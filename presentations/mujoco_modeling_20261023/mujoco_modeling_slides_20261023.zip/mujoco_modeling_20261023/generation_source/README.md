生成器作为审计源文件保存，含本云环境路径。若在其他机器重新生成，需提供用户原模板、调整TEMPLATE/B路径，并安装python-pptx、numpy、Pillow、PyMuPDF和LibreOffice。直接使用PPTX/PDF无需运行这些文件。
