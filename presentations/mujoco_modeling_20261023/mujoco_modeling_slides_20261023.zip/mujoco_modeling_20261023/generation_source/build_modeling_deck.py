"""Standalone MuJoCo modeling deck; never modify the original or the pi0 deck."""
from pathlib import Path
from copy import deepcopy
import json,math,hashlib
import numpy as np
from pptx import Presentation
from pptx.oxml.ns import qn
from pptx.oxml.xmlchemy import OxmlElement
from ppt_native_helpers import *

B=Path(__file__).resolve().parent
ASSETS=B/'model_assets';OUT=B/'deliverables';OUT.mkdir(exist_ok=True)
TEMPLATE=Path('/workspace/attachments/fcfe5bbf-f397-432f-b837-40c0832bb3a7/RCM眼科机器人眼底血管目标的视觉定位与闭环控制.pptx')
TEAL,ORANGE,RED='147D92','C97928','B24B4B'
TIMES=[15,45,55,75,75,60,55]
TITLES=['MuJoCo建模与RCM运动学模型','MuJoCo场景与建模层级','主运动链：两个转动关节与一个移动关节','RCM运动学模型：两轴定向，沿针轴插入','正运动学：从关节坐标到针尖位置','RCM约束与模型数值一致性检验','编码器映射与当前模型边界']

def asset(*names):
    for n in names:
        p=ASSETS/n
        if p.exists():return p
    raise FileNotFoundError(names)

def caption(s,t):text(s,.75,6.65,11.9,.25,t,10.5,False,MUTED)
def bottom(s,t,warning=False):
    shape(s,.67,6.12,12,.49,'FFF7ED' if warning else LIGHT)
    text(s,.83,6.16,11.65,.39,t,18,True)

def equation(s,x,y,w,h,tokens,size=24,bold=False):
    """Editable text runs with real sub/superscripts, rather than literal underscores."""
    z=text(s,x,y,w,h,'',size,bold,align=PP_ALIGN.CENTER)
    paragraph=z.text_frame.paragraphs[0]
    for token in tokens:
        value,baseline=(token if isinstance(token,tuple) else (token,0))
        r=paragraph.add_run();r.text=value
        r.font.name=FONT;r.font.size=Pt(size if not baseline else size*.73)
        r.font.bold=bold;r.font.color.rgb=color(DARK)
        rp=r._r.get_or_add_rPr()
        if baseline:rp.set('baseline',str(baseline))
        for tag in ('latin','ea','cs'):
            font=OxmlElement('a:'+tag);font.set('typeface',FONT);rp.append(font)
    return z

p=Presentation(str(TEMPLATE))
cover=[deepcopy(x.element) for x in p.slides[0].shapes]
body=[deepcopy(x.element) for x in p.slides[6].shapes if x.shape_id in {2,3,4,5,6,7,8,9,25,26,27}]
cr={k:r for k,r in p.slides[0].part.rels.items() if r.reltype.endswith('/image')}
br={k:r for k,r in p.slides[6].part.rels.items() if r.reltype.endswith('/image')}
layout=p.slides[6].slide_layout
for sid in list(p.slides._sldIdLst):p.part.drop_rel(sid.rId);p.slides._sldIdLst.remove(sid)
records=[]

def slide(n):
    s=p.slides.add_slide(layout)
    for sh in list(s.shapes):s.shapes._spTree.remove(sh.element)
    elements,rels=(cover,cr) if n==1 else (body,br)
    mapping={rid:s.part.relate_to(r.target_part,r.reltype) for rid,r in rels.items()}
    for el in elements:
        e=deepcopy(el)
        for node in e.iter():
            for k in list(node.attrib):
                if k in (qn('r:embed'),qn('r:id')) and node.attrib[k] in mapping:node.attrib[k]=mapping[node.attrib[k]]
        s.shapes._spTree.insert_element_before(e,'p:extLst')
    sh={x.shape_id:x for x in s.shapes}
    if n>1:
        set_text(sh[7],'01' if n<4 else '02' if n<7 else '03',24,True,WHITE,PP_ALIGN.CENTER)
        sh[9].width=Inches(9.12);set_text(sh[9],TITLES[n-1],28,True)
        set_text(sh[25],'MuJoCo建模 · RCM运动学',11,False,MUTED)
        set_text(sh[26],'等效任务链 · 坐标映射 · 模型边界',11,False,MUTED,PP_ALIGN.CENTER)
        set_text(sh[27],f'{n:02d} / 07',11,True,MUTED,PP_ALIGN.RIGHT)
    records.append({'page':n,'title':TITLES[n-1],'seconds':TIMES[n-1]})
    return s,sh

def notes(s,n,t,source):
    records[n-1].update(notes=t,source=source)
    s.notes_slide.notes_text_frame.text=f'建议讲述：{TIMES[n-1]}秒。\n\n{t}\n\n来源与条件：\n'+'\n'.join(source)

def ry(a):
    c,s=math.cos(a),math.sin(a);return np.array([[c,0,s],[0,1,0],[-s,0,c]])
def rx(a):
    c,s=math.cos(a),math.sin(a);return np.array([[1,0,0],[0,c,-s],[0,s,c]])

def poly(s,xy,fill=BLUE,width=2,arrow=False,dash=False):
    # A single native editable freeform polyline, not a generated image.
    pts=[(round(x*1000),round(y*1000)) for x,y in xy]
    builder=s.shapes.build_freeform(pts[0][0],pts[0][1],scale=Inches(1)/1000)
    builder.add_line_segments(pts[1:],close=False)
    z=builder.convert_to_shape();z.fill.background();z.line.color.rgb=color(fill);z.line.width=Pt(width)
    if arrow:
        a=OxmlElement('a:tailEnd');a.set('type','triangle');z.line._get_or_add_ln().append(a)
    if dash:
        from pptx.enum.dml import MSO_LINE_DASH_STYLE
        z.line.dash_style=MSO_LINE_DASH_STYLE.DASH
    return z

# 1: user template, separate new presentation.
s,sh=slide(1)
sh[5].left=Inches(.82);sh[5].top=Inches(2.02);sh[5].width=Inches(7.75);sh[5].height=Inches(1.70)
set_text(sh[5],'MuJoCo 建模与\nRCM 运动学模型',42,True,WHITE)
sh[6].left=Inches(.85);sh[6].top=Inches(4.25);sh[6].width=Inches(7.65);sh[6].height=Inches(.50)
set_text(sh[6],'场景搭建 · R–R–P等效链 · 针尖运动与RCM约束',18,False,WHITE)
set_text(sh[8],'汇报人：杨淏博',18,False,'143295')
set_text(sh[10],'日期：2026.10.23',18,False,'143295')
picture(s,asset('mujoco_external_model.png','white_meeting_external.png'),9.10,1.89,3.35,3.10,'当前MuJoCo模型的静态说明用外视渲染')
notes(s,1,'这一份单独说明MuJoCo中怎样建立RCM机器人模型，重点是关节树、运动学模型、针尖坐标变换与RCM约束。它是独立文件，不修改之前的π0与导航汇报。',['rcm_reference.py；rcm_recovered_model.py；config.json','外部模型图片为说明用静态重渲染，不是新导航实验。'])

# 2: actual compiled scene render and editable model hierarchy.
s,_=slide(2)
shape(s,.72,1.43,6.10,4.44,WHITE,BORDER)
picture(s,asset('mujoco_external_model.png','white_meeting_external.png'),.81,1.55,3.65,4.10,'等效机构、眼球和针具的真实MuJoCo静态渲染')
picture(s,asset('mujoco_needle_close.png','white_needle_close.png'),4.50,2.01,2.20,2.85,'RCM及针尖局部的实际MuJoCo渲染')
text(s,4.52,1.53,2.14,.37,'针具 / 眼球局部',17,True,BODY,PP_ALIGN.CENTER)
text(s,.95,5.40,5.58,.28,'实际MuJoCo渲染；展示标记与外观杆件为示意',13,False,MUTED,PP_ALIGN.CENTER)
box(s,7.16,1.48,5.35,1.08,'场景层','眼球椭球、目标、相机、针具与RCM site',headsize=23,bodysize=18)
box(s,7.16,2.84,5.35,1.08,'任务运动层','3个独立任务关节＋4个从属显示关节',headsize=23,bodysize=18)
box(s,7.16,4.20,5.35,1.08,'运行方式','直接设置qpos并调用mj_forward；nu=0',headsize=23,bodysize=18)
bottom(s,'当前是理想化运动学参考模型：外观用于说明，任务链用于针尖运动。')
caption(s,'来源：Reference.build_xml；静态展示重渲染参数与源码哈希随材料保存')
notes(s,2,'场景由眼球椭球、目标、相机、针具和固定RCM点构成。图片是当前模型的实际外部渲染，不是绘制出来的机构效果图。运动层有三个独立任务关节，并带四个从属显示关节，所以MuJoCo的nq与nv等于七，但控制任务自由度仍是三。当前通过设置qpos并调用mj_forward计算运动学，没有actuator，nu等于零。外观等效杆件并未按实机逐项标定，不能以截图推断真实机构尺寸或动力学。',['rcm_reference.py:446–760','config.json:illustrative_linkage，measured=false；visual_scale=0.67','model_assets/中的渲染说明；无新导航运行。'])

# 3: topology and exact local joint axes, all editable.
s,_=slide(3)
for i,(h,b) in enumerate([('固定安装','Rx(45°)'),('A_stage','hinge：−Y'),('B任务框架','hinge：＋X'),('C_carriage','slide：−Z'),('needle_tip','针尖 site')]):
    x=.78+i*2.43
    box(s,x,1.55,2.15,1.14,h,b,headsize=18 if i in (2,3) else 21,bodysize=17.5)
    if i<4:line(s,x+2.17,2.11,x+2.39,2.11,width=1.7)
text(s,.94,2.95,11.60,.59,'这是父子层级展开图：A、B等效旋转轴在空间中相交于同一个RCM。',20,True,BLUE)
table(s,.82,3.77,11.71,1.71,[['关节','MuJoCo名称','类型','自身局部轴','内部坐标'],['A','A_azimuth','hinge','(0, −1, 0)','a：rad'],['B','B_pitch','hinge','(1, 0, 0)','b：rad'],['C','C_insertion','slide','(0, 0, −1)','c：m']],widths=[.70,3.42,1.40,3.06,3.13],size=18,headsize=18)
bottom(s,'7个qpos不等于7个独立控制自由度；4个visual_B关节随B按正负关系联动。')
caption(s,'来源：rcm_reference.py 的TASK_JOINTS、DEPENDENT_JOINTS与build_xml；局部轴不能替写为通用Rz–Ry链')
notes(s,3,'真实主链从固定安装体依次进入A_stage、B_RCM_task_frame、C_carriage_and_needle和针尖site。A是绕自身局部负Y轴的hinge，B是绕局部正X轴的hinge，C沿局部负Z轴平移。因此不能直接套用常见的绕世界Z和Y旋转的公式。A、B是放在RCM处的等效任务旋转轴，展开框图只表示父子关系，不表示两轴在空间分离，也不是声称真实电机轴都安装在RCM。四个可视B关节由任务B正负赋值，不是额外控制量。',['rcm_reference.py:21、239–242、647–692','scene.xml相应body/joint及equality条目。'])

# 4: exact-axis RCM schematic, constructed as native PPT objects.
s,_=slide(4)
shape(s,.74,1.38,7.00,4.55,WHITE,BORDER)
text(s,.92,1.47,6.55,.37,'安装系{M}下的等效任务轴投影 · 不按比例',16,False,MUTED)
O=np.array([3.35,3.24]);S=1.42
P=np.array([[math.sqrt(3)/2,-.5,0],[-.3,-.5,.8]])
def pr(v):
    u=P@np.asarray(v,dtype=float)
    return (O+S*np.array([u[0],-u[1]])).tolist()
a=math.radians(35);b=math.radians(15);beta0=math.radians(-13.7639947496);beta=beta0+b
ra=ry(-a);d=ra@rx(beta)@np.array([0.,0.,-1.]);d0=rx(beta0)@np.array([0.,0.,-1.])
ex,ey,ez=np.eye(3)
for v,lab,dx,dy in [(ex,'x_M',.04,.04),(ey,'y_M',-.48,.02),(ez,'z_M',-.46,-.28)]:
    pt=pr(1.12*v);line(s,*O,*pt,fill='94A3B8',width=1.4)
    text(s,pt[0]+dx,pt[1]+dy,.78,.35,lab,16,False,MUTED)
# Reference needle and current needle both pass through the same point.
poly(s,[pr(-.75*d0),pr(1.95*d0)],fill='B8C2CF',width=2,dash=True)
poly(s,[pr(-.84*d),pr(1.95*d)],fill=DARK,width=4)
tip=np.array(pr(1.95*d))
shape(s,tip[0]-.055,tip[1]-.055,.11,.11,TEAL,None,MSO_SHAPE.OVAL)
text(s,tip[0]+.10,tip[1]-.18,1.23,.40,'P_tip',19,True,TEAL)
shape(s,O[0]-.075,O[1]-.075,.15,.15,RED,None,MSO_SHAPE.OVAL)
text(s,1.20,2.84,1.75,.42,'O_RCM 固定',20,True,RED);line(s,2.92,3.10,*O,fill=RED,width=1.2,arrow=False)
# Positive axes: A = -Y_M; B = R_y(-phi) X_M; C = current needle direction.
pa=pr(1.45*(-ey));line(s,*O,*pa,fill=BLUE,width=3)
text(s,pa[0]-.04,pa[1]-.46,1.02,.40,'A轴',21,True,BLUE)
pb=pr(1.42*(ra@ex));line(s,*O,*pb,fill=ORANGE,width=3)
text(s,pb[0]+.05,pb[1]-.14,1.04,.40,'B轴',21,True,ORANGE)
# Native rotation arcs are actual projections about their labelled local axes.
arcA=[pr(.90*(ry(-t)@np.array([0,0,-1.]))) for t in np.linspace(0,a,24)]
arcB=[pr(1.24*(ra@rx(t)@np.array([0,0,-1.]))) for t in np.linspace(beta0,beta,24)]
poly(s,arcA,BLUE,2.4,True);poly(s,arcB,ORANGE,2.4,True)
text(s,3.47,4.03,.50,.36,'a',20,True,BLUE)
text(s,4.40,4.27,.50,.36,'b',20,True,ORANGE)
# Parallel insertion arrow and distance annotation, both editable.
off=np.array([.90,.25]);c1=np.array(pr(.58*d))+off;c2=np.array(pr(1.61*d))+off
line(s,*c1,*c2,fill=TEAL,width=2.6)
text(s,c2[0]+.16,c2[1]-.59,1.15,.45,'C：＋c',18,True,TEAL)
dim=np.array([-.49,.20]);q1=O+dim;q2=tip+dim
dd=line(s,*q1,*q2,fill=MUTED,width=1.1)
he=OxmlElement('a:headEnd');he.set('type','triangle');dd.line._get_or_add_ln().append(he)
text(s,1.64,4.34,2.10,.45,'L = L₀＋c',20,True,BODY)
box(s,8.09,1.56,4.45,1.10,'A：方位转动','绕−Y_M；a改变针轴方位',headsize=23,bodysize=18)
box(s,8.09,2.95,4.45,1.10,'B：俯仰转动','绕旋转后的＋X_A；b改变俯仰',headsize=23,bodysize=17)
box(s,8.09,4.34,4.45,1.10,'C：轴向插入','沿针轴−Z_B；c增加针尖距离',headsize=23,bodysize=17)
bottom(s,'A/B改变方向，C改变RCM到针尖的距离；针轴始终通过同一个固定RCM。')
caption(s,'原生可编辑示意；图示a=35°、b=15°，展示比例非实际长度；真实主链与配置见后页')
notes(s,4,'这张图是运动学模型的核心。安装系M的原点设在固定RCM。蓝色A轴沿负Y_M，橙色B轴随A旋转，沿转后的正X_A；绿色C方向是针轴局部负Z_B。A和B改变方向，C只沿当前针轴推进，所以无论姿态如何变化，针轴都应穿过固定RCM。虚线表示参考姿态，实线表示示意姿态。RCM到针尖的长度是参考偏置L零加插入增量c。图由PowerPoint原生线、箭头、圆点和文字构成，可继续编辑；只表达模型关系，不按实机尺寸绘制。',['rcm_reference.py:647–692；关节局部轴0 −1 0 / 1 0 0 / 0 0 −1','图示投影参数记录在evidence/kinematic_diagram.json。'])
(B/'evidence/kinematic_diagram.json').write_text(json.dumps({'frame':'MuJoCo fixed mount {M}','origin':'RCM','projection':P.tolist(),'display_scale_in':S,'a_deg':35,'b_deg':15,'beta0_deg':-13.7639947496,'needle_unit_M':d.tolist(),'A_axis_M':[0,-1,0],'B_axis_M':(ra@ex).tolist(),'positive_C_axis_M':d.tolist(),'not_to_scale':True,'native_editable':True},ensure_ascii=False,indent=2))

# 5: homogeneous chain, direct match to the source model.
s,_=slide(5)
box(s,.80,1.42,11.74,.82,'内部任务坐标 q=(a,b,c)：角度rad，位移m；显示ABC使用°、°、mm',headsize=21)
equation(s,.93,2.53,11.55,.68,[('W',35000),'T',('tip',-25000),' = T(p',('RCM',-25000),') · R',('x',-25000),'(45°) · R',('y',-25000),'(−φ) · R',('x',-25000),'(β) · T',('z',-25000),'(−L)'],25,True)
equation(s,.95,3.38,11.50,.64,[('W',35000),'p',('tip',-25000),' = ',('W',35000),'p',('RCM',-25000),' ＋ L · R',('x',-25000),'(45°) R',('y',-25000),'(−φ) R',('x',-25000),'(β) · [0,0,−1]',('T',35000)],24)
table(s,.91,4.36,11.50,1.20,[['变量定义','当前零位参数','物理含义'],['φ=φ₀+a；β=β₀+b；L=L₀+c','φ₀=0°；β₀≈−13.764°\nL₀=0.004m（4mm）','方向角含零位偏置；长度含参考偏置']],widths=[4.27,3.99,3.24],size=17,headsize=18)
bottom(s,'显示ABC全零时，针尖仍距RCM约4mm；此偏置目前是暂定值，尚未实测。',True)
caption(s,'W为世界系；来源：state_from_task、robot_to_world、build_xml；45°安装尚未标定，代入前统一SI单位')
notes(s,5,'正运动学严格按MuJoCo主链写。先平移到世界系中的RCM，再施加当前配置的45度X安装旋转，随后绕负Y进行方位转动、绕X进行俯仰，最后沿局部负Z平移到针尖。内部任务坐标是弧度、弧度、米，界面显示是度、度、毫米，两者需转换。方位角phi含零位phi零，俯仰beta含beta零，长度L含L零。当前phi零为0度，beta零约负13.764度，L零为4毫米，因此ABC显示为零并不代表针尖在RCM。这个4毫米是暂定模型偏置，不能作为已经实测的几何标定。',['rcm_reference.py:67–104、216–222、282–286、647–692','config.json:installation、encoder_reference','源机器人系换基R_mount diag(1,−1,−1)与此安装系写法等价，不是额外物理安装。'])

# 6: geometric RCM line constraint and minimal verified numerical examples.
s,_=slide(6)
equation(s,.89,1.41,11.55,.55,['d',('W',-25000),' = R',('x',-25000),'(45°) R',('y',-25000),'(−φ) R',('x',-25000),'(β) [0,0,−1]',('T',35000)],26)
equation(s,.89,2.16,11.55,.65,['e',('RCM',-25000),' = ‖(I − d',('W',-25000),' d',('W',-25000),('T',35000),')(p',('tip',-25000),' − p',('RCM',-25000),')‖ = 0'],29,True)
text(s,.94,2.92,11.55,.44,'含义：固定RCM到当前针轴直线的垂直距离为零。',21,False,BODY,PP_ALIGN.CENTER)
evidence=B/'evidence/numeric_checks.json'
if not evidence.is_file():raise FileNotFoundError(evidence)
ev=json.loads(evidence.read_text())
cases=ev.get('cases',ev.get('samples',[]))
rows=[['检验对象','执行范围','结果解释'],['关节结构','3独立任务＋4从属显示；nu=0','确认控制维数与层级'],['解析FK与MuJoCo site','3个确定姿态，比较针尖位置','差异处于浮点精度量级'],['针轴通过RCM','各姿态计算轴到RCM距离','满足理想模型几何约束']]
table(s,.94,3.73,11.43,1.75,rows,widths=[2.62,5.01,3.80],size=18,headsize=18)
bottom(s,'数值一致性证明实现对应同一运动学模型；它不等于实体机器人具有同等精度。',True)
caption(s,'只读固定姿态检验；不运行导航或训练；具体姿态、误差、源码哈希见numeric_checks.json')
notes(s,6,'RCM约束可以写为固定点到当前针轴直线的距离。d是单位针轴方向，I减dd转置把向量投影到针轴的垂直平面，所以约束为零意味着针轴经过固定RCM。我们做了最小的只读数值检验：检查三个任务变量和四个显示从属关节，再在三个确定姿态比较解析正运动学和MuJoCo针尖site，并计算轴到RCM的距离。差异在浮点精度量级，说明公式与编译模型一致。这是程序和理想模型的一致性检查，不能解释为实机达到这种数值精度。',['evidence/numeric_checks.json','rcm_reference.py:state_from_task、set_task、metrics；rcm_recovered_model.py:needle_axis、forward'])

# 7: nominal actuator mapping is distinct from a calibrated spatial linkage.
s,_=slide(7)
for i,(h,b) in enumerate([('实机编码器E','零位、符号、比例'),('名义机构映射','B直线位移 ↔ α'),('任务坐标与针尖','φ、α、L ↔ 位置')]):
    x=.83+i*4.10;box(s,x,1.46,3.69,1.04,h,b,headsize=22,bodysize=18)
    if i<2:line(s,x+3.73,1.97,x+4.06,1.97)
equation(s,.96,2.93,11.40,.55,['s',('B',-25000),'(α) = 98.48 − 60cosα − √[52² − (60sinα − 16)²]  mm'],25,True)
text(s,.96,3.62,11.40,.42,'α为原程序俯仰角；s_B不是角增量b，位移逆解需选定分支。',19,False,BODY,PP_ALIGN.CENTER)
box(s,.84,4.38,5.67,1.19,'已明确的仿真能力','等效RCM链、几何观测接口、针尖坐标计算',headsize=22,bodysize=18)
box(s,6.84,4.38,5.67,1.19,'仍需实测与建模','实机杆件/外参/针尖偏置；接触与动力学',headsize=22,bodysize=18)
bottom(s,'外观杆件未实测、4mm偏置暂定；无actuator与动力学积分，不能作为实体动力学模型。',True)
caption(s,'名义参数l₁=60mm、l₂=52mm、h=16mm；α接口用°，三角函数先转rad；外观杆件示意参数另设')
notes(s,7,'最后区分任务运动学、名义编码器映射和实机标定。编码器通过零位、符号和比例换算为执行器量，B执行器还有非线性位移到角度的映射。这里给出的公式来自原程序恢复的名义参数，并非实机闭链已经测量完成；B直线位移s_B也不是任务角增量b。α是原程序俯仰角，β=α−68°；因为映射跨极小值后并非一一对应，逆解需约束分支并参考前一姿态。当前明确的是等效RCM运动学、场景和几何观测接口。外观杆件、针尖绝对偏置、相机外参和真实机构映射仍需实测。模型没有actuator或动力学积分，惯量为占位、重力和接触关闭，因此不能用于宣称真实受力、制动或组织穿刺效果。',['rcm_recovered_model.py:b_displacement、EncoderMap','config.json:kinematics、encoders、encoder_reference、illustrative_linkage','rcm_reference.py:set_task及build_xml；当前动力学与接触范围说明见model_evidence.md。'])

assert len(p.slides)==7
p.core_properties.title='MuJoCo建模与RCM运动学模型'
p.core_properties.author='杨淏博'
p.core_properties.subject='独立建模汇报；原生可编辑运动学模型图；不修改原PPT'
path=OUT/'mujoco_rcm_kinematic_model_20261023.pptx';p.save(str(path))
(B/'slide_manifest.json').write_text(json.dumps({'slides':7,'planned_seconds':sum(TIMES),'records':records},ensure_ascii=False,indent=2))
chunks=['# MuJoCo建模与RCM运动学模型：逐页讲稿','独立7页建模PPT；计划约6分20秒，可按组会需要选页。','']
for r in records:chunks += [f"## {r['page']}. {r['title']}（{r['seconds']}秒）",r['notes'],'','来源：'+'；'.join(r['source']),'']
(OUT/'speaker_notes_建模讲稿.md').write_text('\n'.join(chunks))
orig=json.loads((B/'evidence/originals_sha256.json').read_text())
for name,digest in orig.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
print('STANDALONE_PPTX',path,'SLIDES',len(p.slides),'ORIGINALS_UNCHANGED',True)
