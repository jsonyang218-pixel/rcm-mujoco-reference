from pathlib import Path
from PIL import Image
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt
FONT = "Noto Sans SC"
BLUE, LIGHT, DARK, BODY = "4874CB", "DAE3F5", "0F172A", "475569"
MUTED, CARD, BORDER, WHITE = "64748B", "F8FAFC", "CBD5E1", "FFFFFF"


def color(h):
    return RGBColor.from_string(h)

def style_paragraph(p, text, size=20, bold=False, fill=DARK, align=PP_ALIGN.LEFT):
    p.text = text
    p.alignment = align
    p.space_before = Pt(0)
    p.space_after = Pt(0)
    p.line_spacing = 1.10
    for r in p.runs:
        r.font.name = FONT
        r.font.size = Pt(size)
        r.font.bold = bold
        r.font.color.rgb = color(fill)
        rp = r._r.get_or_add_rPr()
        for tag in ('latin','ea','cs'):
            e = rp.find(qn('a:'+tag))
            if e is None:
                e = OxmlElement('a:'+tag)
                rp.append(e)
            e.set('typeface',FONT)

def set_text(shape, text, size=20, bold=False, fill=DARK, align=PP_ALIGN.LEFT):
    tf=shape.text_frame
    tf.clear()
    tf.word_wrap=True
    tf.auto_size=MSO_AUTO_SIZE.NONE
    tf.vertical_anchor=MSO_ANCHOR.MIDDLE
    tf.margin_left=tf.margin_right=Inches(.02)
    tf.margin_top=tf.margin_bottom=Inches(.01)
    for i,line in enumerate(text.split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        style_paragraph(p,line,size,bold,fill,align)
    return shape

def text(slide,x,y,w,h,value,size=20,bold=False,fill=DARK,align=PP_ALIGN.LEFT):
    sh=slide.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h))
    return set_text(sh,value,size,bold,fill,align)

def shape(slide,x,y,w,h,fill=CARD,line=None,kind=MSO_SHAPE.ROUNDED_RECTANGLE):
    s=slide.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h))
    s.fill.solid(); s.fill.fore_color.rgb=color(fill)
    if line:
        s.line.color.rgb=color(line);s.line.width=Pt(.8)
    else:
        s.line.fill.background()
    if kind==MSO_SHAPE.ROUNDED_RECTANGLE:
        try:s.adjustments[0]=.12
        except Exception:pass
    return s

def box(slide,x,y,w,h,head,body='',fill=CARD,border=None,headsize=21,bodysize=18):
    shape(slide,x,y,w,h,fill,border)
    if body:
        text(slide,x+.14,y+.10,w-.28,.42,head,headsize,True)
        text(slide,x+.14,y+.57,w-.28,h-.66,body,bodysize,False,BODY)
    else:
        text(slide,x+.12,y+.08,w-.24,h-.16,head,headsize,True,align=PP_ALIGN.CENTER)

def line(slide,x1,y1,x2,y2,fill=BLUE,width=2.0,arrow=True,dash=False):
    s=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2))
    s.line.color.rgb=color(fill);s.line.width=Pt(width)
    if dash:
        from pptx.enum.dml import MSO_LINE_DASH_STYLE
        s.line.dash_style=MSO_LINE_DASH_STYLE.DASH
    if arrow:
        e=OxmlElement('a:tailEnd');e.set('type','triangle');s.line._get_or_add_ln().append(e)
    return s

def picture(slide,path,x,y,w,h,alt=''):
    path=Path(path)
    if not path.is_file(): raise FileNotFoundError(path)
    with Image.open(path) as im: iw,ih=im.size
    scale=min(w/iw,h/ih);fw,fh=iw*scale,ih*scale
    s=slide.shapes.add_picture(str(path),Inches(x+(w-fw)/2),Inches(y+(h-fh)/2),Inches(fw),Inches(fh))
    if alt:
        s._element.nvPicPr.cNvPr.set('descr',alt)
    return s

def table(slide,x,y,w,h,rows,widths=None,size=17,headsize=17):
    t=slide.shapes.add_table(len(rows),len(rows[0]),Inches(x),Inches(y),Inches(w),Inches(h)).table
    if widths:
        for c,ww in zip(t.columns,widths):c.width=Inches(ww)
    for ri,row in enumerate(rows):
        for ci,val in enumerate(row):
            c=t.cell(ri,ci)
            c.fill.solid();c.fill.fore_color.rgb=color(LIGHT if ri==0 else (WHITE if ri%2==0 else CARD))
            c.margin_left=Inches(.10);c.margin_right=Inches(.08)
            c.margin_top=Inches(.03);c.margin_bottom=Inches(.03)
            c.vertical_anchor=MSO_ANCHOR.MIDDLE
            for tag in ('lnL','lnR','lnT','lnB'):
                e=OxmlElement('a:'+tag);e.set('w','5500')
                sf=OxmlElement('a:solidFill');rgb=OxmlElement('a:srgbClr');rgb.set('val',WHITE);sf.append(rgb);e.append(sf);c._tc.get_or_add_tcPr().append(e)
            tf=c.text_frame;tf.clear();tf.word_wrap=True
            for pi,ss in enumerate(str(val).split('\n')):
                p=tf.paragraphs[0] if pi==0 else tf.add_paragraph()
                style_paragraph(p,ss,headsize if ri==0 else size,ri==0,DARK if ri==0 else BODY)
    return t
