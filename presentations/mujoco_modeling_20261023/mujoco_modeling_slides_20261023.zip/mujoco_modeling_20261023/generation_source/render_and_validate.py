"""Export a PDF and inspect the standalone modeling deck, without touching old slides."""
from pathlib import Path
import hashlib,json,os,subprocess,zipfile
import fitz
from PIL import Image,ImageOps,ImageDraw
from pptx import Presentation

B=Path(__file__).resolve().parent
O=B/'deliverables';R=B/'renders';R.mkdir(exist_ok=True)
P=O/'mujoco_rcm_kinematic_model_20261023.pptx'
env=os.environ.copy()
env['FONTCONFIG_FILE']='/workspace/exports/pi0_rcm_meeting_20261023/fontconfig.xml'
subprocess.run(['soffice',f'-env:UserInstallation=file://{B}/lo_profile','--headless','--convert-to','pdf','--outdir',str(O),str(P)],env=env,check=True,timeout=90)
pdf=P.with_suffix('.pdf')
doc=fitz.open(pdf);assert len(doc)==7
for i,page in enumerate(doc):
    pix=page.get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False)
    pix.save(R/f'slide_{i+1:02d}.png')
canvas=Image.new('RGB',(1600,1100),'#e2e8f0');draw=ImageDraw.Draw(canvas)
for i in range(7):
    im=Image.open(R/f'slide_{i+1:02d}.png');im=ImageOps.contain(im,(512,288))
    x=16+(i%3)*530;y=22+(i//3)*355
    canvas.paste(im,(x,y+25));draw.text((x,y),f'{i+1:02d}',fill='#0f172a')
canvas.save(R/'contact_sheet.jpg',quality=93)
# A separate high-resolution image and a vector PDF make the model easy to reuse.
doc[3].get_pixmap(matrix=fitz.Matrix(2.5,2.5),alpha=False).save(O/'rcm_kinematic_model.png')
single=fitz.open();single.insert_pdf(doc,from_page=3,to_page=3);single.save(O/'rcm_kinematic_model.pdf')
pres=Presentation(P)
out_of_bounds=[]
for i,s in enumerate(pres.slides):
    for sh in s.shapes:
        if sh.left < -9144 or sh.top < -9144 or sh.left+sh.width>pres.slide_width+9144 or sh.top+sh.height>pres.slide_height+9144:
            out_of_bounds.append({'slide':i+1,'shape_id':sh.shape_id})
notes=[bool(s.notes_slide.notes_text_frame.text.strip()) for s in pres.slides]
originals=json.loads((B/'evidence/originals_sha256.json').read_text())
originals_unchanged={n:hashlib.sha256(Path(n).read_bytes()).hexdigest()==v for n,v in originals.items()}
with zipfile.ZipFile(P) as z:assert z.testzip() is None
report={'slides':len(pres.slides),'pdf_pages':len(doc),'all_speaker_notes_present':all(notes),'object_bounds_check':out_of_bounds,'originals_unchanged':originals_unchanged,'originals_all_unchanged':all(originals_unchanged.values()),'native_kinematic_diagram_shapes':len(pres.slides[3].shapes),'native_diagram_picture_objects':sum(sh.shape_type==13 for sh in pres.slides[3].shapes),'rendering':'LibreOffice + PDF rasterization; not a physical projection or Microsoft PowerPoint check','artifacts':{f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in O.iterdir() if f.is_file()}}
assert all(notes) and all(originals_unchanged.values())
(B/'evidence/validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
