# MuJoCo建模与RCM运动学模型

独立7页建模汇报，沿用用户提供的蓝色模板。预计讲述约6分20秒；这不是实测试讲时长。原上传模板、原π0组会PPTX/PDF及原组会生成器均保持字节不变，校验记录见 `evidence/validation.json`。

## 直接使用

- `mujoco_rcm_kinematic_model_20261023.pptx`：可编辑PPT，含逐页演讲者备注。
- `mujoco_rcm_kinematic_model_20261023.pdf`：7页PDF，便于预览与保留字体效果。
- `speaker_notes_建模讲稿.md`：中文逐页讲稿与来源。
- `rcm_kinematic_model.png` / `.pdf`：第4页运动学模型图的单页导出。
- `fonts/`：Noto Sans SC静态字体与OFL许可。若PowerPoint出现字体替换，可先安装字体再重新打开PPT；PDF已保存本次导出的字形效果。

PPT中的标题、正文、表格、关节树、坐标轴、转角弧、插入箭头和数学公式均由原生对象组成；模型截图是有来源的MuJoCo静态渲染。第4页中的两个图片对象是模板背景/标志，不是运动学示意图栅格化。

## 页面安排

1. MuJoCo建模与RCM运动学模型
2. MuJoCo场景与建模层级
3. 主运动链：两个转动关节与一个移动关节
4. RCM运动学模型：两轴定向，沿针轴插入
5. 正运动学：从关节坐标到针尖位置
6. RCM约束与模型数值一致性检验
7. 编码器映射与当前模型边界

## 汇报口径

主任务链是R–R–P等效运动学链：A局部轴−Y，B局部轴＋X，C沿局部−Z插入；两个定向轴在RCM相交。MuJoCo的7个qpos包括3个独立任务变量和4个从属显示关节，不等于7个独立控制自由度。

固定安装为当前配置的Rx(45°)，未完成实机标定；当前参考针尖距离L0=4mm也是暂定值。名义B执行器映射与未实测的外观杆件参数分别说明，逆解需选择分支。

截图为固定零位的说明用重渲染，未执行导航、训练或物理步进。三姿态检验只验证解析正运动学与MuJoCo site的位置一致性，不能作为导航结果、实机精度或组织接触效果。当前运行通过set_task写qpos并调用mj_forward，nu=0，没有actuator或动力学积分；惯量为占位、重力与接触关闭。

## 证据与检查范围

`evidence/`保存数学推导、三个固定姿态检查、源码哈希、原文件哈希、程序校验，以及独立逻辑/视觉审查。`model_assets/`保存图片、展示快照、配置快照、静态渲染元数据与复现脚本。展示快照只改变背景、颜色与展示设置，不能替代采集场景。

已完成PPTX结构、备注、对象边界、ZIP内部CRC、PDF页数和逐页图像检查。PDF由LibreOffice生成，未在实体投影仪或Microsoft PowerPoint中验证。源码来源：<https://github.com/jsonyang218-pixel/rcm-mujoco-reference>，基准main为`79afacc4bd041228ead0d80d9e44b993d764a449`；具体文件以元数据SHA256为准。

## 制作与审查规范来源

- K-Dense Inc. Scientific Slides v1.12, Scientific Agent Skills, commit `593377bb048752abb0152deab9fbb1083a6087df`. <https://github.com/K-Dense-AI/scientific-agent-skills/tree/593377bb048752abb0152deab9fbb1083a6087df/skills/scientific-slides>
- HKUSTDial. Supervisor-Skills, figure-designer与tech-paper-template, commit `a20d76ef3979b804d7dbf599d577826957e0a8a9`. <https://github.com/HKUSTDial/Supervisor-Skills/tree/a20d76ef3979b804d7dbf599d577826957e0a8a9>

本次采用可编辑方法图、真实素材、逐页渲染、论述与证据边界检查；独立建模PPT按用户最新要求制作，未沿用旧组会版本的13＋3页约束。
