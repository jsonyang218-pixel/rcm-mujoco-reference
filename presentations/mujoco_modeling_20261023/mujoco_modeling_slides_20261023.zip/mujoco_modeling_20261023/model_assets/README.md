# MuJoCo建模说明素材

这组图是当前 Reference 的固定零位静态重渲染，用于说明建模与运动学；未运行导航、未执行物理步进，也不是新增实验结果。

- `white_meeting_external.png`：完整外部机构主图（推荐）。
- `white_meeting_side.png`：侧视图，顶部电机帽部分在画外。
- `white_needle_close.png`：眼球、RCM与针具局部。
- `render_metadata.json`：版本、源码与图片SHA256、姿态、ABC、frame、相机与传感器清单。
- `presentation_scene_snapshot.xml`：独立的展示外观快照；原`scene.xml`和`config.json`未修改。

实际姿态为相对复位 A=0°、B=0°、C=0 mm；绝对模型参数φ=0°、α=54.236005°、RCM至针尖距离=4 mm；ABC=[0,1466018,893518]。展示用黄色针具是原模型viewer-only放大辅助，半径比例4；RCM是红色球，针尖为绿色。可视等效杆件并非硬件CAD，尺度比例0.67；模型是纯运动学参考，接触关闭。

为白底版式，仅在独立内存场景中添加白色天空盒、隐藏地面、将B杆件颜色设为模板蓝#4874CB，并关闭阴影。未更改机器人/眼球/针具几何、任务关节或参数配置。
