"""Reproduce static presentation renders; no navigation or physics steps.

Run from the original repository using its .venv/bin/python, without resolving
that interpreter's symlink. This script never writes to source scene/config.
"""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

SOURCE = Path('/workspace/rcm-mujoco-reference')
OUT = Path(__file__).parent
sys.path.insert(0, str(SOURCE))
from rcm_reference import Reference, save_png, _s


def main():
    reference = Reference()
    root = ET.fromstring(reference.xml)
    ET.SubElement(root.find('asset'), 'texture', name='meeting_white_background',
                  type='skybox', builtin='flat', rgb1='1 1 1', rgb2='1 1 1',
                  width='512', height='3072')
    root.find('.//geom[@name="reference_floor"]').set('rgba', '1 1 1 0')
    root.find('.//material[@name="b_link"]').set(
        'rgba', '0.2823529412 0.4549019608 0.7960784314 1')
    for name, position, target, fovy in [
        ('meeting_external', [.26, -.20, .14], [0, -.036, -.025], 32),
        ('meeting_side', [.29, -.03, .0], [0, -.040, -.024], 34),
    ]:
        z_axis = np.array(position) - np.array(target)
        z_axis /= np.linalg.norm(z_axis)
        x_axis = np.cross([0, 0, 1], z_axis)
        x_axis /= np.linalg.norm(x_axis)
        y_axis = np.cross(z_axis, x_axis)
        ET.SubElement(root.find('worldbody'), 'camera', name=name,
                      pos=_s(position), xyaxes=_s(np.r_[x_axis, y_axis]),
                      fovy=str(fovy))
    reference.model = mujoco.MjModel.from_xml_string(
        ET.tostring(root, encoding='unicode'))
    reference.data = mujoco.MjData(reference.model)
    reference.set_task(reference.home)
    option = mujoco.MjvOption()
    option.sitegroup[:] = 0
    option.geomgroup[:] = 1
    option.geomgroup[5] = 0
    with mujoco.Renderer(reference.model, height=1440, width=1600) as renderer:
        for camera in ['meeting_external', 'meeting_side', 'needle_close']:
            renderer.update_scene(reference.data, camera=camera,
                                  scene_option=option)
            renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW] = 0
            save_png(OUT / f'white_{camera}.png', renderer.render())


if __name__ == '__main__':
    main()
