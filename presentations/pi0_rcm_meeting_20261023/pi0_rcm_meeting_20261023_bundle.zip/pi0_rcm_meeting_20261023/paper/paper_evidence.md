# π0 原论文核对与PPT素材证据

核对日期：2026-10-23。供主PPT第3、4、5页使用。以下事实来自实际下载的论文PDF及页面视觉检查；不以第三方解读代替原文结论。

## 论文身份与来源

- 标题：**π0: A Vision-Language-Action Flow Model for General Robot Control**。
- 作者：Kevin Black, Noah Brown, Danny Driess, Adnan Esmail, Michael Equi, Chelsea Finn, Niccolo Fusai, Lachy Groom, Karol Hausman, Brian Ichter, Szymon Jakubczak, Tim Jones, Liyiming Ke, Sergey Levine, Adrian Li-Bell, Mohith Mothukuri, Suraj Nair, Karl Pertsch, Lucy Xiaoyang Shi, James Tanner, Quan Vuong, Anna Walling, Haohuan Wang, Ury Zhilinsky。团队为 Physical Intelligence。
- 论文首次发布年份：**2024**；标识 **arXiv:2410.24164**。PPT可简写“Black et al., 2024，π0”。所用本地PDF没有印出的arXiv版本号；其PDF创建时间为2026-01-03。**该元数据日期不应当作论文首发年份，也不能据此断言它是2024年v1的逐字快照。**
- 用户指定原站：<https://www.physicalintelligence.company/download/pi0.pdf>。原站及arXiv在本环境返回403，因此从两处公开GitHub论文镜像取得实际PDF：
  - <https://github.com/JoeSun-421/paperreading_and_notes/blob/a00807ec53758956d0d063a608ec1817f5bbbce2/week3/pi0.pdf>
  - <https://github.com/assumeengagetry/paper/blob/0ded52c32a4d0fec4f3c542009b85223edc4a36b/Robotics-and-Embodied-AI/Vision-Language-Action-Models/pi0.pdf>
- 两份镜像字节完全相同，均7,873,003 bytes，17页；SHA-256：`75667e62ba43f153805f2330b55966d0ff51abd03aa0ab76ef2d62ab201cc1fd`。文件为 `pi0.pdf`。尚未与目前受阻的原站响应做字节比对，因此“两个镜像一致”不应写成“已验证官方SHA”。
- 原PDF首页及章节明确属于**π0**；不是π0.5论文。官方openpi仓库的README另确认π0为flow-based VLA，π0-FAST为自回归VLA，π0.5为另一版本：<https://github.com/Physical-Intelligence/openpi>。

## 第3页：Figure 3究竟画了什么

**Figure 3是框架总览与网络结构原图，不是实验性能图。** 它把数据混合、PaliGemma视觉语言主干、动作专家、多机器人控制放在同一张图中。所在位置为本地PDF **第4页**。推荐直接使用 `pi0_figure3_framework.png`；另提供保留原始内容的矢量裁切PDF和含caption版本。所有图均来自原论文页面裁切，未重绘。

原始caption：

> Fig. 3: Overview of our framework. We start with a pre-training mixture, which consists of both our own dexterous manipulation datasets and open-source data. We use this mixture to train our flow matching VLA model, which consists of a larger VLM backbone and a smaller action expert for processing robot states and actions. The VLM backbone weights are initialized from PaliGemma [5], providing representations learned from large-scale Internet pre-training. The resulting π0 model can be used to control multiple robot embodiments with differing action spaces to accomplish a wide variety of tasks.

可讲内容：

1. 图像和语言由较大的预训练VLM处理；关节状态与带噪动作由较小的动作专家处理。
2. 正文§IV称PaliGemma约3B参数，另加约300M动作专家，总计约3.3B。原图标为SigLIP (400M) + Gemma (2.6B)，两种写法属于同一图与正文的口径；PPT用“PaliGemma约3B + 动作专家约300M”即可。
3. 附录B（PDF第15页）说明：这不是只把VLM最后一层特征接给独立MLP；模型是**一个具有两套token专属权重的Transformer，两套权重通过self-attention交互**。图像与语言token路由到VLM权重，本体状态与动作token路由到动作专家权重。不要声称VLM在论文训练中冻结。
4. 输入为多路RGB图像、语言指令与本体状态：\(o_t=[I_t^1,\ldots,I_t^n,\ell_t,q_t]\)。论文每机器人有2或3路RGB，\(q_t\)为关节角向量（§IV，PDF第5页）。
5. 输出为连续动作块 \(A_t=[a_t,\ldots,a_{t+H-1}]\)，论文采用 \(H=50\)（§IV及附录B）。原图顶部示意标签写到\(a_{t+H}\)，PPT公式按正文的\(H\)步定义写到\(a_{t+H-1}\)。动作定义随本体变化，不宜笼统标为“SE(3)位姿输出”。

建议讲稿：**“π0把互联网视觉语言预训练与机器人动作学习接在一起：图像和指令进入PaliGemma，状态和带噪动作进入较小的动作专家；通过共享注意力预测一个连续动作块。”**

## 第4页：Flow Matching的可直接使用公式

正文§IV（PDF第5页），以\(t\)表示机器人时刻，以\(\tau\in[0,1]\)表示流匹配时间，\(\epsilon\sim\mathcal N(0,I)\)：

\[
A_t^\tau=\tau A_t+(1-\tau)\epsilon,
\qquad u=A_t-\epsilon.
\]

\[
\mathcal L(\theta)=\mathbb E_{(o_t,A_t),\tau,\epsilon}
\left[\left\|v_\theta(A_t^\tau,o_t,\tau)-(A_t-\epsilon)\right\|_2^2\right].
\]

上式是按论文采样过程写出的等价清晰形式。论文正文把损失记为\(L^\tau(\theta)\)，把网络写为\(v_\theta(A_t^\tau,o_t)\)；时间\(\tau\)由输入嵌入注入，故PPT显式补写\(\tau\)实参时，应说明是为便于讲解展开的条件变量。

推理从\(A_t^0\sim\mathcal N(0,I)\)开始，沿学习到的向量场由\(\tau=0\)积分到\(1\)。论文使用前向Euler：

\[
A_t^{\tau+\delta}=A_t^\tau+\delta\,v_\theta(A_t^\tau,o_t,\tau),
\qquad\delta=0.1\quad(10\text{步}).
\]

直觉说明：**训练时学习“带噪动作向真实专家动作移动的方向”；推理时从噪声沿向量场迭代生成动作块。** 这里的训练目标是动作空间中的向量场，不是图像光流、机械臂笛卡尔速度或单步确定性动作回归。

符号与措辞边界：

- \(\tau=0\)为纯噪声，\(\tau=1\)为数据动作；不要反写方向。
- 正文使用强调较低\(\tau\)、较高噪声的Beta采样分布，而不是均匀采样（附录B，PDF第16页）。三页介绍不必增加该细节。
- 原文高斯路径一行记作\(q(A_t^\tau\mid A_t)=\mathcal N(\tau A_t,(1-\tau)I)\)，但它紧接给出的实际采样\(A_t^\tau=\tau A_t+(1-\tau)\epsilon\)按通常协方差记法对应\((1-\tau)^2 I\)。PPT使用上述明确采样式即可，避免复写该记号不一致。
- 10步是流匹配积分步数；\(H=50\)是预测动作块长度；最高50Hz是机器人动作执行频率，三者不能互换。
- 附录D（PDF第16页）说20Hz平台每次执行16步后重新推理，50Hz平台执行25步后重新推理。不能讲成“每秒50次完整VLM推理”或“所有50步预测全执行完才反馈”。
- 不能仅凭流匹配形式推导“比所有扩散模型更快”或“路径必为直线”；不同生成方法的效率需要独立实测对照。

## 第5页：预训练和高质量任务后训练的实验原图

推荐 **Figure 13**（PDF **第11页**），文件 `pi0_figure13_posttraining.png`。它直接比较：

- \(\pi_0\) (fine-tuned)：预训练后在目标任务数据上后训练；
- \(\pi_0\) (scratch)：没有机器人预训练，只用目标任务训练数据；
- \(\pi_0\) (out-of-box)：仅预训练，未做目标任务后训练。

原始caption：

> Fig. 13: Post-training results on complex tasks in terms of average scores over 10 trials. The full pre-trained π0 model attains more than 50% of the maximum score across all of the tasks, and typically outperforms the ablations, with especially significant improvements on the hardest tasks.

**准确可讲结论：**“预训练加目标任务后训练，在多数复杂任务上比仅预训练或仅用目标任务数据训练取得更高平均任务进度，支持两阶段训练配方；这种优势不是每个任务都出现。”

必须保留的实验解释：

- 纵轴是 **Average Task Progress（平均任务进度）**，每任务10次评估的平均分；不是整集成功率。1.0代表完整执行，部分分数按任务评分规则给出；例如一半物品正确收拾可对应0.5（§VI-D、附录E）。
- 不从柱状图目测生成精确数字，不把“分数超过0.5”说成“成功率超过50%”。
- **Packing Eggs中scratch柱略高于fine-tuned**；不要讲“所有任务都最好”，即使正文某处有“best across the board”的概括。采用caption更审慎的“typically outperforms”并保留图中例外。
- 图中上下排按其标签区分是否在预训练中有对应任务；正文对复杂Table Bussing的描述与图中上排归类存在粒度差异。PPT不必用这点推导严格的已见/未见任务结论。
- 图13是训练方案消融。它**不是**在相同数据预算、相同算力下隔离“数据质量”的纯因果实验，不能据此写“高质量数据单独带来X%提升”。
- 原文§V-A（PDF第5–6页）把预训练定位为覆盖广泛任务、情况和行为，把后训练定位为一致、流畅、有效的目标任务执行。该设计动机可讲，但“低质量数据必然学会恢复”应表述为作者训练配方的直觉，而不是该图单独证明的机制。
- scratch表示未使用机器人预训练，不宜擅自改成“完全无任何预训练”；在小数据新任务实验中，π0架构本身仍可保有VLM初始化（§VI-C）。

建议两句讲稿：**“预训练解决广覆盖，后训练让目标任务执行更熟练。图13的平均任务进度表明，两阶段组合在多数复杂任务上优于两个单独阶段，但装鸡蛋仍存在例外。”**

备选图 **Figure 11**（PDF第10页）：`pi0_figure11_data_efficiency.png`，用于讲1/5/10小时目标任务数据下的适配；不是图13的高质量后训练消融替代品。原始caption：

> Fig. 11: Fine-tuning with varying amounts of data. π0 can learn some easier tasks even with smaller amounts of data, and the pre-trained model often attains a larger improvement over the model trained from scratch.

## π0与π0.5的版本边界

本次三页应只使用原π0的上述证据。**π0.5: a Vision-Language-Action Model with Open-World Generalization** 为2025年另一论文，标识arXiv:2504.16054。不要把π0.5的异构数据联合训练、统一高层子任务预测、陌生家庭/开放世界评估分数放入原π0名下。原π0论文中可由外置高层VLM给出中间语言指令（§V-B），这不能改写成π0内建的高层子任务头。π0-FAST的自回归动作tokenizer也不是这三页所介绍的连续Flow Matching动作专家。

## 素材复现与归档

- `assets.json` 记录原PDF、镜像、SHA、页码和裁切矩形；PDF坐标单位为pt，原点为页面左上。
- `extract_assets.py` 可从本地`pi0.pdf`重新生成400dpi PNG和保持原图的矢量PDF裁切。
- 主用素材：`pi0_figure3_framework.png`，`pi0_figure13_posttraining.png`。
- 含图注素材可用于检查与备份：`pi0_figure3_with_caption.png`，`pi0_figure13_with_caption.png`。
- 早先取得的`fig3-framework.png`和`fig7-out-of-box-eval.png`来自另一公开阅读库，主PPT无需使用；最终推荐图已全部由本地原论文PDF直接裁切。


## 第5页空间受限时的下半图裁切

`pi0_figure13_lower_panel.png` / `.pdf` 从PDF第11页矩形 `[312,170,562,300]`（pt）直接裁切，400dpi。保留原始legend、Average Task Progress纵轴及0–1刻度、三个任务Box Building / To-Go Box / Packing Eggs。没有改动图形或数值，Packing Eggs中scratch略高的例外保留。推荐主PPT图下注明：**“Figure 13下半图｜每任务10次｜平均任务进度（非成功率）”**。全图 `pi0_figure13_posttraining` 继续保留用于复核。
