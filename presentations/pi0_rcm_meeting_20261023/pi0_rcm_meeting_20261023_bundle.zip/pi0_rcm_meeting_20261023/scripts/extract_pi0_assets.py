"""Render unchanged original-paper crops. Run beside pi0.pdf; requires PyMuPDF."""
from pathlib import Path

import fitz

ROOT = Path(__file__).resolve().parent
CROPS = [
    ("pi0_figure3_framework", 4, [48, 52, 564, 200]),
    ("pi0_figure3_with_caption", 4, [48, 52, 564, 264]),
    ("pi0_figure13_posttraining", 11, [312, 55, 562, 300]),
    ("pi0_figure13_with_caption", 11, [311, 53, 563, 366]),
    ("pi0_figure13_lower_panel", 11, [312, 170, 562, 300]),
    ("pi0_figure11_data_efficiency", 10, [48, 53, 564, 320]),
]

with fitz.open(ROOT / "pi0.pdf") as source:
    for stem, page_number, coordinates in CROPS:
        clip = fitz.Rect(coordinates)
        source[page_number - 1].get_pixmap(
            matrix=fitz.Matrix(400 / 72, 400 / 72), clip=clip, alpha=False
        ).save(ROOT / f"{stem}.png")
        with fitz.open() as target:
            page = target.new_page(width=clip.width, height=clip.height)
            page.show_pdf_page(page.rect, source, page_number - 1, clip=clip)
            target.save(ROOT / f"{stem}.pdf")
