"""Build an editable, evidence-grounded 13+3 slide deck using the user's template."""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import hashlib
import json
import math
import subprocess

from PIL import Image
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

BASE = Path(__file__).resolve().parent
REPO = Path('/workspace/rcm-mujoco-reference')
TEMPLATE = Path('/workspace/attachments/fcfe5bbf-f397-432f-b837-40c0832bb3a7/RCM眼科机器人眼底血管目标的视觉定位与闭环控制.pptx')
PROJECT = BASE / 'project_assets'
PAPER = BASE / 'paper'
SUPP = BASE / 'supplement_assets'
OUT = BASE / 'deliverables'
OUT.mkdir(exist_ok=True)
SUPP.mkdir(exist_ok=True)
FONT = 'Noto Sans SC'
BLUE, LIGHT, DARK, BODY = '4874CB', 'DAE3F5', '0F172A', '475569'
MUTED, CARD, BORDER, WHITE = '64748B', 'F8FAFC', 'CBD5E1', 'FFFFFF'
TEAL, ORANGE, WARN_BG, WARN = '147D92', 'C97928', 'FFF7ED', '92400E'

TIMES = [20,50,70,90,80,60,60,90,35,75,60,75,45]
TITLES = [
 'π0论文阅读与眼底机器人导航策略学习进展',
 '眼底多目标导航任务与当前研究目标',
 'π0：将视觉语言模型用于机器人控制',
 'π0如何生成连续动作块',
 'π0的数据与训练方式对本项目的启发',
 '视觉闭环建立了专家示范生成流程',
 '固定三点导航通过独立终点验收',
 '静态记忆与重观测连接遮挡前后的控制',
 '深度接口与接入后的补充复验',
 '随机多目标任务形成初步示范数据集',
 '从RGB和机器人状态学习下一步ABC动作',
 '视觉信息改善了留出布局的离线动作预测',
 '下一步以闭环导航检验学习策略',
 '实验来源、版本与复现记录',
 '深度接口与本地复验详细结果',
 '训练细节与控制回归检查',
]

SOURCE_MAIN = '项目证据：reports/20261022/meeting；理想RGB-D仿真'
SOURCE_BC = '项目证据：random_policy_overnight_20261022 / round_03'
SOURCE_SUPP = '补充证据：10c4656；primary与local_diagnostic分开统计'
SOURCE_PI = 'Black et al., π0: A Vision-Language-Action Flow Model for General Robot Control, 2024, arXiv:2410.24164'


def color(h):
    return RGBColor.from_string(h)


def style_paragraph(p, text, size=20, bold=False, fill=DARK, align=PP_ALIGN.LEFT):
    p.text = text
    p.alignment = align
    p.space_before = Pt(0)
    p.space_after = Pt(0)
    p.line_spacing = 1.10
    for r in p.runs:
        r.font.name = FONT
        r.font.size = Pt(size)
        r.font.bold = bold
        r.font.color.rgb = color(fill)
        rp = r._r.get_or_add_rPr()
        for tag in ('latin','ea','cs'):
            e = rp.find(qn('a:'+tag))
            if e is None:
                e = OxmlElement('a:'+tag)
                rp.append(e)
            e.set('typeface',FONT)


def set_text(shape, text, size=20, bold=False, fill=DARK, align=PP_ALIGN.LEFT):
    tf=shape.text_frame
    tf.clear()
    tf.word_wrap=True
    tf.auto_size=MSO_AUTO_SIZE.NONE
    tf.vertical_anchor=MSO_ANCHOR.MIDDLE
    tf.margin_left=tf.margin_right=Inches(.02)
    tf.margin_top=tf.margin_bottom=Inches(.01)
    for i,line in enumerate(text.split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        style_paragraph(p,line,size,bold,fill,align)
    return shape


def text(slide,x,y,w,h,value,size=20,bold=False,fill=DARK,align=PP_ALIGN.LEFT):
    sh=slide.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h))
    return set_text(sh,value,size,bold,fill,align)


def shape(slide,x,y,w,h,fill=CARD,line=None,kind=MSO_SHAPE.ROUNDED_RECTANGLE):
    s=slide.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h))
    s.fill.solid(); s.fill.fore_color.rgb=color(fill)
    if line:
        s.line.color.rgb=color(line);s.line.width=Pt(.8)
    else:
        s.line.fill.background()
    if kind==MSO_SHAPE.ROUNDED_RECTANGLE:
        try:s.adjustments[0]=.12
        except Exception:pass
    return s


def box(slide,x,y,w,h,head,body='',fill=CARD,border=None,headsize=21,bodysize=18):
    shape(slide,x,y,w,h,fill,border)
    if body:
        text(slide,x+.14,y+.10,w-.28,.42,head,headsize,True)
        text(slide,x+.14,y+.57,w-.28,h-.66,body,bodysize,False,BODY)
    else:
        text(slide,x+.12,y+.08,w-.24,h-.16,head,headsize,True,align=PP_ALIGN.CENTER)


def line(slide,x1,y1,x2,y2,fill=BLUE,width=2.0,arrow=True,dash=False):
    s=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2))
    s.line.color.rgb=color(fill);s.line.width=Pt(width)
    if dash:
        from pptx.enum.dml import MSO_LINE_DASH_STYLE
        s.line.dash_style=MSO_LINE_DASH_STYLE.DASH
    if arrow:
        e=OxmlElement('a:tailEnd');e.set('type','triangle');s.line._get_or_add_ln().append(e)
    return s


def picture(slide,path,x,y,w,h,alt=''):
    path=Path(path)
    if not path.is_file(): raise FileNotFoundError(path)
    with Image.open(path) as im: iw,ih=im.size
    scale=min(w/iw,h/ih);fw,fh=iw*scale,ih*scale
    s=slide.shapes.add_picture(str(path),Inches(x+(w-fw)/2),Inches(y+(h-fh)/2),Inches(fw),Inches(fh))
    if alt:
        s._element.nvPicPr.cNvPr.set('descr',alt)
    return s


def metric(slide,x,y,w,value,label,fill=BLUE):
    shape(slide,x,y,w,1.02,CARD)
    text(slide,x+.12,y+.06,w-.24,.48,value,30,True,fill,PP_ALIGN.CENTER)
    text(slide,x+.10,y+.60,w-.20,.30,label,16,False,BODY,PP_ALIGN.CENTER)


def takeaway(slide,value,fill=LIGHT,size=19):
    shape(slide,.667,6.12,12.0,.49,fill)
    text(slide,.82,6.15,11.7,.41,value,size,True,DARK)


def source(slide,value):
    text(slide,.73,6.65,11.95,.24,value,10.2,False,MUTED)


def table(slide,x,y,w,h,rows,widths=None,size=17,headsize=17):
    t=slide.shapes.add_table(len(rows),len(rows[0]),Inches(x),Inches(y),Inches(w),Inches(h)).table
    if widths:
        for c,ww in zip(t.columns,widths):c.width=Inches(ww)
    for ri,row in enumerate(rows):
        for ci,val in enumerate(row):
            c=t.cell(ri,ci)
            c.fill.solid();c.fill.fore_color.rgb=color(LIGHT if ri==0 else (WHITE if ri%2==0 else CARD))
            c.margin_left=Inches(.10);c.margin_right=Inches(.08)
            c.margin_top=Inches(.03);c.margin_bottom=Inches(.03)
            c.vertical_anchor=MSO_ANCHOR.MIDDLE
            for tag in ('lnL','lnR','lnT','lnB'):
                e=OxmlElement('a:'+tag);e.set('w','5500')
                sf=OxmlElement('a:solidFill');rgb=OxmlElement('a:srgbClr');rgb.set('val',WHITE);sf.append(rgb);e.append(sf);c._tc.get_or_add_tcPr().append(e)
            tf=c.text_frame;tf.clear();tf.word_wrap=True
            for pi,ss in enumerate(str(val).split('\n')):
                p=tf.paragraphs[0] if pi==0 else tf.add_paragraph()
                style_paragraph(p,ss,headsize if ri==0 else size,ri==0,DARK if ri==0 else BODY)
    return t


def project_image(name):
    for p in [PROJECT/(name+'_ppt.png'),PROJECT/(name+'.png')]:
        if p.is_file():return p
    raise FileNotFoundError(name)


def paper_image(kind):
    manifest=PAPER/'assets.json'
    if manifest.exists():
        d=json.loads(manifest.read_text())
        if isinstance(d,dict):
            wanted='pi0_figure3_framework' if kind=='figure3' else 'pi0_figure13_lower_panel'
            for a in d.get('assets',[]):
                if a.get('id')==wanted and Path(a.get('png','')).is_file():
                    return Path(a['png'])
            for k in (kind,kind+'_path'):
                v=d.get(k)
                if isinstance(v,dict):v=v.get('path') or v.get('file')
                if isinstance(v,str):
                    p=Path(v);p=p if p.is_absolute() else PAPER/p
                    if p.exists():return p
    if kind=='figure3':
        for n in ('pi0_figure3_framework.png','figure3_original.png','figure_3.png','fig3-framework.png'):
            if (PAPER/n).exists():return PAPER/n
    else:
        for n in ('pi0_figure13_lower_panel.png','pi0_figure13_posttraining.png','figure13_original.png','figure_13.png','fig13-post-training.png'):
            if (PAPER/n).exists():return PAPER/n
    raise FileNotFoundError(kind)


def get_supplement(name):
    dest=SUPP/Path(name).name
    src='reports/20261022/oct_three_group_79afacc/'+name
    data=subprocess.check_output(['git','show','10c465607cceea3a298a360746087b58053f920e:'+src],cwd=REPO)
    dest.write_bytes(data)
    return dest


prs=Presentation(str(TEMPLATE))
cover_xml=[deepcopy(s.element) for s in prs.slides[0].shapes]
content_xml=[deepcopy(s.element) for s in prs.slides[6].shapes if s.shape_id in {2,3,4,5,6,7,8,9,25,26,27}]
cover_rels={k:v for k,v in prs.slides[0].part.rels.items() if v.reltype.endswith('/image')}
content_rels={k:v for k,v in prs.slides[6].part.rels.items() if v.reltype.endswith('/image')}
layout=prs.slides[6].slide_layout
for sid in list(prs.slides._sldIdLst):
    prs.part.drop_rel(sid.rId);prs.slides._sldIdLst.remove(sid)
SLIDE_RECORDS=[]


def add_slide(n,section,title=None):
    s=prs.slides.add_slide(layout)
    for sh in list(s.shapes):s.shapes._spTree.remove(sh.element)
    elements,rels=(cover_xml,cover_rels) if n==1 else (content_xml,content_rels)
    mapping={rid:s.part.relate_to(rel.target_part,rel.reltype) for rid,rel in rels.items()}
    for e in elements:
        el=deepcopy(e)
        for node in el.iter():
            for k in list(node.attrib):
                if k in (qn('r:embed'),qn('r:id'),qn('r:link')) and node.attrib[k] in mapping:
                    node.attrib[k]=mapping[node.attrib[k]]
        s.shapes._spTree.insert_element_before(el,'p:extLst')
    shapes={sh.shape_id:sh for sh in s.shapes}
    if n!=1:
        sec='01' if n<=5 else '02' if n<=10 else '03' if n<=13 else '附'
        set_text(shapes[7],sec,24,True,WHITE,PP_ALIGN.CENTER)
        shapes[9].width=Inches(9.1)
        set_text(shapes[9],title or TITLES[n-1],29,True,DARK)
        set_text(shapes[25],section,11,False,MUTED)
        set_text(shapes[26],'π0论文阅读 · 眼底导航策略学习',11,False,MUTED,PP_ALIGN.CENTER)
        set_text(shapes[27],f'{n:02d} / 13' if n<=13 else f'B{n-13} / 3',11,True,MUTED,PP_ALIGN.RIGHT)
    SLIDE_RECORDS.append({'page':n,'title':title or TITLES[n-1],'section':section,'seconds':TIMES[n-1] if n<=13 else None,'source':[]})
    return s


def notes(s,n,script,sources):
    SLIDE_RECORDS[n-1]['speaker_notes']=script
    SLIDE_RECORDS[n-1]['source']=sources
    dur=f'建议讲述：{TIMES[n-1]}秒。' if n<=13 else '备份页，不计入正文讲述时间。'
    s.notes_slide.notes_text_frame.text=dur+'\n\n'+script+'\n\n资料与边界：\n'+'\n'.join(sources)


# 1 — retain the actual cover geometry, gradient and logo.
s=add_slide(1,'论文阅读与阶段进展')
ss={sh.shape_id:sh for sh in s.shapes}
ss[5].left=Inches(.82);ss[5].top=Inches(2.00);ss[5].width=Inches(7.9);ss[5].height=Inches(1.80)
set_text(ss[5],'π0 论文阅读与\n眼底机器人导航策略学习进展',35,True,WHITE)
ss[6].left=Inches(.84);ss[6].top=Inches(4.20);ss[6].width=Inches(7.9);ss[6].height=Inches(.55)
set_text(ss[6],'论文建模思路 → 专家示范 → 数据与离线训练 → 闭环检验',17,False,WHITE)
set_text(ss[8],'汇报人：杨淏博',18,False,'143295')
set_text(ss[10],'日期：2026.10.23',18,False,'143295')
cover_rgb=REPO/'reports/20261022/meeting/rawframes/strict_three_ep000000_frame001288.png'
picture(s,cover_rgb,9.0,2.00,3.55,2.70,'严格视觉三点实验的原始RGB，仿真传感器图像')
text(s,9.0,4.77,3.55,.26,'原始传感器RGB · MuJoCo仿真',11,False,WHITE,PP_ALIGN.CENTER)
notes(s,1,'本次汇报围绕一个目标展开：学习π0如何建模机器人策略，建立能够产生合格示范的导航系统，完成初步数据采集与离线训练，再用闭环实验检验学习策略。先用三页介绍π0，再汇报本项目的实验基础和下一步问题。',[SOURCE_PI,str(cover_rgb)])

# 2 — editable schematic, not a synthetic experimental rendering.
s=add_slide(2,'任务定义与研究目标')
shape(s,.70,1.40,6.50,4.45,WHITE,BORDER)
shape(s,2.13,1.75,3.55,3.55,LIGHT,BLUE,MSO_SHAPE.OVAL)
shape(s,3.77,1.90,.12,.12,BLUE,None,MSO_SHAPE.OVAL)
line(s,3.83,1.96,4.72,4.70,BLUE,4,False)
line(s,3.83,1.96,3.35,1.02,BODY,3,False)
for x,y,label in [(4.68,4.65,'P1'),(3.58,4.86,'P2'),(2.78,4.48,'P3')]:
    shape(s,x,y,.14,.14,ORANGE,None,MSO_SHAPE.OVAL);text(s,x+.13,y-.12,.55,.38,label,17,True,ORANGE)
text(s,.94,2.02,1.32,.50,'固定 RCM',20,True,BLUE);line(s,2.22,2.26,3.76,2.02,BLUE,1.4)
text(s,4.93,3.17,1.7,.5,'针尖 / 针轴',18,True);line(s,4.95,3.63,4.47,3.96,BODY,1.4)
text(s,1.02,5.10,5.66,.50,'眼球后部椭球表面作为眼底代理',18,False,BODY,PP_ALIGN.CENTER)
text(s,.98,1.46,3.8,.26,'任务几何示意 · 不按比例',12,False,MUTED)
box(s,7.55,1.43,5.05,1.17,'给定顺序的连续导航','随机3点 / 5点，目标逐个呈现',headsize=23,bodysize=19)
box(s,7.55,2.85,5.05,1.17,'终点验收 <20 μm','同时检查停稳、速率与失败原因',headsize=23,bodysize=19)
box(s,7.55,4.27,5.05,1.17,'本阶段聚焦策略学习基础','观测稳定性 · 遮挡 · 跨布局控制',headsize=22,bodysize=19)
takeaway(s,'当前验证对象：仿真目标点导航；多病灶识别、真实穿刺另行研究。',size=18)
source(s,SOURCE_MAIN)
notes(s,2,'任务是在固定RCM约束下，按给定顺序完成随机三点或五点导航。目标放在眼球后部椭球表面，用它作为眼底代理；当前逐个呈现目标，没有验证多病灶识别和自主排序。验收要求独立终点误差低于20微米，并检查停稳和运动约束。三个实际困难是观测不足、遮挡，以及从固定场景转向不同布局。',[SOURCE_MAIN,'示意图为原生PPT对象，不按比例，不是实验重建结果。'])

# 3 — original paper figure.
s=add_slide(3,'π0论文阅读')
picture(s,paper_image('figure3'),.75,1.40,11.85,3.40,'π0论文Figure 3原图：视觉语言模型与动作专家的总体框架')
for x,h,b in [( .72,'PaliGemma VLM ≈3B','图像与语言表征'),(4.82,'动作专家 ≈300M','处理状态与带噪动作'),(8.92,'输出连续动作块','联合建模未来H步动作')]:
    box(s,x,5.03,3.70,.90,h,b,headsize=20,bodysize=17)
takeaway(s,'π0把视觉语言表征与连续动作生成连接起来。',size=20)
source(s,'原论文 Figure 3；'+SOURCE_PI)
notes(s,3,'π0面向通用机器人控制，将图像、语言任务与机器人状态共同作为条件。图中视觉语言骨干承担视觉与任务表征，动作专家负责生成连续控制量；两者通过模型结构中的注意力交互连接。这不是把大语言模型的文字输出直接当作机器人动作。论文将来自不同机器人与任务的数据组织到同一个策略框架，动作专家再学习连续动作分布。这里阅读的是2024年的π0，不混入π0.5的后续设计。',[SOURCE_PI,'原论文Figure 3；图片文件 '+str(paper_image('figure3'))])

# 4 — all process nodes, equation text and action tiles remain editable.
s=add_slide(4,'π0论文阅读')
text(s,.80,1.34,8.4,.48,'动作块：一次预测未来一段动作',24,True)
for i,lbl in enumerate(['aₜ','aₜ₊₁','aₜ₊₂','…','aₜ₊H₋₁']):
    box(s,.84+i*2.12,1.98,1.84,.72,lbl,fill=LIGHT if i!=3 else CARD,headsize=25)
text(s,.88,2.78,11.4,.42,'论文采用H=50；按执行协议重新观测与推理，动作块不等于全程开环。',19,False,BODY)
shape(s,.73,3.45,5.80,2.23,CARD)
text(s,.94,3.56,5.34,.45,'训练：学习条件速度场',24,True)
text(s,.94,4.06,5.34,.58,'L = E ‖vθ(Aτ, o, τ) − (A − ε)‖²',22,False,DARK,PP_ALIGN.CENTER)
text(s,.98,4.82,5.25,.61,'用示范动作与噪声构造中间状态\n监督从噪声流向动作的方向',18,False,BODY)
shape(s,6.80,3.45,5.80,2.23,CARD)
text(s,7.01,3.56,5.34,.45,'推理：由噪声积分为动作块',24,True)
for x,lab in [(7.00,'噪声'),(8.92,'迭代更新'),(10.84,'动作块')]:
    box(s,x,4.28,1.42,.73,lab,fill=LIGHT,headsize=20)
line(s,8.44,4.64,8.87,4.64);line(s,10.36,4.64,10.79,4.64)
text(s,7.02,5.12,5.18,.45,'10步Euler；ε为高斯噪声\no为观测条件，Aτ为中间动作',15.5,False,BODY)
takeaway(s,'τ=0为噪声，τ=1为动作；H=50是块长度，不是50次完整模型推理/秒。',size=17)
source(s,SOURCE_PI+'；线性插值路径的Flow Matching示意')
notes(s,4,'动作块表示一次预测未来一段连续动作，而不是只输出下一步。π0采用H等于50，但并非50步全执行完才反馈：附录中的20Hz平台执行16步后重新推理，50Hz平台执行25步。Flow Matching训练从真实示范与高斯噪声构造中间状态，在观测条件下预测动作空间的速度场。τ从0到1，Aτ等于一减τ乘噪声加τ乘真实动作，目标方向为A减ε。推理从噪声出发，用学习到的速度场做10步前向Euler积分，得到动作块。10个积分步、50步动作块与最高50Hz执行频率是不同概念。这个生成目标也不同于本项目目前的单步动作回归。',[SOURCE_PI,'原论文§IV和附录B/D；显式补写τ作为条件变量，便于讲解。'])

# 5 — exact experiment asset chosen from the paper, with editable mapping table.
s=add_slide(5,'π0论文阅读')
text(s,.80,1.32,5.95,.46,'预训练广覆盖，后训练适配任务',22,True)
picture(s,paper_image('experiment'),.77,1.98,5.97,3.42,'π0原论文Figure13下半图，平均任务进度，每任务10次；Packing Eggs保留例外')
text(s,.88,5.42,5.84,.53,'Figure 13下半图：平均任务进度，非成功率\n每任务10次；Packing Eggs中scratch略高。',15.5,False,BODY)
table(s,7.00,1.47,5.62,4.15,[
 ['方面','π0','本项目当前'],
 ['输入','图像、语言、状态','RGB、特征、ABC'],
 ['输出','连续动作块','单步 ΔABC'],
 ['模型','预训练VLM＋动作专家','轻量CNN＋MLP'],
 ['数据','多样机器人＋任务示范','随机多目标示范'],
 ['验证','机器人任务实验','专家闭环 / 策略离线'],
],widths=[.66,2.37,2.59],size=16.8,headsize=17)
takeaway(s,'研究问题：RGB＋状态策略能否降低运行时理想深度依赖，并完成留出布局闭环？',size=17)
source(s,'原论文Figure13（下半图）；'+SOURCE_PI)
notes(s,5,'π0给本项目的启发是数据和训练配方：多样化预训练获得广覆盖，目标任务后训练使执行更熟练。左图为Figure13下半图，保留fine-tuned、scratch和out-of-box对照；纵轴是每任务10次评估的平均任务进度，不是成功率。总体上两阶段组合在多数复杂任务更好，但装鸡蛋任务中scratch略高，说明不是所有任务都最优。这也不是隔离数据质量单项因素的因果实验。对应到本项目，目前先用可追溯的专家闭环采随机多目标示范，训练轻量RGB加状态基线，输出单步ABC增量，并无语言、VLM或Flow Matching。下一步先检验减少运行时理想深度依赖后，能否在留出布局完成闭环，再考虑动作块等方向。',[SOURCE_PI,'Figure13；平均任务进度，每任务10次。scratch意为未使用机器人预训练，不能说完全无预训练。',SOURCE_BC])

# 6 — expert control and evaluation are deliberately separate.
s=add_slide(6,'专家闭环与示范生成')
for x,h,b in [( .76,'RGB／理想深度','当前传感器观测'),(3.87,'针尖／目标测量','几何视觉重建'),(6.98,'受限视觉伺服','中心差分与反馈'),(10.09,'ABC执行','限速、限加速度')]:
    box(s,x,1.66,2.50,1.16,h,b,headsize=20,bodysize=17)
for x in [3.28,6.39,9.50]:line(s,x,2.24,x+.51,2.24)
line(s,11.32,2.85,11.32,3.25);line(s,11.32,3.25,2.02,3.25,arrow=False);line(s,2.02,3.25,2.02,2.87)
text(s,4.25,3.34,4.25,.35,'执行后重新观测，形成闭环',17,False,BLUE,PP_ALIGN.CENTER)
box(s,.78,3.83,5.56,1.30,'故障修正：中心差分','同一故障姿态，AB雅可比秩 1 → 2',headsize=22,bodysize=20)
box(s,6.61,3.83,5.96,1.30,'可观测性修正：提高分辨率','同一回放帧，针尖可见像素 0 → 1',headsize=22,bodysize=20)
text(s,.96,5.45,7.65,.44,'局部故障证据；尚未完成整任务单因素消融。',18,False,BODY)
box(s,9.04,5.36,3.51,.49,'场景真值 → 独立验收',fill='EEF0F3',headsize=16)
takeaway(s,'控制依据视觉测量；独立真值用于验收，示教日志用于后续学习。',size=19)
source(s,SOURCE_MAIN+'；局部故障证据来自用户提供的实验日志')
notes(s,6,'为训练策略，先建立能够产生合格示范的专家流程。RGB与理想深度经过测量，进入受限视觉伺服，再执行ABC动作并重新采图。场景目标真值不进入严格视觉控制目标，而作为独立验收支路。两个具体修正是：采用正负扰动中心差分，恢复像素量化下失去的雅可比方向；提高实际渲染分辨率，改善针尖不可见问题。这些有同姿态或同帧的直接证据，但不能把整体精度改善全部归因于其中某一项。',[SOURCE_MAIN,'用户提供的48条实验日志：中心差分故障姿态及2×分辨率同帧回放。'])

# 7 — two verified plots plus the stop gate.
s=add_slide(7,'专家闭环与示范生成')
picture(s,project_image('strict_three_executed_trajectory'),.72,1.38,7.18,4.34,'严格三点专家实际执行轨迹，非规划路径')
picture(s,project_image('strict_three_endpoint_errors'),8.10,1.43,4.45,3.46,'三个独立终点误差与20微米阈值')
text(s,8.23,5.07,4.20,.53,'每点停稳：≥3帧零指令速度',18,True,BLUE)
takeaway(s,'1个episode · 3个目标全部通过；最大独立终点误差6.634 μm。',size=20)
source(s,SOURCE_MAIN+' / strict_three；场景真值仅用于验收')
notes(s,7,'这是一个固定三点任务，不是三次独立重复实验。左图来自实际执行轨迹，能看到跨点回撤、转向和接近；右图给出独立三维终点误差：6.634、6.085和6.268微米，都低于20微米。每点还通过至少三帧零指令速度的停稳验收，速率和边界检查也通过。这里验证的是理想RGB-D条件下专家视觉控制器的能力，后续学习策略的结果不能直接使用这些终点精度。',[SOURCE_MAIN,'reports/20261022/meeting/evidence/strict_three/visual_servo/trajectory.csv','reports/20261022/meeting/endpoint_metrics.csv'])

# 8 — old paired occlusion episode only; never mix with new OCT replay.
s=add_slide(8,'专家闭环与遮挡恢复')
states=['可见跟踪','短时记忆','受限回撤\n重观测','恢复跟踪']
for i,lab in enumerate(states):
    box(s,.77+i*1.93,1.45,1.65,.83,lab,fill=LIGHT,headsize=19)
    if i<3:line(s,2.44+i*1.93,1.87,2.65+i*1.93,1.87,width=1.5)
frame_manifest=PROJECT/'recovery_frames_provenance.json'
if frame_manifest.exists():
    fm=json.loads(frame_manifest.read_text())
    items=fm.get('items',fm.get('frames',[])) if isinstance(fm,dict) else fm
else:items=[]
fallback=[('遮挡前','strict_occlusion_recovery_ep000000_frame000000.png'),('遮挡期间','strict_occlusion_recovery_ep000000_frame000028.png'),('最终到达','strict_occlusion_recovery_ep000000_frame000668.png')]
for i in range(3):
    if i<len(items):
        it=items[i];p=Path(it.get('path',it.get('export_rgb',it.get('file',''))));p=p if p.is_absolute() else PROJECT/p
        lab=['遮挡前','遮挡中：回撤','重获后：恢复跟踪'][i]
    else:
        lab,fn=fallback[i];p=REPO/'reports/20261022/meeting/rawframes'/fn
    picture(s,p,.79+i*2.48,2.73,2.25,2.05,lab+'；旧配对recovery实验')
    text(s,.79+i*2.48,4.82,2.25,.44,lab,17,True,BODY,PP_ALIGN.CENTER)
table(s,8.55,1.48,4.05,2.40,[['组别','完成/计划'],['stop','0 / 3'],['恢复','3 / 3']],widths=[2.22,1.83],size=21,headsize=19)
text(s,8.67,4.07,3.88,.84,'恢复组最大误差 6.442 μm\n24个记忆帧 · 1次恢复',18,True,BLUE)
text(s,.93,5.48,11.65,.43,'同一reset与遮挡计划；固定相机、静态目标，针尖仍需新鲜测量。',17,False,BODY)
takeaway(s,'stop仅尝试P1，P2/P3未运行；瞬停加速度约束失败。仅1对固定场景。',fill=WARN_BG,size=17)
source(s,SOURCE_MAIN+' / strict_occlusion_stop 与 strict_occlusion_recovery；pre-OCT')
notes(s,8,'遮挡恢复采用静态目标记忆与重观测。目标可见时积累可靠测量，短时遮挡使用受限记忆；持续失观测时受限回撤并重新观测，连续有效后恢复。条件是相机固定、目标静态，而且针尖必须仍有新鲜观测。这里展示旧的同源配对实验：两组使用相同reset、目标和实体遮挡计划。stop在P1失去目标后中止，仅尝试一个目标，后两个没有运行；恢复组完成三点，最大误差6.442微米，使用24个记忆帧和一次恢复。stop还未通过独立加速度约束，所以不能称为安全制动。这个结果只支持该固定场景的可行性，不是统计成功率。',[SOURCE_MAIN,'旧同源配对primary实验，完成于OCT包装接口接入前；图帧与6.442微米指标来自对应episode。'])

# 9 — local replay with real registered depth assets; failures remain visible.
s=add_slide(9,'深度接口与补充复验')
depth_figure=get_supplement('figures/figure_06_P3_depth_audit.png')
picture(s,depth_figure,.73,1.52,7.28,3.74,'local_diagnostic C/P3原始RGB、理想注册深度与有效区域')
text(s,.90,5.42,7.00,.36,'深度 · mask · frame ID · 时间戳；完整深度保存阶段末帧',16,False,BODY)
table(s,8.30,1.50,4.30,3.70,[['本地复验','结果'],['A：无遮挡','P1 23.506 μm\n精度FAIL'],['B：stop','P1失观测FAIL\nP2/P3未运行'],['C：恢复','3/3通过\n10.43–11.24 μm']],widths=[1.73,2.57],size=18,headsize=19)
takeaway(s,'MuJoCo理想注册深度；无真实OCT／A/B-scan；本地三组非严格同条件对照。',size=17)
source(s,SOURCE_SUPP+'；169文件/12阶段归档审计PASS不改变导航结局')
notes(s,9,'深度接口记录深度、有效区域、帧ID和时间戳。这里展示接入接口后的本地复验，和前一页的旧配对实验分别呈现。本地A在23.506微米处未通过精度验收，B失观测中止，C完成三点，误差约10到11微米。补充包已经归档审计通过并发布，但三组初始条件不完全相同，不能作为严格公平对照。当前是MuJoCo理想注册深度，不是真实OCT。',[SOURCE_SUPP,'reports/20261022/oct_three_group_79afacc/metrics.json local_diagnostic','原primary三组不含OCT日志；原图figure06来自本地C/P3。'])

# 10 — real randomized layouts and native split table.
s=add_slide(10,'随机示范数据集')
picture(s,project_image('real_three_five_layouts'),.71,1.43,6.58,3.52,'来自已采集episode的真实随机3点与5点布局')
metric(s,7.58,1.43,2.36,'16 / 19','专家任务合格')
metric(s,10.18,1.43,2.36,'26,705','合格RGB帧')
table(s,7.56,2.79,5.02,2.10,[['划分','episode','帧'],['训练','12','20,075'],['验证','2','3,184'],['测试','2','3,446']],widths=[1.44,1.53,2.05],size=17.5,headsize=17)
sample=json.loads((PROJECT/'aligned_sample.json').read_text())
shape(s,.77,5.12,11.80,.79,CARD)
picture(s,PROJECT/'aligned_rgb_frame_000010.png',.85,5.17,.86,.65,'真实对齐样本：0.50秒的原始RGB')
text(s,1.86,5.16,10.48,.31,'真实样本 t=0.50s：ABCₜ=[−1.30°, 0.65°, 0.00mm] → a_abs=[−1.50°, 0.75°, 0.00mm]',15.7,False,BODY)
text(s,1.86,5.53,10.48,.29,'日志存下一步绝对命令；训练标签 ΔABC≈[−0.20°, 0.10°, 0.00mm]，并核对下一帧状态。',15.7,False,BODY)
takeaway(s,'合格示教64个目标全部停稳，最大误差14.981 μm；3次失败完整保留。',size=18)
source(s,SOURCE_BC+'；按完整布局拆分，禁止相邻帧随机拆分')
notes(s,10,'在固定场景可行后，进一步随机设置三点或五点布局。共尝试19个任务，16个合格、三个失败。所有尝试保存30441张RGB，其中合格训练集合计26705帧；按完整任务和布局划分为12个训练、两个验证、两个测试episode，避免相邻帧泄漏。合格示教包含64个目标，都到达并停稳，最大独立误差14.981微米。三个失败保留在原始记录中，没有作为成功示范混入训练。下方展示数据对齐关系；每条样本可追溯RGB、状态、动作和下一帧状态。这里的精度仍属于专家。',[SOURCE_BC,'project_assets/sources_and_values.json','project_assets/aligned_sample.json：保留真实值和来源；图中布局坐标仅用于场景展示与验收。'])

# 11 — editable network flow, not π0 implementation.
s=add_slide(11,'单步监督模仿学习')
box(s,.76,1.63,3.12,1.50,'图像输入','全局RGB＋局部ROI\n96×96 / 64×64',headsize=22,bodysize=19)
box(s,.76,4.01,3.12,1.40,'数值输入','ABC＋RGB提取特征\n中心坐标／可见性',headsize=22,bodysize=18)
box(s,4.57,1.83,2.30,1.10,'共享CNN','两幅图像编码',headsize=21,bodysize=18)
box(s,4.57,4.03,2.30,1.30,'数值处理','ABC标准化\nRGB特征直传',headsize=21,bodysize=16)
box(s,7.65,2.83,2.00,1.12,'特征拼接','图像＋数值',headsize=21,bodysize=18)
box(s,10.37,2.83,2.20,1.12,'动作MLP','单步 ΔABC',headsize=21,bodysize=20)
line(s,3.90,2.38,4.50,2.38);line(s,3.90,4.60,4.50,4.60)
line(s,6.90,2.38,7.57,3.17);line(s,6.90,4.60,7.57,3.60);line(s,9.68,3.40,10.28,3.40)
text(s,4.45,5.47,8.15,.44,'监督标签：下一帧ABC − 当前ABC；按实际时间间隔加权。',18,False,BODY)
takeaway(s,'当前为单步行为克隆基线；深度、分割、phase、目标ID及场景真值不入策略。',size=17)
source(s,SOURCE_BC+'；非π0复现，尚未使用VLM、动作块或Flow Matching')
notes(s,11,'当前模型是轻量单步监督模仿学习基线。共享CNN分别编码96乘96的全局RGB和64乘64的目标局部图像。随后拼接图像特征、标准化后的ABC状态，以及RGB中心和可见性数值特征，经动作MLP输出归一化的下一步ABC增量。RGB数值特征不作为卷积输入，模型也没有独立的状态MLP编码器。监督标签由专家日志中下一帧状态减当前状态构造，图像与动作时间对齐已经检查；损失按实际时间间隔加权。策略不读取仿真深度、分割、场景目标真值、控制阶段或目标ID。这不是π0复现；先验证视觉信息与数据流程，再考虑动作块和Flow Matching。',[SOURCE_BC,'rcm_imitation_data.py；rcm_behavior_policy.py:105–141；train_behavior_cloning.py'])

# 12 — offline metric only; explicit C-axis limitation.
s=add_slide(12,'策略离线测试')
picture(s,project_image('heldout_action_mse'),.73,1.44,7.72,4.40,'四种方法在两个留出布局上的时间加权归一化一步动作MSE')
metric(s,8.78,1.55,3.76,'41.8%','相对仅状态MSE下降')
table(s,8.78,3.00,3.76,1.82,[['C轴动作MAE','μm'],['仅状态','10.472'],['RGB＋状态','11.162']],widths=[2.25,1.51],size=17,headsize=16)
text(s,8.92,5.01,3.51,.63,'C轴未改善\n动作误差 ≠ 终点误差',18,True,WARN)
takeaway(s,'仅2个留出测试episode；学习策略闭环到达率和<20 μm终点精度尚未评估。',fill=WARN_BG,size=17)
source(s,SOURCE_BC+'；验证集选模，最终测试未参与选择')
notes(s,12,'最终按验证集选择第三轮模型，再对留出的两个布局做一次独立测试：一个三点任务、一个五点任务。时间加权归一化一步动作MSE，RGB加状态是0.1203，仅状态是0.2067，相对下降41.8%；zero-hold和状态最近邻也作为对照。收益主要来自A、B方向，C轴动作MAE为11.162微米，仍略高于仅状态的10.472微米，因此不能笼统地说每个轴都改善。测试只包含两个episode，且是离线预测；模型尚未放入闭环，不能由这个MSE推导到达率或20微米终点精度。',[SOURCE_BC,'round_03/training_report.json；round_03/test_comparison.csv','C轴单位由毫米乘1000换为微米，仅用于动作MAE。'])

# 13 — the next experiment answers the stated research question.
s=add_slide(13,'下一步实验')
for x,num,h,b in [( .77,'1','统一协议','冻结代码版本、初始条件\n与独立随机测试布局'),(4.85,'2','策略闭环','同批任务配对比较\n专家与RGB＋状态策略'),(8.93,'3','困难条件扩展','扩大遮挡、深度噪声\n及观测／执行延迟')]:
    box(s,x,1.74,3.64,2.32,num+'  '+h,b,fill=LIGHT if num=='2' else CARD,headsize=25,bodysize=21)
line(s,4.44,2.89,4.79,2.89);line(s,8.52,2.89,8.87,2.89)
table(s,.86,4.54,11.62,1.02,[['闭环完成率','独立三维终点误差','停稳与约束违例','失败原因'],['整任务与逐目标','均值／最大值／<20 μm','每目标、每任务记录','完整保留']],widths=[2.70,3.15,3.11,2.66],size=18,headsize=18)
takeaway(s,'下一次要回答：减少运行时理想深度依赖后，策略还能否完成留出布局导航？',size=18)
source(s,'实验计划；尚未产生学习策略闭环结果')
notes(s,13,'下一步先统一代码、初始条件和测试布局，再把学习策略真正放到闭环里，与专家在同一批任务上配对比较。主要指标是整任务完成率、独立三维终点误差、停稳和约束违例，同时保留所有失败。基础闭环通过后，再扩大遮挡、噪声和延迟条件。π0的动作块与Flow Matching可以作为后续模型方向，但当前优先回答一个具体问题：减少运行时理想深度依赖后，RGB加状态策略能否在留出布局完成导航。',['用户确认的下一步实验目标；无新的性能结果。'])

# B1 — native provenance table, not a claim of identical acquisition code.
s=add_slide(14,'备份 · 来源与复现')
table(s,.78,1.45,11.82,2.42,[['用途','分支／提交','材料与边界'],['主线基线','main / 79afacc','严格视觉、OCT仿真接口及已有报告'],['补充实验','experiment/oct-three-group-79afacc\n10c4656','primary与local_diagnostic分开；归档审计PASS'],['训练成果','download-random-fundus-bc-20261023\n8683b76','代码、三轮模型、报告ZIP；完整原始RGB未打包']],widths=[1.55,5.05,5.22],size=16.8,headsize=18)
box(s,.81,4.16,5.66,1.36,'每次采集需绑定','运行ID · 源码哈希 · 初始姿态\n目标布局 · 传感器模式 · 验收条件',headsize=21,bodysize=18)
box(s,6.80,4.16,5.66,1.36,'发布版本 ≠ 采集版本','local fallback说明保留；\n分支父提交不能追认全部采集同源。',headsize=21,bodysize=18)
takeaway(s,'48条工作日志不是48次导航；复制、归档与复核不增加独立实验次数。',size=18)
source(s,'远端分支与提交已核对；补充包provenance.json；主报告不展示上传代理配置')
notes(s,14,'补充包的发布提交是10c4656，基于79afacc，main未改动。发布版本可核验，但包内仍保留采集时未核验提交、使用local fallback的说明，因此不能以分支父提交反向证明所有实验使用相同采集代码。复现时按运行ID、源码哈希、配置和初始条件对应。日志中的编译、复核与复制材料不算新增导航。',['https://github.com/jsonyang218-pixel/rcm-mujoco-reference','10c4656:reports/20261022/oct_three_group_79afacc/provenance.json'])

# B2 — all six rows remain visible, primary versus local replay.
s=add_slide(15,'备份 · 深度与补充复验')
table(s,.76,1.45,11.85,3.22,[['来源','组别','完成/计划','独立验收／失败'],['primary（pre-OCT）','A / B / C','3/3 · 0/3 · 3/3','A最大6.634；C最大6.442 μm；B仅尝试P1'],['local_diagnostic','A：无遮挡','0/3','P1 23.506 μm；P2/P3未运行'],['local_diagnostic','B：stop','0/3','P1目标不可见；P2/P3未运行；加速度FAIL'],['local_diagnostic','C：恢复','3/3','10.917 / 10.434 / 11.244 μm']],widths=[2.41,2.16,1.77,5.51],size=16.8,headsize=18)
box(s,.80,4.98,5.65,.81,'保存：JSONL序列元数据＋各阶段末帧完整深度',fill=CARD,headsize=17)
box(s,6.79,4.98,5.65,.81,'渲染中位0.471秒/帧：未支持实际20 Hz',fill=WARN_BG,headsize=17)
takeaway(s,'12阶段／12 NPZ归档检查通过；理想注册深度，不包含真实OCT噪声或A/B-scan。',size=17)
source(s,'10c4656: metrics.json、oct_audit.json；接口数值10组、传感器12组检查')
notes(s,15,'本页把原始三组和接入OCT包装接口后的本地复验分开。原始A/C成功、B失败，旧三组本身没有OCT序列日志；本地A/B失败、C成功。阶段完整深度只留末帧，JSONL保存序列元数据，不能说每帧完整原始OCT都已采集。记录的渲染中位为0.471秒每帧，不能由名义20Hz采样频率推导真实实时能力。审计PASS只说明所覆盖的归档检查通过。',[SOURCE_SUPP,'reports/20261022/oct_p1_final/oct_closed_loop_verification.json'])

# B3 — training protocol plus honest non-ablation caveat.
s=add_slide(16,'备份 · 训练与回归')
table(s,.77,1.44,7.19,2.50,[['轮次','训练episode','RGB验证MSE','状态验证MSE'],['1','4','0.148889','0.185904'],['2','8','0.139064','0.185806'],['3','12','0.111807','0.174239']],widths=[.74,1.93,2.26,2.26],size=18,headsize=17)
box(s,8.26,1.47,4.32,2.45,'归一化与加权','动作尺度：0.2° / 0.1° / 0.03 mm\n按实际Δt加权\n验证集选模；测试仅最终评估',headsize=21,bodysize=17.5)
text(s,.96,4.26,11.35,.63,'三轮同时改变数据量、随机种子和epoch上限，不能当作单因素规模消融。',19,True,WARN)
text(s,.96,5.08,11.35,.57,'控制回归：中心差分故障姿态、分辨率同帧回放；RRT/PRM失观测闭锁不代表规划成功。',17.5,False,BODY)
takeaway(s,'离线动作误差与导航终点误差分别验收；训练曲线和原始报告随材料提供。',size=18)
source(s,SOURCE_BC+'；制作辅助：scientific-slides v1.12 / Supervisor-Skills（版本见说明）')
notes(s,16,'验证集随递增训练数据的三轮结果如表，第三轮最佳，但数据量、种子和epoch上限同时变化，因此只能描述实际训练过程，不能作为纯数据规模消融。归一化尺度为A0.2度、B0.1度、C0.03毫米，损失按实际时间间隔加权，测试集未参与选择。局部控制回归与规划失观测闭锁检查分别列出。制作使用scientific-slides和Supervisor-Skills辅助，软件来源见随附来源与审查文件，它们不是性能结果来源。',[SOURCE_BC,'Scientific Slides v1.12, K-Dense, commit593377bb048752abb0152deab9fbb1083a6087df','Supervisor-Skills, HKUSTDial, commita20d76ef3979b804d7dbf599d577826957e0a8a9'])

assert len(prs.slides)==16
assert sum(TIMES)==810 and sum(TIMES[2:5])==240
prs.core_properties.title='π0论文阅读与眼底机器人导航策略学习进展'
prs.core_properties.subject='13页主报告＋3页备份；正文13分30秒；π0三页4分钟'
prs.core_properties.author='杨淏博'
prs.core_properties.keywords='π0, RCM, 视觉导航, 遮挡恢复, 行为克隆, 仿真'
output=OUT/'pi0_rcm_navigation_meeting_20261023.pptx'
prs.save(str(output))
(BASE/'slide_manifest.json').write_text(json.dumps({'main_slides':13,'backup_slides':3,'planned_seconds':810,'paper_seconds':240,'records':SLIDE_RECORDS},ensure_ascii=False,indent=2))
lines=['# 讲者备注与计时','正文13:30；π0部分4:00；另预留1:30用于翻页、指图和补充。','']
elapsed=0
for r in SLIDE_RECORDS:
    if r['seconds'] is not None:
        elapsed+=r['seconds'];time=f"{r['seconds']}秒；累计{elapsed//60}:{elapsed%60:02d}"
    else:time='备份'
    lines.extend([f"## {r['page']}. {r['title']}（{time}）",r['speaker_notes'],'','资料：'+'；'.join(r['source']),''])
(OUT/'speaker_notes_讲稿与计时.md').write_text('\n'.join(lines))
print('PPTX',output)
print('SLIDES',len(prs.slides),'MAIN_SECONDS',sum(TIMES),'PI0_SECONDS',sum(TIMES[2:5]))
