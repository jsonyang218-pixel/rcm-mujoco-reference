#!/usr/bin/env python3
"""Deterministic meeting figures. Reads existing evidence; never runs navigation."""
from pathlib import Path
import csv
import hashlib
import json
import os
import shutil
from collections import Counter

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/rcm-mujoco-reference')
os.environ['MPLCONFIGDIR'] = str(OUT / '.mplconfig')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Ellipse, FancyBboxPatch

BLUE = '#4874CB'
DARK = '#0F172A'
BODY = '#475569'
PALE = '#DAE3F5'
CARD = '#F8FAFC'
COLORS = [BLUE, '#8EA8DD', '#234D91']
font_manager.fontManager.addfont(str(OUT / 'NotoSansSC-Regular-static.ttf'))
if (OUT / 'NotoSansSC-Bold-static.ttf').exists():
    font_manager.fontManager.addfont(str(OUT / 'NotoSansSC-Bold-static.ttf'))
plt.rcParams.update({
    'font.family': 'Noto Sans SC', 'font.size': 18,
    'axes.labelsize': 18, 'axes.titlesize': 21,
    'xtick.labelsize': 16, 'ytick.labelsize': 16,
    'text.color': DARK, 'axes.labelcolor': BODY,
    'axes.edgecolor': '#CBD5E1', 'xtick.color': BODY, 'ytick.color': BODY,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.unicode_minus': False, 'pdf.fonttype': 42, 'ps.fonttype': 42,
    'svg.fonttype': 'none', 'svg.hashsalt': 'pi0_rcm_meeting_20261023', 'savefig.facecolor': 'white',
    'figure.facecolor': 'white', 'axes.facecolor': 'white',
})

SOURCES = {}
def read_json(rel):
    p = ROOT / rel
    SOURCES[rel] = {'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    return json.loads(p.read_text(encoding='utf-8-sig'))

def read_csv(rel):
    p = ROOT / rel
    SOURCES[rel] = {'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def save(fig, name):
    for ext in ('png', 'pdf', 'svg'):
        metadata = {'Date': None} if ext == 'svg' else {'CreationDate': None, 'ModDate': None} if ext == 'pdf' else {}
        fig.savefig(OUT / f'{name}.{ext}', dpi=220, bbox_inches='tight', pad_inches=.08, metadata=metadata)
    plt.close(fig)

def grid(ax, axis='y'):
    ax.set_axisbelow(True)
    ax.grid(axis=axis, color='#E2E8F0', lw=.8)

meeting = 'reports/20261022/meeting'
strict = meeting + '/evidence/strict_three'
run = 'runs/random_policy_overnight_20261022'
endpoint_rows = [r for r in read_csv(meeting + '/endpoint_metrics.csv') if r['case'] == 'strict_three']
endpoint_rows.sort(key=lambda r: r['waypoint_id'])
assert len(endpoint_rows) == 3 and {r['episode_index'] for r in endpoint_rows} == {'0'}
errors = [float(r['true_endpoint_error_um']) for r in endpoint_rows]
assert all(r['independent_success_lt20um_and_3_zero_frames'] == 'True' for r in endpoint_rows)
fig, ax = plt.subplots(figsize=(7.2, 4.7))
ax.bar([r['waypoint_id'] for r in endpoint_rows], errors, width=.46, color=BLUE)
for i, v in enumerate(errors):
    ax.text(i, v+.55, f'{v:.3f}', ha='center', va='bottom', fontsize=20, weight='bold')
ax.axhline(20, color=BODY, lw=1.7, ls=(0, (5, 4)))
ax.text(2.47, 20.7, '20 μm', ha='right', fontsize=17, color=BODY)
ax.set_ylim(0, 23)
ax.set_yticks([0, 5, 10, 15, 20])
ax.set_ylabel('真实终点误差（μm）')
ax.set_title('严格 RGB-D 三点独立验收', loc='left', pad=16, weight='bold')
grid(ax)
fig.text(.13, -.01, '1 episode · 3 targets；均记录 ≥3 帧零命令停稳', fontsize=16, color=BODY)
fig.subplots_adjust(bottom=.16, left=.18, right=.98, top=.88)
save(fig, 'strict_three_endpoint_errors')

trajectory_rows = read_csv(strict + '/visual_servo/trajectory.csv')
targets = read_json(strict + '/target_solutions.json')
target_map = {r['id']: np.array(r['requested_world_mm']) for r in targets}
xyz = np.array([[float(r[k]) for k in ('tip_world_x_mm','tip_world_y_mm','tip_world_z_mm')] for r in trajectory_rows])
segments = []
for r in trajectory_rows:
    key = (r['waypoint_id'], r['phase'])
    if not segments or segments[-1]['key'] != key:
        segments.append({'key': key, 'rows': []})
    segments[-1]['rows'].append(r)
phase_style = {'visual_align': (0, (1.2, 2.2)), 'visual_approach': '-', 'visual_retract': (0, (5, 3))}
phase_cn = {'visual_align': '方向对准', 'visual_approach': '轴向接近', 'visual_retract': '轴向回撤'}
fig, axes = plt.subplots(1, 2, figsize=(13.2, 6.0), gridspec_kw={'width_ratios': [1.12, 1]})
projections = [(1,2), (0,1)]
for ax, (a,b) in zip(axes, projections):
    for seg in segments:
        pt = np.array([[float(r[k]) for k in ('tip_world_x_mm','tip_world_y_mm','tip_world_z_mm')] for r in seg['rows']])
        idx = int(seg['key'][0][1:])-1
        ax.plot(pt[:,a], pt[:,b], color=COLORS[idx], ls=phase_style[seg['key'][1]], lw=2.8)
        if len(pt) > 20:
            j = int(len(pt)*.62)
            k = min(j+max(3,len(pt)//25),len(pt)-1)
            ax.annotate('', xy=(pt[k,a],pt[k,b]), xytext=(pt[j,a],pt[j,b]), arrowprops={'arrowstyle':'-|>','color':COLORS[idx],'lw':1.8,'mutation_scale':17})
    for i,(tid,pt) in enumerate(target_map.items()):
        ax.scatter(pt[a],pt[b],s=110,marker='X',color=DARK,zorder=5,edgecolor='white',linewidth=.7)
        offsets = [(8,12),(12,-5),(-36,0)] if a==1 else [(8,9),(-32,-24),(7,-25)]
        ax.annotate(tid, (pt[a],pt[b]), xytext=offsets[i],textcoords='offset points',fontsize=18,weight='bold',color=DARK)
    grid(ax, 'both')
    ax.set_aspect('equal', adjustable='box')
axes[0].scatter(xyz[0,1],xyz[0,2],s=65,marker='o',facecolors='white',edgecolors=BLUE,lw=2,zorder=5)
axes[0].annotate('起点', (xyz[0,1],xyz[0,2]),xytext=(12,-2),textcoords='offset points',fontsize=17,color=BODY)
axes[0].set_xlabel('World Y（mm）'); axes[0].set_ylabel('World Z（mm）')
axes[0].set_title('侧视：完整已执行轨迹',loc='left',weight='bold',pad=14)
axes[0].set_xlim(1,15); axes[0].set_ylim(-23,-2)
axes[1].set_xlabel('World X（mm）'); axes[1].set_ylabel('World Y（mm）')
axes[1].set_title('后部区域：实际跨点转移',loc='left',weight='bold',pad=14)
axes[1].set_xlim(-1.6,3.5); axes[1].set_ylim(8.6,14.4)
handles = [Line2D([0],[0],color=COLORS[i],lw=3,label=f'P{i+1} 段') for i in range(3)]
handles += [Line2D([0],[0],color=BODY,lw=2.5,ls=phase_style[p],label=phase_cn[p]) for p in phase_cn]
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,-.015),ncol=3,frameon=False,fontsize=16,columnspacing=2)
fig.text(.5,-.085,'1 episode · P1 → P2 → P3 · 3,844 条真实执行日志；目标取独立验收场景坐标',ha='center',fontsize=16,color=BODY)
fig.subplots_adjust(wspace=.36,bottom=.22,left=.07,right=.98,top=.9)
save(fig,'strict_three_executed_trajectory')

report = read_json(run + '/round_03/training_report.json')
models = {m['model']:m for m in report['models']}
mse = [report['test_baselines']['zero_hold']['all']['normalized_mse'],report['test_baselines']['nearest_training_state_lookup']['all']['normalized_mse'],models['state_only_bc']['test']['all']['normalized_mse'],models['rgb_state_bc']['test']['all']['normalized_mse']]
labels = ['Zero hold','State 1-NN','State-only BC','RGB + state BC']
c_state = models['state_only_bc']['test']['all']['action_mae_A_deg_B_deg_C_mm'][2]*1000
c_rgb = models['rgb_state_bc']['test']['all']['action_mae_A_deg_B_deg_C_mm'][2]*1000
improvement = (1-mse[3]/mse[2])*100
fig, ax = plt.subplots(figsize=(11.2,6.0))
ax.barh(range(4),mse,height=.58,color=['#DAE3F5','#CBD8EF','#9BB5E5',BLUE])
ax.set_yticks(range(4),labels,fontsize=18)
ax.invert_yaxis(); ax.set_xlim(0,.41); ax.set_xticks([0,.1,.2,.3,.4])
for i,v in enumerate(mse):
    ax.text(v+.008,i,f'{v:.6f}',va='center',fontsize=20,weight='bold' if i==3 else 'normal')
ax.set_xlabel('时间加权归一化一步动作 MSE（越低越好）',labelpad=14)
ax.set_title('独立随机布局测试：离线一步动作预测',loc='left',pad=18,weight='bold')
grid(ax,'x')
fig.text(.98,.84,f'较仅状态降低 {improvement:.1f}%',ha='right',fontsize=20,color=BLUE,weight='bold')
fig.text(.02,.09,f'C 轴动作 MAE：仅状态 {c_state:.3f} μm；RGB＋状态 {c_rgb:.3f} μm',fontsize=17,color=BODY)
fig.text(.02,.025,'测试 2 episodes / 3,446 frames；动作误差不等于终点误差，学习策略闭环尚未运行。',fontsize=16,color=BODY)
fig.subplots_adjust(left=.25,right=.96,top=.81,bottom=.29)
save(fig,'heldout_action_mse')

indexes = {name:read_json(run+f'/{name}/dataset_index.json') for name in ('three','five')}
layout_configs = {name:read_json(run+f'/{name}/collection_config.json') for name in ('three','five')}
layout_radii = layout_configs['three']['reference_scene']['eye_radii_robot_mm']
assert layout_radii == layout_configs['five']['reference_scene']['eye_radii_robot_mm']
layouts = {}
for name,index in indexes.items():
    e = next(e for e in index['episodes'] if e['split']=='train' and e['episode_index']==0)
    assert e['collection']['qualified_training_episode']
    layouts[name] = {'split':'train','episode_index':0,'targets':e['target_verification']['targets'],'seed':e['random_seed']}
fig, axes=plt.subplots(1,2,figsize=(12.6,5.8),sharex=True,sharey=True)
cap_z_min=indexes['three']['episodes'][0]['target_verification']['definition']['minimum_normalized_posterior_z']
assert cap_z_min == indexes['five']['episodes'][0]['target_verification']['definition']['minimum_normalized_posterior_z']
cap_factor=np.sqrt(1-cap_z_min**2)
for ax,(name,layout) in zip(axes,layouts.items()):
    # Exact projection of the z/rz >= 0.9 cap for radii 12,11.5,12 mm.
    ax.add_patch(Ellipse((0,0),2*layout_radii[0]*cap_factor,2*layout_radii[1]*cap_factor,facecolor=CARD,edgecolor='#BCCBE7',lw=1.4))
    ax.axhline(0,color='#E2E8F0',lw=1);ax.axvline(0,color='#E2E8F0',lw=1)
    for t in layout['targets']:
        x,y,z=t['eye_local_mm']
        ax.scatter(x,y,s=180,color=BLUE,edgecolor='white',linewidth=1.3,zorder=3)
        ax.annotate(t['waypoint_id'],(x,y),xytext=(9,8),textcoords='offset points',fontsize=19,weight='bold')
    ax.set_xlim(-6,6);ax.set_ylim(-5.7,5.7);ax.set_aspect('equal')
    ax.set_xticks([-4,0,4]);ax.set_yticks([-4,0,4]);ax.set_xlabel('眼球局部 X（mm）')
    ax.set_title(f'{len(layout["targets"])} 点真实训练布局',weight='bold',loc='left',pad=14)
    grid(ax,'both')
axes[0].set_ylabel('眼球局部 Y（mm）')
fig.text(.5,.02,'从已采集合格 episode 读取；后部椭球表面代理的 XY 投影（z/rz ≥ 0.9），无单独视网膜层。',ha='center',fontsize=16,color=BODY)
fig.subplots_adjust(left=.07,right=.98,top=.9,bottom=.17,wspace=.22)
save(fig,'real_three_five_layouts')

split = report['split_audit']
split_rows=[['训练',split['source_episode_counts']['train'],split['train_frames'],'6 / 6'],['验证',split['source_episode_counts']['validation'],split['validation_frames'],'1 / 1'],['测试',split['source_episode_counts']['test'],split['test_frames'],'1 / 1']]
fig,ax=plt.subplots(figsize=(9.4,3.6));ax.axis('off')
table=ax.table(cellText=[[r[0],str(r[1]),f'{r[2]:,}',r[3]] for r in split_rows],colLabels=['划分','Episodes','Frames','3点 / 5点 episode'],cellLoc='center',colLoc='center',bbox=[0,.17,1,.8],colWidths=[.17,.2,.25,.38])
table.auto_set_font_size(False);table.set_fontsize(19)
for (row,col),cell in table.get_celld().items():
    cell.set_edgecolor('white');cell.set_linewidth(3)
    cell.set_facecolor(PALE if row==0 else CARD)
    cell.set_text_props(color=DARK if row==0 else BODY,weight='bold' if row==0 else 'normal')
ax.text(.5,.055,'按完整 episode / 目标布局划分；三组布局哈希不交叉。',ha='center',fontsize=17,color=BODY)
save(fig,'dataset_split_table')
with (OUT/'dataset_split.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(['split','episodes','frames','three_target_episodes','five_target_episodes']);w.writerows([['train',12,20075,6,6],['validation',2,3184,1,1],['test',2,3446,1,1]])

sample_rel=run+'/three/episodes/train/episode_000000/dataset/data/episode_000000.jsonl'
sp=ROOT/sample_rel
sample_lines=sp.read_text().splitlines(); sample=json.loads(sample_lines[10]); next_sample=json.loads(sample_lines[11])
SOURCES[sample_rel]={'sha256':hashlib.sha256(sp.read_bytes()).hexdigest(),'line_1_based':11}
rgb_key='observation.images.microscope_rgb'
state_key='observation.state'
rgb_path=sp.parent.parent/sample[rgb_key]
assert rgb_path.exists() and sample['action']==next_sample[state_key]
rgb_sha=hashlib.sha256(rgb_path.read_bytes()).hexdigest()
shutil.copyfile(rgb_path,OUT/'aligned_rgb_frame_000010.png')
aligned={k:sample[k] for k in ['timestamp',rgb_key,state_key,'action']}
(OUT/'aligned_sample.json').write_text(json.dumps(aligned,ensure_ascii=False,indent=2)+'\n')
alignment={'sample_jsonl':sample_rel,'sample_line_1_based':11,'rgb_relative_to_dataset':sample[rgb_key],'rgb_sha256':rgb_sha,'rgb_original_size_px':list(__import__('PIL.Image',fromlist=['Image']).open(rgb_path).size),'field_units':{state_key:['A_deg','B_deg','C_mm'],'action':['A_deg','B_deg','C_mm']},'action_semantics':'Absolute next axis-position command; BC label uses action minus current state.','next_timestamp':next_sample['timestamp'],'next_state':next_sample[state_key],'action_equals_next_state':True,'path_and_ids_are_model_features':False,'training_inputs':['decoded RGB-derived global image','decoded RGB-derived target ROI','RGB-derived visual features','A/B/C state'],'not_policy_inputs':['RGB path string','episode/frame/target ID','phase','3D target truth','depth','segmentation'],'fixed_task_text_encoded':False}
(OUT/'aligned_sample_provenance.json').write_text(json.dumps(alignment,ensure_ascii=False,indent=2)+'\n')

included = read_json(run+'/round_03/episode_selection.json')
excluded = read_json(run+'/round_03/excluded_episodes.json')
selected_layouts={s:[] for s in ('train','validation','test')}
for item in included['included']:
    name='three' if item['target_count']==3 else 'five'
    e=next(e for e in indexes[name]['episodes'] if e['split']==item['split'] and e['episode_index']==item['scenario_episode_index'])
    assert e['collection']['qualified_training_episode'] and e['target_verification']['result']=='PASS'
    selected_layouts[item['split']].append({'target_count':item['target_count'],'scenario_episode_index':item['scenario_episode_index'],'target_layout_sha256':item['target_layout_sha256'],'eye_local_targets_mm':{t['waypoint_id']:t['eye_local_mm'] for t in e['target_verification']['targets']}})
assert [len(selected_layouts[s]) for s in selected_layouts]==[12,2,2]
assert not (set(x['target_layout_sha256'] for x in selected_layouts['train']) & set(x['target_layout_sha256'] for x in selected_layouts['validation']+selected_layouts['test']))
(OUT/'selected_layouts_by_split.json').write_text(json.dumps(selected_layouts,ensure_ascii=False,indent=2)+'\n')
results_path=ROOT/run/'RESULTS.md'
SOURCES[run+'/RESULTS.md']={'sha256':hashlib.sha256(results_path.read_bytes()).hexdigest()}
source_data={
 'style':{'blue':BLUE,'dark':DARK,'body':BODY,'pale_blue':PALE,'card':CARD,'font':'Noto Sans SC','minimum_plot_font_pt':16},
 'strict_three':{'endpoint_rows':endpoint_rows,'trajectory_rows':len(trajectory_rows),'trajectory_time_s':[float(trajectory_rows[0]['time_s']),float(trajectory_rows[-1]['time_s'])],'targets_requested_world_mm':{k:v.tolist() for k,v in target_map.items()},'source':'independent evaluation executed world XYZ; no planned path'},
 'test_actions':{'labels':labels,'normalized_mse':mse,'rgb_vs_state_reduction_percent':improvement,'C_axis_action_MAE_um':{'state_only':c_state,'rgb_state':c_rgb},'scope':report['evaluation_scope'],'closed_loop_navigation':report['closed_loop_navigation'],'endpoint_accuracy_below_20um':report['endpoint_accuracy_below_20um']},
 'layouts':layouts,'layout_proxy':{'eye_radii_mm':layout_radii,'minimum_normalized_posterior_z':cap_z_min,'projection':'eye-local XY; posterior-cap boundary derived from source ellipsoid radii'},'splits':{'rows':split_rows,'unit':split['split_unit'],'target_layouts_disjoint':split['target_layouts_disjoint'],'included_episode_count':len(included['included'])},
 'failure_retention':{'attempts':19,'qualified':16,'failures':3,'raw_rgb_saved':30441,'unattempted_frozen_reserve_layouts':9,'failures':[{'target_count':5,'split':'validation','episode_index':0,'reason':'TARGET_NOT_VISIBLE','frames':1127},{'target_count':5,'split':'validation','episode_index':1,'reason':'INCONSISTENT_VISUAL_DEPTH','frames':1756},{'target_count':5,'split':'train','episode_index':4,'reason':'INSUFFICIENT_VISUAL_DEPTH','frames':853}],'failed_navigation_data_integrity_PASS_does_not_mean_navigation_success':True},
 'sample':alignment,'source_files':SOURCES,
}
(OUT/'sources_and_values.json').write_text(json.dumps(source_data,ensure_ascii=False,indent=2)+'\n')
(OUT/'README.md').write_text('''# Project figures for 2026-10-23 meeting

Generated from existing evidence by `generate_project_assets.py`. All figures are available as PNG, PDF and SVG. Source hashes, exact values, coordinate systems, retained failures and data boundaries are in `sources_and_values.json`.

| Asset | Suggested use |
|---|---|
| strict_three_endpoint_errors | Strict three-point endpoint result, exactly one episode / three targets |
| strict_three_executed_trajectory | Actual executed world-coordinate trajectory; full side view plus posterior XY detail |
| heldout_action_mse | Four-method held-out offline action MSE with C-axis limitation |
| real_three_five_layouts | Actual collected 3/5-point train layouts in eye-local coordinates |
| dataset_split_table | Whole-episode 12/2/2 and 20075/3184/3446 split |
| aligned_sample.json + aligned_rgb_frame_000010.png | One real timestamp-aligned RGB/state/action example |

Critical limits: The strict three-point endpoint experiment belongs to the RGB-D expert controller. The learned model was evaluated only on offline one-step actions from two held-out episodes; it has no closed-loop endpoint result. The C-axis action MAE is 10.472 μm for state-only and 11.162 μm for RGB+state, so C has not improved. Layouts are posterior ellipsoid-surface proxies with no separate retinal layer, not measured retinal lesions or OCT surfaces. RGB paths and IDs are data references/audit metadata; the image pixels and ABC state supply policy inputs. The sample `action` is the next absolute axis-position command; BC uses its increment from current state.

Failed collection attempts remain in original evidence: 19 attempted, 16 qualified, 3 failed. Qualified train/validation/test splitting excludes failed demonstrations, and this asset set does not alter source files. Test size is two episodes (one three-point, one five-point). Do not infer statistical significance or general closed-loop success from frame count.

Font: `NotoSansSC-Regular-static.ttf` is instantiated at wght=400 from the official Google Fonts Noto Sans SC variable TTF. `NotoSansSC-Bold-static.ttf` is wght=700 where present. Original URL: https://raw.githubusercontent.com/google/fonts/main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf .
''',encoding='utf-8')

# Native slide-size alternatives. Use at the stated physical size so all text
# remains at least 16 pt on the slide. Long explanations belong in slide text.
def save_ppt(fig,name):
    for ext in ('png','pdf','svg'):
        metadata={'Date':None} if ext=='svg' else {'CreationDate':None,'ModDate':None} if ext=='pdf' else {}
        fig.savefig(OUT/f'{name}_ppt.{ext}',dpi=240,metadata=metadata)
    plt.close(fig)

fig,ax=plt.subplots(figsize=(4.3,3.2))
ax.bar(['P1','P2','P3'],errors,width=.48,color=BLUE)
for i,v in enumerate(errors):ax.text(i,v+.8,f'{v:.3f}',ha='center',fontsize=18,weight='bold')
ax.axhline(20,color=BODY,lw=1.6,ls=(0,(4,3)))
ax.text(2.43,20.8,'20 μm',fontsize=16,ha='right',color=BODY)
ax.set_ylabel('终点误差 / μm',fontsize=16,labelpad=7)
ax.set_ylim(0,23);ax.set_yticks([0,10,20]);ax.tick_params(labelsize=16)
grid(ax)
fig.text(.6,.025,'1 episode / 3 targets',ha='center',fontsize=16,color=BODY)
fig.subplots_adjust(left=.23,right=.98,top=.97,bottom=.22)
save_ppt(fig,'strict_three_endpoint_errors')

fig,axes=plt.subplots(1,2,figsize=(7.2,4.3),gridspec_kw={'width_ratios':[1,1]})
for ax,(a,b) in zip(axes,projections):
    for seg in segments:
        pt=np.array([[float(r[k]) for k in ('tip_world_x_mm','tip_world_y_mm','tip_world_z_mm')] for r in seg['rows']])
        idx=int(seg['key'][0][1:])-1
        ax.plot(pt[:,a],pt[:,b],color=COLORS[idx],ls=phase_style[seg['key'][1]],lw=2.6)
        if len(pt)>20:
            j=int(len(pt)*.62);k=min(j+max(3,len(pt)//25),len(pt)-1)
            ax.annotate('',xy=(pt[k,a],pt[k,b]),xytext=(pt[j,a],pt[j,b]),arrowprops={'arrowstyle':'-|>','color':COLORS[idx],'lw':1.5,'mutation_scale':13})
    for i,(tid,pt) in enumerate(target_map.items()):
        ax.scatter(pt[a],pt[b],s=65,marker='X',color=DARK,zorder=6,edgecolor='white',linewidth=.5)
        off=[(7,8),(12,-5),(-36,0)] if a==1 else [(5,8),(-28,-16),(5,-18)]
        ax.annotate(tid,(pt[a],pt[b]),xytext=off[i],textcoords='offset points',fontsize=16,weight='bold')
    grid(ax,'both');ax.tick_params(labelsize=16)
axes[0].set_xlim(1,15);axes[0].set_ylim(-23,-2)
axes[0].set_xticks([5,10,15]);axes[0].set_yticks([-5,-15,-25]);axes[0].set_ylim(-23,-2)
axes[0].set_xlabel('Y / mm',fontsize=16,labelpad=3);axes[0].set_ylabel('Z / mm',fontsize=16,labelpad=0)
axes[0].set_title('完整侧视 YZ',fontsize=18,loc='left',pad=10,weight='bold')
axes[0].scatter(xyz[0,1],xyz[0,2],s=45,facecolors='white',edgecolors=BLUE,lw=1.5,zorder=5)
axes[0].annotate('起点',(xyz[0,1],xyz[0,2]),xytext=(7,-2),textcoords='offset points',fontsize=16,color=BODY)
axes[1].set_xlim(-1.6,3.5);axes[1].set_ylim(8.6,14.4)
axes[1].set_xticks([0,3]);axes[1].set_yticks([9,12,14])
axes[1].set_xlabel('X / mm',fontsize=16,labelpad=3);axes[1].set_ylabel('Y / mm',fontsize=16,labelpad=0)
axes[1].set_title('后部区域 XY',fontsize=18,loc='left',pad=10,weight='bold')
legend=[Line2D([0],[0],color=BODY,lw=2.5,ls=phase_style[p],label=phase_cn[p]) for p in phase_cn]
fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.53,.001),ncol=3,frameon=False,fontsize=16,handlelength=1.7,columnspacing=.8,handletextpad=.4)
fig.subplots_adjust(left=.12,right=.98,top=.86,bottom=.26,wspace=.57)
save_ppt(fig,'strict_three_executed_trajectory')

fig,ax=plt.subplots(figsize=(7.3,4.5))
ax.barh(range(4),mse,height=.58,color=[PALE,'#CBD8EF','#9BB5E5',BLUE])
ax.set_yticks(range(4),labels,fontsize=16);ax.invert_yaxis()
ax.set_xlim(0,.48);ax.set_xticks([0,.1,.2,.3,.4]);ax.tick_params(axis='x',labelsize=16)
for i,v in enumerate(mse):
    ax.text(v+.006,i,f'{v:.6f}',va='center',fontsize=17,weight='bold' if i==3 else 'normal')
ax.set_xlabel('时间加权归一化一步动作 MSE',fontsize=16,labelpad=8)
grid(ax,'x')
fig.text(.975,.94,f'较仅状态降低 {improvement:.1f}%',ha='right',fontsize=18,color=BLUE,weight='bold')
fig.text(.02,.13,f'C 轴 MAE：状态 {c_state:.3f} μm / 视觉 {c_rgb:.3f} μm',fontsize=16,color=BODY)
fig.text(.02,.045,'一步动作预测；尚无学习策略闭环终点结果',fontsize=16,color=BODY)
fig.subplots_adjust(left=.27,right=.98,top=.88,bottom=.32)
save_ppt(fig,'heldout_action_mse')

fig,axes=plt.subplots(1,2,figsize=(7.4,3.9),sharex=True,sharey=True)
for ax,(name,layout) in zip(axes,layouts.items()):
    ax.add_patch(Ellipse((0,0),2*layout_radii[0]*cap_factor,2*layout_radii[1]*cap_factor,facecolor=CARD,edgecolor='#BCCBE7',lw=1.2))
    ax.axhline(0,color='#E2E8F0',lw=.8);ax.axvline(0,color='#E2E8F0',lw=.8)
    for t in layout['targets']:
        x,y,z=t['eye_local_mm'];ax.scatter(x,y,s=85,color=BLUE,zorder=3,edgecolor='white')
        ax.annotate(t['waypoint_id'],(x,y),xytext=(5,6),textcoords='offset points',fontsize=16,weight='bold')
    ax.set_xlim(-6,6);ax.set_ylim(-5.7,5.7);ax.set_aspect('equal');ax.set_xticks([-4,0,4]);ax.set_yticks([-4,0,4]);ax.tick_params(labelsize=16)
    ax.set_xlabel('局部 X / mm',fontsize=16,labelpad=3)
    ax.set_title(f'{len(layout["targets"])} 点真实布局',fontsize=18,weight='bold',loc='left',pad=10)
axes[0].set_ylabel('局部 Y / mm',fontsize=16,labelpad=1)
fig.subplots_adjust(left=.10,right=.98,top=.84,bottom=.18,wspace=.28)
save_ppt(fig,'real_three_five_layouts')

print(json.dumps({'out':str(OUT),'pngs':[p.name for p in OUT.glob('*.png')],'strict_errors_um':errors,'mse':mse,'sample_action_equals_next_state':True},ensure_ascii=False,indent=2))
