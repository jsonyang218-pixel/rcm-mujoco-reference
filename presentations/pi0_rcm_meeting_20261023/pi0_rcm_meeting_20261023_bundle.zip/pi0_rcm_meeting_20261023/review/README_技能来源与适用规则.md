# Scientific Slides 与 Supervisor-Skills：来源、适用规则和待执行检查

记录日期：2026-10-23（UTC）。本文件是制作规范与检查计划，不是对尚未完成的 PPTX 的通过声明。

## 1. 已查找并读取的技能

- 已检查会话 `skills.list`：cloud 只有环境 onboarding 技能，executor 为空；本地未找到 scientific-slides。
- 用户指定的 `K-Dense-AI/claude-scientific-skills` 已更名为 **K-Dense-AI/scientific-agent-skills**；上游 README 明确说明重命名，技能现位于 `skills/scientific-slides/SKILL.md`。
- 正式来源：<https://github.com/K-Dense-AI/scientific-agent-skills/blob/593377bb048752abb0152deab9fbb1083a6087df/skills/scientific-slides/SKILL.md>。
- scientific-slides 元数据版本：**1.12**；`last-reviewed: 2026-10-01`；MIT license。
- `git ls-remote` 读取的 `main` / `HEAD`：**593377bb048752abb0152deab9fbb1083a6087df**。下载均固定此 SHA，与首次 master raw 下载逐字节一致。
- 已保存技能、10 份适用 references/assets、逐文件 URL/字节数/SHA256：`scientific-slides/download_manifest.json`。未执行上游脚本或远程代码。
- Supervisor-Skills 来源：<https://github.com/HKUSTDial/Supervisor-Skills>，现有本地克隆 `/tmp/rcm-supervisor-skills-20261022`；固定提交 **a20d76ef3979b804d7dbf599d577826957e0a8a9**。已复制并读取 `figure-designer`、`tech-paper-template` 及审查所需 references。

## 2. 本次用户约束优先

本次交付为中文科研组会、原生可编辑 PPTX，**13 页正文 + 3 页备份**；正文目标 **13:30**，15 分钟总时段留约 1:30 缓冲；π0 的 3 页约 **4 分钟**。

技能中的“15–18 页”“8–15 篇文献”“每个英文 bullet 4–6 words”等是通用建议，不能覆盖用户精确页数、讲述时间、已给材料和证据边界。本次不为满足数量而增页或添加无关文献。中文采用简短短语与清晰换行，不机械套用英文词数。

## 3. 可执行制作规则

| 项目 | 本次执行方式 | 来源 / 性质 |
|---|---|---|
| 一页一个核心信息 | 每页有一条可口头复述的主结论；标题优先表达结论或本页要解决的问题 | scientific-slides，设计规则 |
| 论述闭环 | 动机/局限 → 核心思路 → 实施挑战 → 方法模块 → 证据/已完成工作 → 局限与下一步 | Supervisor tech-paper-template；对组会情境的适配 |
| 证据可追溯 | 论文事实、代码事实、实验结果、研究设想分别表述；每个关键性能数字可回到真实来源 | scientific-slides 的 research-backed 与原图保真规则；本次适配 |
| 原生编辑 | 标题、正文、标签、表格、流程图节点与箭头保持 PowerPoint 原生对象；可用 python-pptx 现有模板工作流 | scientific-slides `assets/powerpoint_design_guide.md` |
| 定量结果保真 | 保留原图或由真实数据确定性重绘；不使用生成式图片重绘点、坐标轴、数字、误差线；不补造缺失结果 | scientific-slides SKILL 的 preserve-original-assets 规则 |
| 图优先 | 方法页优先流程图，比较页优先简表或对照图，几何页优先示意图；可视元素帮助解释，避免装饰占用 | scientific-slides |
| 简短文字 | 通常每页 3–4 个短提示；详细解释放讲稿；同一信息不同时挤在图注、正文和标题 | scientific-slides；中文短语长度为实施判断 |
| 字体层级 | 建议标题 32–40 pt，正文 24–28 pt；必要次级内容不低于 18 pt；图标签 18–24 pt；引用 14–16 pt 且限量 | scientific-slides design principles；以上为建议目标，最终须逐页渲染检查 |
| 中文字体 | 采用已安装且可回退的中文无衬线字体；核验 π、上/下标、数学符号、英文缩写及中文换行 | 设计规则的字体兼容性；中文细则为实施判断 |
| 统一视觉 | 3–5 个角色明确的颜色、固定边距和标题区、3–5 种布局变体；同一模块/状态跨页同色 | scientific-slides |
| 可访问性 | 常规文字对比度 ≥4.5:1，尽量 ≥7:1；使用颜色 + 线型/形状/直接标签双重编码；避免仅红绿区分 | scientific-slides + Supervisor figure-designer |
| 图与坐标 | 标清实体、方向、坐标名、单位和必要的不确定性；图型匹配数据类型；量程真实；不使用图形夸大未验证优势 | Supervisor figure-designer + scientific-slides |
| 投影可读 | 放大关键比较，复杂图拆解或移入备份；保持比例，不拉伸；不得为了简化删除会改变结论的对照、样本量或不确定性 | scientific-slides data_visualization_slides |
| 计时 | 对每页标定预计时长，合计 13:30；π0 三页合计约4分钟；备份不计入正文；不以页数自动推断实际讲述时长 | 用户约束 + scientific-slides timing |
| 验证 | 保存PPTX后导出PDF，逐页渲染成图，核验正文/备份页数、越界、遮挡、字体替换、图清晰度和错误字符；提取文本另查术语、数字、引用 | scientific-slides visual_review_workflow |

Supervisor 的“8 pt”“PDF/EPS/SVG only”“与论文衬线字体一致”等规则面向双栏论文，**不直接作为投影 PPT 的字号或格式阈值**。本次以更严格的投影可读字号和原生编辑要求实施；示意图和图表尽量使用原生矢量对象，真实截图可作为有来源的证据素材。

## 4. Supervisor 逻辑审查表（待成稿执行）

每项结论必须写明页码、对象或原文证据；材料不足时标“待核验”，不可写“通过”。

| ID | 检查 | 失败条件 | 来源严重度 |
|---|---|---|---|
| L1 | 局限 → 核心思路 | 声称解决的局限与方案无关，或提出未解释的额外目标 | CRITICAL |
| L2 | 核心思路 → 挑战 | 挑战并非由实施核心思路自然产生，而是为模块拼凑 | CRITICAL |
| L3 | 挑战 → 方法模块 | 有挑战无回应，有模块无动机，或多对多映射无解释 | CRITICAL |
| L4 | 方法/实验 → 结论 | 结论无实验/代码/来源支持，把计划写成成果，或把外部论文结果写成本项目结果 | CRITICAL；后一组例子为本次审查适配 |
| L5 | 单句思路 | 无法用一句话清晰说明本次方案或阶段目标 | integrity gate |
| L6 | 贡献/进展边界 | 已完成工作、代码适配、设计目标、待验证指标边界不清 | integrity gate；组会适配 |
| L7 | 中文术语一致 | π0、RCM等术语、参考坐标系、输入/输出、公式定义前后改变 | 本次补充 |

## 5. Supervisor 图示审查表（待渲染后执行）

| ID | 检查 | 本次要求 |
|---|---|---|
| F1 | 图示类型匹配意图 | 动机图能解释问题；总览图展示模块与关系；结果图用于真实结果 |
| F2 | 标签具体 | 使用真实实体和模块名称；避免“Module A”“X/Y”等无定义占位标签 |
| F3 | 布局与连线 | 读者能判断流程、输入/输出、箭头方向和关键约束；不暗示不存在的因果关系 |
| F4 | 原生/矢量 | 原生对象与连接线可编辑；原始数值图不变形、不生成式重绘 |
| F5 | 可读字号与清晰度 | 以投影字号核验；需视觉检查，不能只看代码设定 |
| F6 | 色盲安全 | 颜色 + 形状/线型/标签；灰度下仍能理解 |
| F7 | 核心发现与图注 | 标题/短注说明本图传递的发现；缩写、变量、单位可理解 |
| F8 | 坐标与不确定性 | 范围、单位、log标注、误差/样本量真实；不得呈现虚构量化效果 |
| F9 | 无图表装饰噪声 | 不使用3D柱、装饰渐变/投影、无意义背景；突出真正的关键对象 |

严重度按上游执行：CRITICAL 阻断正确理解或存在逻辑/证据断裂；MAJOR 影响阅读、字号、对比度或连线解释；MINOR 为不影响结论的排版细节。没有图像时，上游明确要求字体、栅格和配色等视觉项目标为待核验；原文不是要求把可由现有材料验证的项目重新交给用户。

## 6. 引用核验状态与软件来源引用

scientific-slides 上游要求在技能对交付有实质贡献时引用其论文，并列出：Kassis 等，2026，*Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents*，arXiv:2609.00065。已分别尝试 `https://arxiv.org/abs/2609.00065`、`https://export.arxiv.org/api/query?id_list=2609.00065`、`https://doi.org/10.48550/arXiv.2609.00065`；均被网络代理以 HTTP 403 拒绝。因此，**该论文书目尚未独立核验，不作为本项目方法或性能证据**。

本交付的可核验软件来源引用为：

> K-Dense Inc. Scientific Slides, v1.12, Scientific Agent Skills. GitHub, commit 593377bb048752abb0152deab9fbb1083a6087df. Accessed 2026-10-23. <https://github.com/K-Dense-AI/scientific-agent-skills/tree/593377bb048752abb0152deab9fbb1083a6087df/skills/scientific-slides>
>
> HKUSTDial. Supervisor-Skills, figure-designer and tech-paper-template. GitHub, commit a20d76ef3979b804d7dbf599d577826957e0a8a9. Accessed 2026-10-23. <https://github.com/HKUSTDial/Supervisor-Skills/tree/a20d76ef3979b804d7dbf599d577826957e0a8a9>

这些工具来源可放入随交付的技术说明/审查报告；它们不等于实验或论文性能来源。

## 7. 最终报告应提供的最小证据

- 成稿路径、PPTX页数与正文/备份标识；讲稿页时长总和。
- 全部16页渲染图；已修复问题的页码与修复后复查结果。
- L1–L7 与 F1–F9 逐项结论、证据、严重度、剩余待核验项。
- 性能数字与引用来源检查；实验证据缺失明确标注。
- 真实验收范围：程序检查、渲染视觉检查和独立逻辑审查分别写清，不能等同于实际投影、PowerPoint原生渲染或口头试讲通过。
