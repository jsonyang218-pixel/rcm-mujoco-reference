# 随机3点/5点采集与BC训练结果

北京时间 **2026-10-23 03:09** 全部完成，早于08:00截止。采集、三轮训练及验证集选模后的独立测试已完成；学习策略闭环尚未运行。

|数据|episode|帧|
|---|---:|---:|
|训练|12|20,075|
|验证|2|3,184|
|测试|2|3,446|
|合格总计|16|26,705|

共尝试19个随机任务，合格16、失败3，实际保存30,441张原始RGB。另9个冻结备用布局未尝试，不计为失败。训练/验证/测试布局哈希完全不交叉；测试只有2个episode，分别为随机3点、5点，结果适用于本次留出场景。失败完整保留，未混入成功示范训练。

合格专家示范64个目标均到达并停稳，最大终点误差 **14.981013 μm**，速度/加速度及眼底转向约束通过。此精度属于原视觉示教控制器，不能作为学习模型的精度结论。

## 三轮训练

|轮次|训练episode|RGB验证动作MSE|仅状态验证动作MSE|
|---|---:|---:|---:|
|1|4|0.148889|0.185904|
|2|8|0.139064|0.185806|
|3|12|0.111807|0.174239|

三轮均通过预设验证门槛；仅按验证动作MSE选择第3轮，随后只对该轮做最终测试。每轮数据量、训练种子与epoch上限不同，表格描述实际结果，不是单一因素消融。

## 独立随机布局测试

|方法|时间加权归一化一步动作MSE（越低越好）|
|---|---:|
|Zero hold|0.284060|
|State 1-NN|0.359600|
|State-only BC|0.206721|
|RGB + state BC|0.120330|

RGB＋状态模型比仅状态模型降低 **41.8%**。随机3点测试MSE为0.098908，5点为0.135348。验证时同步打乱图像、局部裁剪和RGB特征后，RGB模型MSE由0.111807升为0.612307，表明当前预测受视觉输入影响。

改进主要来自A/B方向。C轴一步动作MAE为0.011162mm（11.162μm），仅状态模型为0.010472mm；C轴预测未优于该对照。一步动作误差不是导航终点误差，当前没有学习策略的闭环到达率、三/五点整集完成率或<20μm验收结果。

## 失败场景

- 5点validation/000000：P3对准时TARGET_NOT_VISIBLE，1127帧。
- 5点validation/000001：P5对准时INCONSISTENT_VISUAL_DEPTH，1756帧。
- 5点train/000004：P2对准时INSUFFICIENT_VISUAL_DEPTH，853帧。

上述导航FAIL，数据完整性验证PASS只表示保存与对齐成立。

## 文件

- 最佳模型：[round_03/rgb_state_bc/policy.pt](round_03/rgb_state_bc/policy.pt)
- 完整指标：[round_03/training_report.json](round_03/training_report.json)
- 测试对比：[result_figures/test_action_comparison.png](result_figures/test_action_comparison.png)
- 三轮验证对比：[result_figures/validation_rounds.png](result_figures/validation_rounds.png)
- 最佳轮训练曲线：[round_03/training_curves.png](round_03/training_curves.png)
- 汇总JSON：[results_summary.json](results_summary.json)

策略输入是RGB全局图、RGB目标局部裁剪、RGB中心/可见特征和ABC状态；没有输入深度、分割、phase、目标ID或场景真值。专家示教仍依赖理想RGB-D和几何标定；OCT仍是仿真接口，本次没有完整OCT深度序列训练、人工完全遮挡恢复学习或硬件验证。

完整原始RGB数据保留在three/episodes与five/episodes；轻量模型/报告包不含完整图像库和预处理缓存。
