#!/usr/bin/env python3
"""Bounded, resumable collection and validation-selected offline BC experiment.

Only this process edits dataset indexes. Each collector owns one frozen scenario,
its episode directory, and its unique result JSON. Test scores never decide
whether another training round runs or which checkpoint receives final test.

Example (run only after reviewing the frozen plan)::

    .venv/bin/python run_random_training_night.py \
        --base-dir runs/random_policy_overnight_20261022

Use --resume after an interruption; existing partial episode/round directories
are preserved and are never silently retried or overwritten. --self-check runs
small isolated scheduler/process checks without collecting or training.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile


HERE = Path(__file__).resolve().parent
SPLITS = ('train', 'validation', 'test')
DEFAULT_BASE = HERE/'runs/random_policy_overnight_20261022'
SOURCE_NAMES = (
    'run_random_training_night.py', 'collect_random_episode.py',
    'random_fundus_dataset.py', 'train_behavior_cloning.py',
    'rcm_behavior_policy.py', 'rcm_imitation_data.py',
    'run_waypoint_comparison.py', 'rcm_waypoint_dataset.py',
    'rcm_visual_servo.py', 'rcm_multitarget_visual.py',
    'rcm_reference.py', 'rcm_recovered_model.py', 'rcm_navigation.py',
    'rcm_fundus.py', 'rcm_sampling_planners.py', 'rcm_vision_navigation.py',
    'rcm_visual_geometry.py', 'rcm_target_tracking.py', 'rcm_occlusion_fixture.py', 'rcm_oct.py',
    'verify_dataset_collection.py', 'verify_waypoint_comparison.py',
    'requirements.txt', 'requirements-training.txt', 'scene.xml',
)


def utcnow():
    return datetime.now(timezone.utc)


def stamp():
    return utcnow().isoformat(timespec='seconds')


def parse_utc(value):
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if parsed.tzinfo is None:
        raise ValueError('Deadline must include its UTC offset or Z')
    return parsed.astimezone(timezone.utc)


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def atomic_json(path, value):
    """Publish complete JSON in one rename on the destination filesystem."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+f'.tmp.{os.getpid()}')
    try:
        with temporary.open('w', encoding='utf-8') as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def scenario_key(index_path, scenario):
    return f'{Path(index_path).resolve()}::{scenario["split"]}::{int(scenario["episode_index"])}'


def episode_directory(index_path, scenario):
    return Path(index_path).parent/'episodes'/scenario['split']/f'episode_{int(scenario["episode_index"]):06d}'


def verification_pass(result):
    value = result.get('verification_result')
    return (value.get('result') if isinstance(value, dict) else value) == 'PASS'


def eligible(scenario):
    result = scenario.get('collection', {})
    reports = result.get('reports', [])
    return (scenario.get('collection_status') == 'completed'
            and result.get('qualified_training_episode') is True
            and result.get('capture_complete') is True
            and result.get('exit_code') == 0 and verification_pass(result)
            and bool(reports) and all(row.get('result') == 'PASS' for row in reports))


def quotas_for_round(number):
    return {'train': 2*number, 'validation': 1, 'test': 1}


def counts_for_indexes(indexes):
    return {str(index['target_count_per_episode']): {
        split: sum(eligible(row) for row in index['episodes'] if row['split'] == split)
        for split in SPLITS} for index in indexes.values()}


def quotas_met(indexes, quotas):
    return all(counts[split] >= quotas[split]
               for counts in counts_for_indexes(indexes).values() for split in SPLITS)


def choose_scenario(indexes, quotas, active_keys=()):
    """Choose the largest proportional shortage, with deterministic tie breaks."""
    active_keys = set(active_keys)
    choices = []
    for path, index in indexes.items():
        count = index['target_count_per_episode']
        for split in SPLITS:
            rows = [row for row in index['episodes'] if row['split'] == split]
            accepted = sum(eligible(row) for row in rows)
            active = sum(scenario_key(path, row) in active_keys for row in rows)
            shortage = quotas[split]-accepted-active
            if shortage <= 0:
                continue
            pending = [row for row in rows if row.get('collection_status') == 'not_started'
                       and scenario_key(path, row) not in active_keys]
            if pending:
                row = min(pending, key=lambda item: int(item['episode_index']))
                choices.append((-shortage/quotas[split], -shortage,
                                SPLITS.index(split), count, str(path), row))
    if not choices:
        return None
    choice = min(choices, key=lambda item: item[:-1])
    return Path(choice[-2]), choice[-1]


def validation_result(report):
    """Use heldout validation only; nearest-state baseline is reported only."""
    models = {row['model']: row for row in report.get('models', [])}
    vision = float(models['rgb_state_bc']['validation']['all']['normalized_mse'])
    state = float(models['state_only_bc']['validation']['all']['normalized_mse'])
    zero = float(report['baselines']['zero_hold']['all']['normalized_mse'])
    if not all(math.isfinite(value) for value in (vision, state, zero)):
        raise ValueError('Non-finite validation score')
    return {'training_pipeline_result': report.get('training_pipeline_result'),
            'vision_normalized_mse': vision, 'state_only_normalized_mse': state,
            'zero_hold_normalized_mse': zero,
            'gate_pass': report.get('training_pipeline_result') == 'PASS'
                         and vision < zero and vision < state,
            'selection_split': 'validation', 'test_used_for_selection': False}


def process_start_ticks(pid):
    try:
        # The process name inside parentheses may contain spaces.
        return Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[19]
    except (OSError, IndexError):
        return None


def terminate_group(process, grace=5.):
    """Signal the full subprocess group; wait no longer than grace seconds."""
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=grace)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=5.)


class NightRunner:
    def __init__(self, args):
        self.args = args
        probe = subprocess.run(
            [sys.executable, '-c',
             'import json,sys,mujoco,numpy,torch; print(json.dumps({"executable":sys.executable,"prefix":sys.prefix,"mujoco":mujoco.__version__,"numpy":numpy.__version__,"torch":str(torch.__version__)}))'],
            capture_output=True, text=True, timeout=60)
        if probe.returncode != 0:
            raise RuntimeError('Runtime preflight failed before consuming any frozen scenario: '+probe.stderr[-2000:])
        self.runtime_preflight = json.loads(probe.stdout)
        self.base = args.base_dir.resolve()
        self.base.mkdir(parents=True, exist_ok=True)
        self.state_path = self.base/'progress.json'
        self.log_stream = (self.base/'runner.log').open('a', encoding='utf-8', buffering=1)
        self.lock = (self.base/'runner.lock').open('a+')
        fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        self.stop_reason = None
        self.active = {}
        self.indexes = {}
        self.cutoffs = {name: parse_utc(getattr(args, name+'_deadline'))
                        for name in ('collection', 'training', 'final', 'hard')}
        if not (self.cutoffs['collection'] < self.cutoffs['training']
                < self.cutoffs['final'] < self.cutoffs['hard']):
            raise ValueError('Deadlines must increase: collection < training < final < hard')
        self.index_paths = [path.resolve() for path in (args.dataset_index or [
            self.base/'three/dataset_index.json', self.base/'five/dataset_index.json'])]
        self.load_indexes()
        if self.state_path.exists():
            if not args.resume:
                raise ValueError(f'Existing progress requires --resume: {self.state_path}')
            self.state = read_json(self.state_path)
            old_paths = self.state.get('dataset_indexes')
            if old_paths != [str(path) for path in self.index_paths]:
                raise ValueError('Resume index paths differ from original plan')
            if self.state.get('deadlines') != {name: value.isoformat() for name, value in self.cutoffs.items()}:
                raise ValueError('Resume deadlines differ from original plan')
            self.validate_plan(self.state['frozen_plan'])
            self.state.setdefault('resumes', []).append(stamp())
        else:
            if args.resume:
                raise ValueError('--resume requires an existing progress.json')
            self.state = {'schema_version': 1, 'run_id': self.base.name,
                          'runtime_preflight': self.runtime_preflight,
                          'started_at': stamp(), 'status': 'prepared',
                          'dataset_indexes': [str(path) for path in self.index_paths],
                          'deadlines': {name: value.isoformat() for name, value in self.cutoffs.items()},
                          'jobs': [], 'rounds': [], 'final_evaluation': None,
                          'frozen_plan': self.make_plan(),
                          'policy': {'max_rounds': args.max_rounds, 'workers': args.workers,
                                     'train_minimums_by_round': [quotas_for_round(n) for n in range(1, args.max_rounds+1)],
                                     'gate': 'pipeline PASS and heldout validation vision MSE < zero hold and state only',
                                     'test_used_for_selection': False,
                                     'final_test_evaluations_maximum': 1},
                          'invocation': [sys.executable, *sys.argv]}
            self.snapshot()
        self.save()

    def log(self, message):
        line = f'{stamp()} {message}'
        print(line, flush=True)
        self.log_stream.write(line+'\n')

    def save(self):
        self.state['updated_at'] = stamp()
        self.state['qualified_counts'] = counts_for_indexes(self.indexes)
        atomic_json(self.state_path, self.state)

    def load_indexes(self):
        for path in self.index_paths:
            index = read_json(path)
            manifest_path = path.parent/index['scenario_manifest']
            manifest = read_json(manifest_path)
            manifest_content = {key: value for key, value in manifest.items() if key != 'manifest_sha256'}
            canonical = json.dumps(manifest_content, ensure_ascii=False, sort_keys=True,
                                   separators=(',', ':')).encode('utf-8')
            if (hashlib.sha256(canonical).hexdigest() != index['scenario_manifest_sha256']
                    or manifest.get('manifest_sha256') != index['scenario_manifest_sha256']):
                raise ValueError(f'Frozen manifest hash differs: {path}')
            frozen = {(row['split'], row['episode_index']): row for row in manifest['scenarios']}
            if len(frozen) != len(index['episodes']):
                raise ValueError(f'Frozen scenario count differs: {path}')
            for row in index['episodes']:
                original = frozen[(row['split'], row['episode_index'])]
                if any(row.get(key) != value for key, value in original.items()):
                    raise ValueError(f'Frozen scenario changed: {path} {row["split"]}/{row["episode_index"]}')
                targets = (path.parent/row['targets']).resolve()
                if not targets.is_relative_to(path.parent) or sha256(targets) != row['targets_sha256']:
                    raise ValueError(f'Frozen targets changed: {targets}')
            config = path.parent/index['config_snapshot']
            if sha256(config) != index['config_sha256']:
                raise ValueError(f'Frozen config changed: {config}')
            self.indexes[path] = index
        counts = sorted(index['target_count_per_episode'] for index in self.indexes.values())
        if counts != [3, 5]:
            raise ValueError('Exactly one frozen 3-target and one 5-target index are required')

    def make_plan(self):
        return [{'dataset_index': str(path),
                 'target_count': index['target_count_per_episode'],
                 'manifest_sha256': index['scenario_manifest_sha256'],
                 'config_sha256': index['config_sha256'],
                 'scenarios': [{key: row.get(key) for key in (
                     'split', 'episode_index', 'random_seed', 'start_seed',
                     'targets', 'targets_sha256', 'start_task_A_deg_B_deg_C_mm')}
                     for row in index['episodes']]}
                for path, index in self.indexes.items()]

    def validate_plan(self, plan):
        if self.make_plan() != plan:
            raise ValueError('Frozen seeds, splits, geometry or configuration differ from original plan')

    def snapshot(self):
        destination = self.base/'source_snapshot'
        destination.mkdir(exist_ok=False)
        hashes = {}
        for name in SOURCE_NAMES:
            source = HERE/name
            if source.is_file():
                shutil.copy2(source, destination/name)
                hashes[name] = sha256(source)
        for path in self.index_paths:
            label = f'{self.indexes[path]["target_count_per_episode"]}_targets'
            directory = destination/label
            directory.mkdir()
            for name in ('dataset_index.json', 'scenario_manifest.json', 'collection_config.json'):
                source = path.parent/name
                shutil.copy2(source, directory/name)
                hashes[f'{label}/{name}'] = sha256(source)
            shutil.copytree(path.parent/'targets', directory/'targets')
        atomic_json(destination/'source_sha256.json', hashes)
        atomic_json(self.base/'frozen_seed_plan.json', self.state['frozen_plan'])
        atomic_json(self.base/'runner_config.json', {
            key: str(value) if isinstance(value, Path) else
                 [str(item) for item in value] if key == 'dataset_index' and value else value
            for key, value in vars(self.args).items()})

    def update_index(self, path):
        index = self.indexes[path]
        attempted = [row for row in index['episodes'] if row.get('collection_status') != 'not_started']
        index['collection_status'] = 'in_progress'
        if len(attempted) == len(index['episodes']):
            index['collection_status'] = ('complete' if all(row.get('collection_status') == 'completed'
                                                          for row in attempted) else 'complete_with_failures')
        index['overnight_qualified_counts'] = counts_for_indexes({path: index})[str(index['target_count_per_episode'])]
        index['overnight_updated_at'] = stamp()
        atomic_json(path, index)

    def find_scenario(self, job):
        path = Path(job['dataset_index'])
        row = next(row for row in self.indexes[path]['episodes']
                   if row['split'] == job['split'] and row['episode_index'] == job['episode_index'])
        return path, row

    def apply_job(self, job, process_code=None, forced_reason=None):
        path, row = self.find_scenario(job)
        result_path = Path(job['result_path'])
        try:
            result = read_json(result_path)
            if not isinstance(result, dict):
                raise ValueError('Result is not an object')
        except (OSError, ValueError) as exc:
            result = {'capture_complete': False, 'exit_code': process_code if process_code is not None else -1,
                      'qualified_training_episode': False, 'reports': [],
                      'verification_result': 'NOT_RUN', 'expected_runs': 1,
                      'reported_runs': 0, 'manifest_episodes': 0,
                      'result_error': str(exc)}
            # Preserve malformed worker output separately; never overwrite it.
            atomic_json(result_path.with_name(result_path.stem+'.runner_failure.json'), result)
        if forced_reason:
            result['qualified_training_episode'] = False
            result['runner_termination_reason'] = forced_reason
            result['timed_out'] = 'deadline' in forced_reason or 'timeout' in forced_reason
        result['runner_job_id'] = job['job_id']
        result['runner_result_path'] = str(result_path)
        row['collection'] = result
        row['collection_status'] = 'completed' if result.get('capture_complete') is True else 'failed_process'
        self.update_index(path)
        job.update(status='finished', finished_at=stamp(),
                   process_exit_code=process_code, qualified_training_episode=eligible(row))
        if forced_reason:
            job['termination_reason'] = forced_reason
        self.log(f'Collection {job["job_id"]}: qualified={eligible(row)}, capture={result.get("capture_complete")}')
        self.save()

    def recover(self):
        for job in self.state['jobs']:
            if job.get('status') == 'finished':
                continue
            pid = job.get('pid')
            if pid and process_start_ticks(pid) == job.get('proc_start_ticks'):
                try:
                    command = Path(f'/proc/{pid}/cmdline').read_bytes()
                    if str(job['result_path']).encode() not in command:
                        raise ValueError('PID identity differs from recorded collector')
                    os.killpg(pid, signal.SIGTERM)
                    deadline = time.monotonic()+5
                    while process_start_ticks(pid) == job.get('proc_start_ticks') and time.monotonic() < deadline:
                        time.sleep(.1)
                    if process_start_ticks(pid) == job.get('proc_start_ticks'):
                        os.killpg(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            reason = None if Path(job['result_path']).is_file() else 'interrupted_before_result_on_resume'
            self.apply_job(job, forced_reason=reason)
        for path, index in self.indexes.items():
            changed = False
            for row in index['episodes']:
                if (row.get('collection_status') == 'not_started'
                        and episode_directory(path, row).exists()):
                    row['collection_status'] = 'failed_process'
                    row['collection'] = {'capture_complete': False, 'exit_code': -1,
                                         'qualified_training_episode': False, 'reports': [],
                                         'verification_result': 'NOT_RUN',
                                         'failure_reason': 'preexisting_episode_directory_preserved'}
                    changed = True
            if changed:
                self.update_index(path)
        for round_ in self.state['rounds']:
            if round_.get('status') in ('training', 'pending'):
                report_path = Path(round_['output_dir'])/'training_report.json'
                if report_path.is_file():
                    self.finish_round(round_, None)
                else:
                    round_.update(status='interrupted', finished_at=stamp(),
                                  termination_reason='partial_round_preserved_on_resume', gate_pass=False)
        final = self.state.get('final_evaluation')
        if final and final.get('status') == 'running':
            final.update(status='interrupted', finished_at=stamp(),
                         termination_reason='final_evaluation_is_never_repeated_on_resume')
        self.save()

    def collection_budget(self):
        remaining = (self.cutoffs['collection']-utcnow()).total_seconds()-45
        if remaining < self.args.minimum_collection_budget_s:
            return None
        verify = min(self.args.verify_timeout_s, max(30, remaining*.2))
        collect = min(self.args.collection_timeout_s, remaining-verify-15)
        return max(1, int(collect)), max(1, int(verify))

    def start_collection(self, path, row):
        budget = self.collection_budget()
        if budget is None:
            return False
        collect, verify = budget
        count = self.indexes[path]['target_count_per_episode']
        job_id = f'{count}target_{row["split"]}_{row["episode_index"]:06d}'
        result_path = self.base/'jobs'/f'{job_id}.json'
        if result_path.exists():
            raise ValueError(f'Existing job result must be resumed: {result_path}')
        command = [sys.executable, str(HERE/'collect_random_episode.py'),
                   '--dataset-index', str(path), '--split', row['split'],
                   '--episode-index', str(row['episode_index']), '--result', str(result_path),
                   '--timeout-s', str(collect), '--verify-timeout-s', str(verify)]
        job = {'job_id': job_id, 'dataset_index': str(path), 'split': row['split'],
               'episode_index': row['episode_index'], 'random_seed': row['random_seed'],
               'target_count': count, 'result_path': str(result_path),
               'command': command, 'started_at': stamp(), 'status': 'starting',
               'timeout_s': collect+verify+30}
        self.state['jobs'].append(job)
        self.save()  # Journal before starting a process.
        result_path.parent.mkdir(exist_ok=True)
        atomic_json(result_path.with_suffix('.command.json'), job)
        log = result_path.with_suffix('.stdout.log').open('a', encoding='utf-8')
        process = subprocess.Popen(command, cwd=HERE, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        job.update(status='running', pid=process.pid, proc_start_ticks=process_start_ticks(process.pid))
        self.active[job_id] = {'process': process, 'log': log, 'job': job,
                               'started_monotonic': time.monotonic()}
        self.log(f'Started {job_id}, collection/verify budgets={collect}/{verify}s')
        self.save()
        return True

    def collect_until(self, quotas):
        self.state['status'] = 'collecting'
        self.state['current_quotas'] = quotas
        self.save()
        reason = None
        last_heartbeat = time.monotonic()
        while True:
            for job_id, item in list(self.active.items()):
                process, job = item['process'], item['job']
                forced = None
                if self.stop_reason:
                    forced = self.stop_reason
                elif utcnow() >= self.cutoffs['collection']:
                    forced = 'collection_deadline'
                elif time.monotonic()-item['started_monotonic'] >= job['timeout_s']:
                    forced = 'collector_outer_timeout'
                if forced:
                    terminate_group(process)
                if process.poll() is not None:
                    item['log'].close()
                    self.apply_job(job, process.returncode, forced)
                    del self.active[job_id]
            if self.stop_reason:
                reason = self.stop_reason
            elif quotas_met(self.indexes, quotas):
                if not self.active:
                    return True, 'qualified_quotas_met'
            elif utcnow() >= self.cutoffs['collection']:
                reason = 'collection_deadline'
            if reason and not self.active:
                return False, reason
            while not reason and len(self.active) < self.args.workers:
                active_keys = {scenario_key(Path(item['job']['dataset_index']), item['job'])
                               for item in self.active.values()}
                chosen = choose_scenario(self.indexes, quotas, active_keys)
                if chosen is None:
                    if not self.active:
                        return False, 'frozen_scenarios_exhausted_before_qualified_quotas'
                    break
                if not self.start_collection(*chosen):
                    reason = 'insufficient_collection_budget'
                    break
            if reason and not self.active:
                return False, reason
            if time.monotonic()-last_heartbeat > 30:
                self.log(f'Collection progress: {counts_for_indexes(self.indexes)}; active={len(self.active)}')
                self.save()
                last_heartbeat = time.monotonic()
            time.sleep(.5)

    def train_command(self, output, number, evaluate=False):
        command = [sys.executable, str(HERE/'train_behavior_cloning.py'),
                   '--dataset-index', *map(str, self.index_paths),
                   '--min-episodes-per-split', str(2*number), '1', '1',
                   '--epochs', str((100, 150, 200)[number-1]), '--patience', '20',
                   '--threads', str(self.args.threads), '--seed', str(self.args.training_seed+number-1),
                   '--cache-dir', str(self.base/'cache'), '--output-dir', str(output)]
        command.append('--evaluate-only' if evaluate else '--defer-test')
        return command

    def run_bounded(self, command, log_path, cutoff, minimum_budget, record):
        remaining = (cutoff-utcnow()).total_seconds()-20
        if self.stop_reason or remaining < minimum_budget:
            record.update(status='not_started', termination_reason=self.stop_reason or 'insufficient_time_budget')
            self.save()
            return None
        atomic_json(Path(log_path).with_suffix('.command.json'), {'command': command, 'started_at': stamp()})
        with Path(log_path).open('a', encoding='utf-8') as log:
            process = subprocess.Popen(command, cwd=HERE, stdout=log, stderr=subprocess.STDOUT,
                                       start_new_session=True)
            record.update(pid=process.pid, proc_start_ticks=process_start_ticks(process.pid))
            self.save()
            last_heartbeat = time.monotonic()
            while process.poll() is None:
                if self.stop_reason or utcnow() >= cutoff:
                    reason = self.stop_reason or 'stage_deadline'
                    terminate_group(process)
                    record['termination_reason'] = reason
                    self.save()
                    break
                if time.monotonic()-last_heartbeat > 30:
                    self.log(f'Process {process.pid} running; output={log_path}')
                    self.save()
                    last_heartbeat = time.monotonic()
                time.sleep(.5)
            return process.returncode

    def finish_round(self, round_, process_code):
        round_['finished_at'] = stamp()
        round_['process_exit_code'] = process_code
        try:
            report = read_json(Path(round_['output_dir'])/'training_report.json')
            metrics = validation_result(report)
            round_.update(status='completed', validation=metrics, gate_pass=metrics['gate_pass'])
            if process_code not in (None, 0):
                round_['gate_pass'] = False
                round_['process_failed'] = True
            if round_.get('termination_reason'):
                round_['gate_pass'] = False
        except (OSError, ValueError, KeyError, TypeError) as exc:
            round_.update(status='failed', gate_pass=False, report_error=str(exc))
        self.log(f'Round {round_["number"]} {round_["status"]}; gate={round_["gate_pass"]}')
        self.save()

    def train_round(self, number):
        output = self.base/f'round_{number:02d}'
        if output.exists():
            raise ValueError(f'Existing round directory is preserved: {output}')
        round_ = {'number': number, 'output_dir': str(output), 'started_at': stamp(),
                  'status': 'training', 'quotas': quotas_for_round(number),
                  'qualified_counts': counts_for_indexes(self.indexes)}
        self.state['rounds'].append(round_)
        self.state['status'] = 'training'
        command = self.train_command(output, number)
        round_['command'] = command
        self.save()
        self.log(f'Training round {number}; test deferred')
        code = self.run_bounded(command, self.base/f'round_{number:02d}.stdout.log',
                                self.cutoffs['training'], self.args.minimum_training_budget_s, round_)
        if code is None:
            round_.update(gate_pass=False, finished_at=stamp())
            self.save()
        else:
            self.finish_round(round_, code)
        return round_

    def final_evaluation(self):
        if self.state.get('final_evaluation'):
            return
        candidates = [item for item in self.state['rounds']
                      if item.get('status') == 'completed' and 'validation' in item]
        if not candidates:
            self.state['final_evaluation'] = {'status': 'not_run', 'reason': 'no_completed_training_round'}
            return
        best = min(candidates, key=lambda item: (item['validation']['vision_normalized_mse'], item['number']))
        self.state['selected_round'] = best['number']
        self.state['selection_reason'] = 'lowest_heldout_validation_rgb_state_normalized_mse'
        record = {'status': 'running', 'round': best['number'], 'started_at': stamp(),
                  'selection_split': 'validation', 'test_used_for_selection': False}
        self.state['final_evaluation'] = record
        self.state['status'] = 'final_evaluation'
        command = self.train_command(Path(best['output_dir']), best['number'], evaluate=True)
        record['command'] = command
        self.save()  # This journal also enforces at most one final test invocation.
        self.log(f'Final evaluation of validation-selected round {best["number"]}')
        code = self.run_bounded(command, self.base/'final_evaluation.stdout.log',
                                self.cutoffs['final'], self.args.minimum_evaluation_budget_s, record)
        record.update(status='completed' if code == 0 else 'failed' if code is not None else 'not_started',
                      process_exit_code=code, finished_at=stamp())
        report_path = Path(best['output_dir'])/'training_report.json'
        if report_path.is_file():
            record['report'] = str(report_path)
            report = read_json(report_path)
            record['reported_test_status'] = report.get('test_status')
        self.save()

    def package(self):
        """Bundle scripts, checkpoints and small reports; exclude RGB and cache."""
        self.state['status'] = 'packaging'
        self.save()
        destination = self.base/'night_artifacts.zip'
        temporary = destination.with_suffix('.zip.tmp')
        candidates = []
        for path in self.base.rglob('*'):
            if not path.is_file() or path == destination or path == temporary:
                continue
            relative = path.relative_to(self.base)
            if any(part in ('cache', 'episodes', '__pycache__', '.git') for part in relative.parts):
                continue
            if path.suffix.lower() in ('.png', '.npz', '.npy', '.mp4', '.avi', '.gif'):
                continue
            if path.name == 'runner.lock' or '.tmp.' in path.name:
                continue
            if path.stat().st_size <= self.args.archive_max_file_mb*1024**2:
                candidates.append(path)
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=3) as archive:
            for path in sorted(candidates):
                if utcnow() >= self.cutoffs['hard']:
                    self.state['archive_truncated_by_deadline'] = True
                    break
                archive.write(path, path.relative_to(self.base))
        os.replace(temporary, destination)
        self.state['archive'] = str(destination)
        self.state['archive_excludes'] = ['episode RGB/data directories', 'cache', 'large files over configured limit']

    def finish(self, reason, failed=False):
        for item in list(self.active.values()):
            terminate_group(item['process'])
            item['log'].close()
            self.apply_job(item['job'], item['process'].returncode, reason)
        self.active.clear()
        self.state.update(termination_reason=reason, finished_at=stamp(),
                          final_status='failed' if failed else 'completed')
        atomic_json(self.base/'night_report.json', self.report())
        try:
            self.package()
        except Exception as exc:
            self.state['archive_error'] = f'{type(exc).__name__}: {exc}'
            self.log(f'Packaging failed: {exc}')
        self.state['status'] = self.state['final_status']
        self.save()
        atomic_json(self.base/'night_report.json', self.report())
        # Include final, rather than pre-packaging, state in the small archive.
        if self.state.get('archive') and utcnow() < self.cutoffs['hard']:
            with zipfile.ZipFile(self.state['archive'], 'a', compression=zipfile.ZIP_DEFLATED) as archive:
                for name in ('progress.json', 'night_report.json'):
                    archive.write(self.base/name, 'final/'+name)
        self.log(f'Finished: {reason}; report={self.base/"night_report.json"}')

    def report(self):
        return {'schema_version': 1, 'run_id': self.state['run_id'],
                'status': self.state.get('final_status', self.state['status']),
                'termination_reason': self.state.get('termination_reason'),
                'started_at': self.state['started_at'], 'finished_at': self.state.get('finished_at'),
                'deadlines': self.state['deadlines'],
                'qualified_counts': counts_for_indexes(self.indexes),
                'collection_attempts': len(self.state['jobs']),
                'qualified_collection_jobs': sum(job.get('qualified_training_episode') is True for job in self.state['jobs']),
                'failed_collection_jobs_preserved': [job['job_id'] for job in self.state['jobs']
                                                    if job.get('qualified_training_episode') is not True],
                'rounds': self.state['rounds'],
                'selected_round': self.state.get('selected_round'),
                'selection_reason': self.state.get('selection_reason'),
                'test_used_for_selection': False,
                'final_evaluation': self.state.get('final_evaluation'),
                'closed_loop_navigation': 'NOT_RUN',
                'archive': self.state.get('archive'), 'archive_error': self.state.get('archive_error'),
                'scope': 'Offline heldout-layout action prediction; no closed-loop policy or endpoint accuracy claim'}

    def run(self):
        self.recover()
        if self.state.get('final_status'):
            self.log('Run already finalized; no collection, training or test repeated')
            return 0
        reason = 'maximum_rounds_completed'
        for number in range(1, self.args.max_rounds+1):
            existing = next((item for item in self.state['rounds'] if item['number'] == number), None)
            if existing:
                if existing.get('gate_pass') is not True:
                    reason = f'round_{number:02d}_gate_failed_or_interrupted'
                    break
                continue
            previous = next((item for item in self.state['rounds'] if item['number'] == number-1), None)
            if number > 1 and (not previous or previous.get('gate_pass') is not True):
                reason = 'previous_round_did_not_pass_validation_gate'
                break
            ready, collection_reason = self.collect_until(quotas_for_round(number))
            if not ready:
                reason = collection_reason
                break
            round_ = self.train_round(number)
            if round_.get('gate_pass') is not True:
                reason = f'round_{number:02d}_validation_gate_failed'
                break
        if not self.stop_reason:
            self.final_evaluation()
        self.finish(self.stop_reason or reason)
        return 0


def self_check():
    """Exercise real scheduling, validation gate and process-group termination."""
    def row(split, number, ok=False):
        result = {'capture_complete': True, 'exit_code': 0,
                  'qualified_training_episode': True, 'verification_result': 'PASS',
                  'reports': [{'result': 'PASS'}]}
        return {'split': split, 'episode_index': number,
                'collection_status': 'completed' if ok else 'not_started',
                'collection': result if ok else {}}
    indexes = {Path(f'/tmp/selfcheck/{count}/dataset_index.json'): {
        'target_count_per_episode': count,
        'episodes': [row(split, number) for split in SPLITS for number in range(8)]}
        for count in (3, 5)}
    choices = []
    while not quotas_met(indexes, quotas_for_round(1)):
        path, scenario = choose_scenario(indexes, quotas_for_round(1))
        choices.append((indexes[path]['target_count_per_episode'], scenario['split'], scenario['episode_index']))
        scenario.update(row(scenario['split'], scenario['episode_index'], True))
    assert len(choices) == 8
    assert all(counts == {'train': 2, 'validation': 1, 'test': 1}
               for counts in counts_for_indexes(indexes).values())
    assert choose_scenario(indexes, quotas_for_round(1)) is None
    assert choose_scenario(indexes, quotas_for_round(2))[1]['split'] == 'train'
    path, scenario = choose_scenario(indexes, quotas_for_round(2))
    key = scenario_key(path, scenario)
    second = choose_scenario(indexes, quotas_for_round(2), [key])
    assert scenario_key(*second) != key
    scenario['collection_status'] = 'failed_process'
    assert choose_scenario(indexes, quotas_for_round(2))[1] is not scenario
    report = {'training_pipeline_result': 'PASS',
              'models': [{'model': name, 'validation': {'all': {'normalized_mse': value}}}
                         for name, value in [('rgb_state_bc', .1), ('state_only_bc', .2)]],
              'baselines': {'zero_hold': {'all': {'normalized_mse': .3}}},
              'test': {'normalized_mse': 999}}
    assert validation_result(report)['gate_pass'] is True
    report['models'][0]['validation']['all']['normalized_mse'] = .4
    assert validation_result(report)['gate_pass'] is False
    with tempfile.TemporaryDirectory(prefix='night-runner-check-') as temporary:
        path = Path(temporary)/'progress.json'
        atomic_json(path, {'state': 'complete'})
        assert read_json(path) == {'state': 'complete'}
        assert not list(Path(temporary).glob('*.tmp.*'))
        process = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(30)'],
                                   start_new_session=True)
        assert process_start_ticks(process.pid) is not None
        terminate_group(process, grace=.5)
        assert process.poll() is not None
    print(json.dumps({'result': 'PASS', 'checks': [
        'deterministic eight-scene first quotas', 'later rounds add train only',
        'inflight slots reserve quotas', 'failed scenes remain excluded',
        'validation-only gate', 'atomic state JSON', 'process-group termination'],
        'real_collection_or_training_started': False}, indent=2))
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--base-dir', type=Path, default=DEFAULT_BASE)
    parser.add_argument('--dataset-index', type=Path, nargs=2, default=None)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--self-check', action='store_true')
    parser.add_argument('--workers', type=int, choices=(1, 2), default=2)
    parser.add_argument('--max-rounds', type=int, choices=(1, 2, 3), default=3)
    parser.add_argument('--threads', type=int, default=2)
    parser.add_argument('--training-seed', type=int, default=20261023)
    parser.add_argument('--collection-timeout-s', type=int, default=2400)
    parser.add_argument('--verify-timeout-s', type=int, default=600)
    parser.add_argument('--minimum-collection-budget-s', type=int, default=3000)
    parser.add_argument('--minimum-training-budget-s', type=int, default=900)
    parser.add_argument('--minimum-evaluation-budget-s', type=int, default=300)
    parser.add_argument('--archive-max-file-mb', type=int, default=32)
    parser.add_argument('--collection-deadline', default='2026-10-22T23:00:00Z')
    parser.add_argument('--training-deadline', default='2026-10-22T23:25:00Z')
    parser.add_argument('--final-deadline', default='2026-10-22T23:45:00Z')
    parser.add_argument('--hard-deadline', default='2026-10-23T00:00:00Z')
    args = parser.parse_args(argv)
    if args.self_check:
        return self_check()
    if min(args.threads, args.collection_timeout_s, args.verify_timeout_s,
           args.minimum_collection_budget_s, args.minimum_training_budget_s,
           args.minimum_evaluation_budget_s, args.archive_max_file_mb) <= 0:
        parser.error('Timeouts, minimum budgets, threads and archive limit must be positive')
    runner = None
    try:
        runner = NightRunner(args)
        def stop(signum, frame):
            runner.stop_reason = f'received_signal_{signal.Signals(signum).name}'
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        return runner.run()
    except Exception as exc:
        if runner is not None:
            runner.log(f'Fatal error: {type(exc).__name__}: {exc}\n{traceback.format_exc()}')
            runner.finish(f'{type(exc).__name__}: {exc}', failed=True)
        else:
            print(f'Cannot start night runner: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 1
    finally:
        if runner is not None:
            runner.log_stream.close()
            runner.lock.close()


if __name__ == '__main__':
    raise SystemExit(main())
