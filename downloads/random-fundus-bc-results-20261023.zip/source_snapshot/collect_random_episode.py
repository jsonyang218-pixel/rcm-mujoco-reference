#!/usr/bin/env python3
"""Collect and verify one frozen random scenario; never rewrite its index.

The overnight parent owns index updates. This worker writes an independent
result even on timeout/failure and preserves all partial observations and logs.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


HERE = Path(__file__).resolve().parent
ACTIVE_CHILD = None


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    temporary.replace(path)


def read_json(path, default=None):
    path = Path(path)
    return json.loads(path.read_text(encoding='utf-8-sig')) if path.is_file() else default


def stop_child():
    global ACTIVE_CHILD
    if ACTIVE_CHILD is not None and ACTIVE_CHILD.poll() is None:
        ACTIVE_CHILD.terminate()
        try:
            ACTIVE_CHILD.wait(timeout=8)
        except subprocess.TimeoutExpired:
            ACTIVE_CHILD.kill()
            ACTIVE_CHILD.wait(timeout=5)


def interrupted(signum, frame):
    stop_child()
    raise InterruptedError(f'Worker interrupted by signal {signum}')


def run_process(command, log_path, timeout_s, environment):
    global ACTIVE_CHILD
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    with log_path.open('w', encoding='utf-8') as log:
        # Inherit the worker session so the parent's killpg reaches the entire
        # worker/collector tree. These Python commands launch no extra jobs.
        ACTIVE_CHILD = subprocess.Popen(command, cwd=HERE, env=environment,
                                        stdout=log, stderr=subprocess.STDOUT)
        try:
            code = ACTIVE_CHILD.wait(timeout=timeout_s)
            return code, False, time.monotonic()-started
        except subprocess.TimeoutExpired:
            stop_child()
            return 124, True, time.monotonic()-started
        finally:
            ACTIVE_CHILD = None


def summarize_capture(directory, exit_code, verification_exit_code=None):
    directory = Path(directory)
    reports = read_json(directory/'run_reports.json', [])
    manifest = read_json(directory/'dataset/manifest.json', {})
    episodes = manifest.get('episodes', [])
    expected = Counter({('visual_servo', None): 1})
    captured = Counter((row.get('method'), row.get('seed')) for row in episodes)
    reported = Counter((row.get('method'), row.get('seed')) for row in reports)
    complete = len(reports) == len(episodes) == 1 and captured == reported == expected
    verification = read_json(directory/'dataset_verification.json', {})
    quality = complete and exit_code == 0 and verification_exit_code == 0 and verification.get('result') == 'PASS'
    for report in reports:
        quality = quality and report.get('result') == 'PASS'
        quality = quality and report.get('trajectory_rate_limits_pass') is True
        quality = quality and report.get('fundus_transition_constraints_pass') is True
        quality = quality and report.get('tip_outside_eye_samples') == 0
        quality = quality and report.get('stop_constraint_summary', {}).get('pass') is True
        quality = quality and bool(report.get('waypoints'))
        for waypoint in report.get('waypoints', []):
            error = waypoint.get('tip_error_um')
            quality = quality and waypoint.get('result') == 'PASS' and waypoint.get('success_with_stop') is True
            quality = quality and isinstance(error, (int, float)) and 0 <= error < 20.
    quality = quality and all(row.get('result') == 'PASS' and
                              row.get('stop_constraint_summary', {}).get('pass') is True for row in episodes)
    return {'exit_code': exit_code, 'capture_complete': bool(complete), 'expected_runs': 1,
            'reported_runs': len(reports), 'manifest_episodes': len(episodes), 'reports': reports,
            'verification_exit_code': verification_exit_code,
            'verification_result': verification.get('result', 'NOT_RUN'),
            'qualified_training_episode': bool(quality),
            'frames': int(manifest.get('total_frames', 0)),
            'quality_scope': 'complete capture, navigation PASS, per-target <20um and stop, rate/eye/fundus constraints, independent dataset verification PASS'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset-index', type=Path, required=True)
    parser.add_argument('--split', choices=('train', 'validation', 'test'), required=True)
    parser.add_argument('--episode-index', type=int, required=True)
    parser.add_argument('--result', type=Path, required=True)
    parser.add_argument('--timeout-s', type=float, default=2400.)
    parser.add_argument('--verify-timeout-s', type=float, default=600.)
    args = parser.parse_args(argv)
    if args.timeout_s <= 0 or args.verify_timeout_s <= 0:
        parser.error('Timeouts must be positive')
    identity = {'dataset_index': str(args.dataset_index.resolve()), 'split': args.split,
                'episode_index': args.episode_index}
    if args.result.exists():
        existing = read_json(args.result)
        if any(existing.get(key) != value for key, value in identity.items()):
            parser.error('Existing result belongs to a different scenario')
        print(json.dumps({'status': 'existing_result_preserved', **identity}), flush=True)
        return 0
    started = time.monotonic()
    result = {**identity, 'worker_pid': os.getpid(), 'started_utc': datetime.now(timezone.utc).isoformat(),
              'capture_complete': False, 'qualified_training_episode': False,
              'exit_code': None, 'timed_out': False, 'verification_result': 'NOT_RUN'}
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        index = read_json(args.dataset_index)
        root = args.dataset_index.resolve().parent
        scenario = next(row for row in index['episodes'] if row['split'] == args.split
                        and row['episode_index'] == args.episode_index)
        if index.get('strict_visual') is not True or index.get('methods') != ['visual_servo']:
            raise ValueError('Only frozen strict visual-servo scenarios are supported')
        target_path = (root/scenario['targets']).resolve(strict=True)
        config_path = (root/index['config_snapshot']).resolve(strict=True)
        if not target_path.is_relative_to(root) or not config_path.is_relative_to(root):
            raise ValueError('Frozen input path escapes dataset root')
        if hashlib.sha256(target_path.read_bytes()).hexdigest() != scenario['targets_sha256']:
            raise ValueError('Frozen target file changed')
        if hashlib.sha256(config_path.read_bytes()).hexdigest() != index['config_sha256']:
            raise ValueError('Frozen collection configuration changed')
        directory = root/'episodes'/args.split/f'episode_{args.episode_index:06d}'
        directory.parent.mkdir(parents=True, exist_ok=True)
        log_path = directory.parent/(directory.name+'.stdout.log')
        verify_log = directory.parent/(directory.name+'.verification.log')
        environment = dict(os.environ)
        environment.update(MUJOCO_GL='egl', MPLBACKEND='Agg', LP_NUM_THREADS='1',
                           OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
                           MESA_SHADER_CACHE_DIR='/workspace/.cache/mesa',
                           MPLCONFIGDIR='/workspace/.cache/matplotlib', XDG_CACHE_HOME='/workspace/.cache')
        command = [sys.executable, str(HERE/'run_waypoint_comparison.py'), '--targets', str(target_path),
                   '--config', str(config_path), '--output-dir', str(directory), '--profile', 'precision',
                   '--planner-feedback', 'vision', '--methods', 'visual_servo', '--strict-visual',
                   '--sampling-frequency-hz', str(index['sampling_frequency_hz']),
                   '--task-regime', 'visual_current_target', '--start-task',
                   *map(str, scenario['start_task_A_deg_B_deg_C_mm']),
                   '--baseline-dir', str(root/'no_baseline')]
        result.update(command=command, log=str(log_path), output_dir=str(directory),
                      targets_sha256=scenario['targets_sha256'], config_sha256=index['config_sha256'],
                      target_count=scenario['target_count'], random_seed=scenario['random_seed'])
        if directory.exists():
            # A partial prior attempt is evidence; never overwrite it on resume.
            raise FileExistsError('Episode output already exists without a worker result; preserved for manual review')
        code, timed_out, wall = run_process(command, log_path, args.timeout_s, environment)
        result.update(exit_code=code, timed_out=timed_out, collector_wall_s=wall)
        verification_code = None
        if (directory/'run_reports.json').is_file() and (directory/'dataset/manifest.json').is_file():
            verify_command = [sys.executable, str(HERE/'verify_waypoint_comparison.py'), '--run-dir', str(directory)]
            verification_code, verification_timeout, verification_wall = run_process(
                verify_command, verify_log, args.verify_timeout_s, environment)
            result.update(verification_command=verify_command, verification_log=str(verify_log),
                          verification_timed_out=verification_timeout, verification_wall_s=verification_wall)
        result.update(summarize_capture(directory, code, verification_code))
    except Exception as exc:
        stop_child()
        result.update(worker_error=f'{type(exc).__name__}: {exc}')
        if result['exit_code'] is None:
            result['exit_code'] = 130 if isinstance(exc, InterruptedError) else 2
    finally:
        result['worker_wall_s'] = time.monotonic()-started
        result['finished_utc'] = datetime.now(timezone.utc).isoformat()
        write_json(args.result, result)
    print(json.dumps({key: result.get(key) for key in ('split', 'episode_index', 'target_count', 'exit_code',
                                                      'frames', 'verification_result', 'qualified_training_episode', 'worker_error')},
                     ensure_ascii=False), flush=True)
    return 0 if result['qualified_training_episode'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
