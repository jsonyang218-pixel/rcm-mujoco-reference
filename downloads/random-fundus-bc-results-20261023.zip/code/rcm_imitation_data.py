"""NumPy/Pillow preparation for a small RGB + axis-feedback BC baseline.

Public API::

    batch = prepare_episode_dataset(dataset_root, cache_dir,
                                    image_size=96, roi_size=64, max_frames=None)
    views = preprocess_rgb(rgb_uint8, image_size=96, roi_size=64)

The returned dictionary contains:

* ``global_rgb``: uint8 [N, image_size, image_size, 3], resized raw RGB.
* ``target_roi_rgb``: uint8 [N, roi_size, roi_size, 3], an unscaled square
  crop centred on an orange feature detected in the *current raw RGB*.
  A missing target produces a black crop. This is a colour heuristic, not a
  calibrated detector, and never consumes simulation masks or target truth.
* ``visual_features``: float32 [N, 3] = [x, y, visible], with image coordinates
  normalized to [-1, 1]; missing coordinates are zero and visible is zero.
* ``state``, ``action``, ``delta``: float32 [N, 3], in [A degrees, B degrees,
  C millimetres]. Action is the recorded next absolute command; delta is
  action - state. All original rows are checked for action/next-state alignment
  before optional subsampling; the final hold command is retained.
* ``dt_seconds``: float64 [N], actual forward timestamp interval. The final
  row of each episode uses that episode's median regular interval, because
  the recording has no next timestamp. ``sample_weight`` is float32 [N],
  dt / median_regular_dt. Thus nanosecond stitching intervals have negligible
  weight without silently relabelling them as regular control steps.
* ``audit``: list of N dictionaries for reporting ONLY, containing source row
  IDs, phase, waypoint, visibility, perception, timestamps and terminal flags.
* ``metadata``: configuration, source SHA-256 hashes, alignment validation,
  units, detector limits, source resolution, sampling and cache provenance.

Only global_rgb, target_roi_rgb, visual_features and state are policy inputs.
Action/delta are labels and sample_weight is a loss weight. Neither audit nor
metadata, task text, paths, timestamps, row numbers, phase, waypoints, dynamic
truth, depth, segmentation or teacher perception may enter the policy.

Cache files are content addressed NPZ + JSON with no pickle. Images are selected
before reading/decoding, including when max_frames is used. Original datasets
are read only; cache_dir must be outside dataset_root. This module imports no
PyTorch, simulator, segmentation or controller code.
"""

from __future__ import annotations

from collections import deque
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from typing import Any
from uuid import uuid4

import numpy as np
from PIL import Image


_CACHE_VERSION = 1
_POLICY_KEYS = {"observation.images.microscope_rgb", "observation.state", "task"}
_ARRAY_KEYS = ("global_rgb", "target_roi_rgb", "visual_features", "state",
               "action", "delta", "dt_seconds", "sample_weight")


def _contained_path(root: Path, relative: str) -> Path:
    """Resolve an existing relative source path without allowing symlink escapes."""
    rel = Path(relative)
    if not relative or rel.is_absolute() or ".." in rel.parts:
        raise ValueError(f"Unsafe dataset-relative path: {relative!r}")
    resolved = (root / rel).resolve(strict=True)
    if not resolved.is_relative_to(root) or not resolved.is_file():
        raise ValueError(f"Source escapes dataset root or is not a file: {relative!r}")
    return resolved


def _hash_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _array_float32(value: np.ndarray, name: str, n: int) -> np.ndarray:
    if value.shape != (n, 3) or not np.issubdtype(value.dtype, np.number):
        raise ValueError(f"{name} must have numeric shape ({n}, 3), got {value.shape}")
    if not np.isfinite(value).all():
        raise ValueError(f"{name} contains nonfinite values")
    result = np.asarray(value, dtype=np.float32)
    if not np.isfinite(result).all():
        raise ValueError(f"{name} overflows float32")
    return result


def _detect_target_rgb(rgb: np.ndarray) -> tuple[tuple[float, float] | None, int]:
    """Largest small 8-connected orange RGB component; no other observations."""
    red = rgb[..., 0].astype(np.int16)
    green = rgb[..., 1].astype(np.int16)
    blue = rgb[..., 2].astype(np.int16)
    mask = ((red >= 160) & (green >= 45) & (green <= 210)
            & (red > green + 25) & (green > blue + 25))
    ys, xs = np.nonzero(mask)
    # Refuse ambiguous, widespread orange backgrounds rather than hallucinate a
    # centre. Bounds are fixed configuration, not taken from audit/truth.
    if len(xs) < 3 or len(xs) > 65536:
        return None, 0
    width = rgb.shape[1]
    remaining = set((ys.astype(np.int64) * width + xs).tolist())
    best: list[int] = []
    while remaining:
        start = min(remaining)
        remaining.remove(start)
        queue = deque([start])
        component = [start]
        while queue:
            pixel = queue.popleft()
            y, x = divmod(pixel, width)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if (dx == 0 and dy == 0) or not (0 <= x + dx < width):
                        continue
                    adjacent = (y + dy) * width + x + dx
                    if adjacent in remaining:
                        remaining.remove(adjacent)
                        queue.append(adjacent)
                        component.append(adjacent)
        if len(component) > len(best):
            best = component
    coords = np.asarray(best, dtype=np.int64)
    yy, xx = coords // width, coords % width
    if not 3 <= len(best) <= 4096 or np.ptp(xx) > 127 or np.ptp(yy) > 127:
        return None, 0
    return (float(xx.mean()), float(yy.mean())), len(best)


def _preprocess_rgb_with_audit(rgb: np.ndarray, image_size: int,
                               roi_size: int) -> tuple[dict[str, np.ndarray],
                                                       tuple[float, float] | None, int]:
    """Apply the identical RGB-only preprocessing at training and inference.

    Returns global_rgb [S,S,3] uint8, target_roi_rgb [R,R,3] uint8 and
    visual_features [3] float32. Input must be original RGB uint8 [H,W,3].
    Missing target centres are represented as [0,0,0], never guessed from
    earlier frames or teacher state. Detection/resize/crop are deterministic.
    """
    for name, value in (("image_size", image_size), ("roi_size", roi_size)):
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f"{name} must be a positive integer")
    if not isinstance(rgb, np.ndarray) or rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3:
        raise ValueError("rgb must be a uint8 [H,W,3] NumPy array")
    height, width, _ = rgb.shape
    if min(height, width) < max(image_size, roi_size):
        raise ValueError("Source image resolution is smaller than requested views")
    image = Image.fromarray(rgb)
    output = {
        "global_rgb": np.asarray(image.resize((image_size, image_size),
                                               resample=Image.Resampling.BILINEAR)),
        "target_roi_rgb": np.zeros((roi_size, roi_size, 3), dtype=np.uint8),
        "visual_features": np.zeros(3, dtype=np.float32),
    }
    center, pixel_count = _detect_target_rgb(rgb)
    if center is not None:
        x, y = center
        left, top = int(round(x)) - roi_size // 2, int(round(y)) - roi_size // 2
        output["target_roi_rgb"] = np.asarray(image.crop(
            (left, top, left + roi_size, top + roi_size)))
        output["visual_features"][:] = (2 * x / (width - 1) - 1,
                                         2 * y / (height - 1) - 1, 1)
    return output, center, pixel_count


def preprocess_rgb(rgb: np.ndarray, image_size: int = 96,
                   roi_size: int = 64) -> dict[str, np.ndarray]:
    """Prepare RGB-only policy views identically at training and inference.

    Input is original uint8 [H,W,3] RGB. Output contains global_rgb uint8
    [image_size,image_size,3], target_roi_rgb uint8 [roi_size,roi_size,3] and
    visual_features float32 [3] = [normalized_x, normalized_y, visible].
    Missing RGB target centres produce a black crop and [0,0,0] features.
    """
    return _preprocess_rgb_with_audit(rgb, image_size, roi_size)[0]


def _validate_arrays(arrays: dict[str, np.ndarray], n: int,
                     image_size: int, roi_size: int) -> None:
    expected = {
        "global_rgb": (n, image_size, image_size, 3),
        "target_roi_rgb": (n, roi_size, roi_size, 3),
        "visual_features": (n, 3), "state": (n, 3), "action": (n, 3),
        "delta": (n, 3), "dt_seconds": (n,), "sample_weight": (n,),
    }
    if set(arrays) != set(expected):
        raise ValueError("Unexpected cached array keys")
    for key, shape in expected.items():
        value = arrays[key]
        dtype = np.uint8 if key.endswith("rgb") else (np.float64 if key == "dt_seconds" else np.float32)
        if value.shape != shape or value.dtype != dtype:
            raise ValueError(f"Invalid {key}: expected {shape}/{dtype}, got {value.shape}/{value.dtype}")
        if not np.isfinite(value).all():
            raise ValueError(f"Nonfinite {key}")
    if (arrays["dt_seconds"] < 0).any() or (arrays["sample_weight"] < 0).any():
        raise ValueError("Negative time interval or sample weight")
    if not np.array_equal(arrays["delta"], arrays["action"] - arrays["state"]):
        raise ValueError("Delta does not equal float32 action minus state")
    features = arrays["visual_features"]
    if not np.isin(features[:, 2], [0.0, 1.0]).all() or (np.abs(features[:, :2]) > 1).any():
        raise ValueError("Invalid RGB feature coordinates or visibility")


def prepare_episode_dataset(dataset_root: str | Path, cache_dir: str | Path, *,
                            image_size: int = 96, roi_size: int = 64,
                            max_frames: int | None = None) -> dict[str, Any]:
    """Validate raw episodes and prepare cached, explicitly separated policy data.

    max_frames selects deterministic evenly spaced source indices, including
    endpoints when at least two are requested. It is a smoke-test convenience,
    not an independently sampled validation split. Episode boundaries are never
    crossed when checking action/next-state alignment or computing timestamps.
    """
    for name, value in (("image_size", image_size), ("roi_size", roi_size)):
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f"{name} must be a positive integer")
    if max_frames is not None and (isinstance(max_frames, bool)
                                  or not isinstance(max_frames, int) or max_frames <= 0):
        raise ValueError("max_frames must be None or a positive integer")
    root = Path(dataset_root).resolve(strict=True)
    cache = Path(cache_dir).resolve()
    if not root.is_dir():
        raise ValueError("dataset_root must be a directory")
    if cache.is_relative_to(root):
        raise ValueError("cache_dir must be outside the read-only source dataset")
    policy_dir = root / "policy_inputs"
    if policy_dir.resolve().parent != root:
        raise ValueError("policy_inputs must be contained directly in dataset_root")
    policy_files = sorted(policy_dir.glob("episode_*.npz"))
    if not policy_files:
        raise ValueError(f"No policy_inputs episodes under {root}")

    hashes: dict[str, str] = {}
    all_rows: list[dict[str, Any]] = []
    all_states: list[np.ndarray] = []
    all_actions: list[np.ndarray] = []
    all_dt: list[np.ndarray] = []
    all_weights: list[np.ndarray] = []
    image_paths: list[Path] = []
    episode_metadata: list[dict[str, Any]] = []
    for policy_file in policy_files:
        episode = policy_file.stem
        policy_path = _contained_path(root, f"policy_inputs/{episode}.npz")
        label_path = _contained_path(root, f"action_labels/{episode}.npz")
        audit_path = _contained_path(root, f"data/{episode}.jsonl")
        for source in (policy_path, label_path, audit_path):
            hashes[source.relative_to(root).as_posix()] = _hash_file(source)
        with np.load(policy_path, allow_pickle=False) as archive:
            if set(archive.files) != _POLICY_KEYS:
                raise ValueError(f"Unexpected policy input keys in {episode}")
            paths = archive["observation.images.microscope_rgb"]
            if paths.ndim != 1 or paths.dtype.kind not in "US" or not len(paths):
                raise ValueError(f"Invalid RGB path array in {episode}")
            n = len(paths)
            states = _array_float32(archive["observation.state"], "state", n)
            tasks = archive["task"]
            if tasks.shape != (n,) or tasks.dtype.kind not in "US":
                raise ValueError(f"Invalid task text array in {episode}")
        with np.load(label_path, allow_pickle=False) as archive:
            if set(archive.files) != {"action"}:
                raise ValueError(f"Unexpected action label keys in {episode}")
            actions = _array_float32(archive["action"], "action", n)
        rows = [json.loads(line) for line in audit_path.read_text(encoding="utf-8").splitlines()
                if line.strip()]
        if len(rows) != n:
            raise ValueError(f"Audit row count differs from policy row count in {episode}")
        timestamps = np.asarray([row["timestamp"] for row in rows], dtype=np.float64)
        if not np.isfinite(timestamps).all():
            raise ValueError(f"Nonfinite timestamps in {episode}")
        intervals = np.diff(timestamps)
        if (intervals < 0).any():
            raise ValueError(f"Timestamps run backwards in {episode}")
        regular = intervals[intervals > 1e-6]
        if not len(regular):
            raise ValueError(f"No regular positive time interval in {episode}")
        nominal_dt = float(np.median(regular))
        # Alignment uses all consecutive source rows, not sampled rows. These
        # exports use exact float32 next-state labels; reject broken alignment.
        if not np.array_equal(actions[:-1], states[1:]):
            error = np.max(np.abs(actions[:-1] - states[1:]), axis=1)
            bad = np.flatnonzero(error != 0)[:10].tolist()
            raise ValueError(f"Action/next-state float32 mismatch in {episode}, rows {bad}")
        if not rows[-1].get("is_terminal", False) or not np.array_equal(actions[-1], states[-1]):
            raise ValueError(f"Episode {episode} must end with a terminal hold command")
        dt = np.concatenate((intervals, np.asarray([nominal_dt], dtype=np.float64)))
        for i, (relative, row) in enumerate(zip(paths.tolist(), rows)):
            if isinstance(relative, bytes):
                relative = relative.decode("utf-8")
            if row.get("observation.images.microscope_rgb") != relative:
                raise ValueError(f"Audit/policy RGB path mismatch in {episode} row {i}")
            if not np.array_equal(np.asarray(row["observation.state"], dtype=np.float32), states[i]):
                raise ValueError(f"Audit/policy state mismatch in {episode} row {i}")
            if not np.array_equal(np.asarray(row["action"], dtype=np.float32), actions[i]):
                raise ValueError(f"Audit/action label mismatch in {episode} row {i}")
            image_paths.append(_contained_path(root, relative))
            # Audit is deliberately assembled independently from policy arrays.
            all_rows.append({
                "source_episode": episode, "source_row_index": i,
                "image_relative_path": relative,
                **{key: row.get(key) for key in ("timestamp", "episode_index", "frame_index",
                                                "is_terminal", "phase", "waypoint_id",
                                                "visibility", "perception")},
                "dt_seconds": float(dt[i]),
                "dt_is_imputed_terminal": i == n - 1,
            })
        all_states.append(states)
        all_actions.append(actions)
        all_dt.append(dt)
        all_weights.append(np.asarray(dt / nominal_dt, dtype=np.float32))
        episode_metadata.append({"episode": episode, "frames": n,
                                 "nominal_dt_seconds": nominal_dt,
                                 "alignment_checked_pairs": n - 1,
                                 "alignment_max_abs_error_float32": 0.0,
                                 "near_zero_intervals": int(np.sum(intervals <= 1e-6)),
                                 "zero_intervals": int(np.sum(intervals == 0)),
                                 "terminal_hold": True})

    total = len(all_rows)
    count = min(total, max_frames) if max_frames is not None else total
    selected = (np.arange(total, dtype=np.int64) if count == total
                else np.rint(np.linspace(0, total - 1, count)).astype(np.int64))
    # Only selected images are read/hashed/decoded. All input rows above are
    # nevertheless validated, and all path references are containment checked.
    for index in selected:
        path = image_paths[int(index)]
        hashes[path.relative_to(root).as_posix()] = _hash_file(path)
    config = {"version": _CACHE_VERSION, "image_size": image_size, "roi_size": roi_size,
              "max_frames": max_frames, "dataset_root": str(root)}
    fingerprint = sha256(json.dumps({"config": config, "source_hashes": hashes},
                                    sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    cache.mkdir(parents=True, exist_ok=True)
    npz_path = cache / f"episode_dataset_{fingerprint[:20]}.npz"
    json_path = cache / f"episode_dataset_{fingerprint[:20]}.json"
    if npz_path.is_file() and json_path.is_file():
        document = json.loads(json_path.read_text(encoding="utf-8"))
        if document["metadata"].get("fingerprint_sha256") != fingerprint:
            raise ValueError("Cache fingerprint mismatch")
        with np.load(npz_path, allow_pickle=False) as archive:
            arrays = {key: archive[key] for key in archive.files}
        _validate_arrays(arrays, count, image_size, roi_size)
        if len(document["audit"]) != count:
            raise ValueError("Cache audit length mismatch")
        metadata = document["metadata"]
        metadata["cache_hit"] = True
        return {**arrays, "audit": document["audit"], "metadata": metadata}

    states = np.concatenate(all_states)[selected]
    actions = np.concatenate(all_actions)[selected]
    arrays = {"global_rgb": np.zeros((count, image_size, image_size, 3), dtype=np.uint8),
              "target_roi_rgb": np.zeros((count, roi_size, roi_size, 3), dtype=np.uint8),
              "visual_features": np.zeros((count, 3), dtype=np.float32),
              "state": states, "action": actions, "delta": actions - states,
              "dt_seconds": np.concatenate(all_dt)[selected],
              "sample_weight": np.concatenate(all_weights)[selected]}
    audit = [dict(all_rows[int(index)]) for index in selected]
    resolution: tuple[int, int] | None = None
    for output_i, source_i in enumerate(selected):
        path = image_paths[int(source_i)]
        raw = path.read_bytes()
        if sha256(raw).hexdigest() != hashes[path.relative_to(root).as_posix()]:
            raise ValueError(f"Image changed while preparing data: {path.name}")
        with Image.open(BytesIO(raw)) as image:
            if image.mode != "RGB":
                raise ValueError(f"Expected original uint8 RGB, got {image.mode}: {path.name}")
            if resolution is None:
                resolution = image.size
                if min(resolution) < max(image_size, roi_size):
                    raise ValueError("Source image resolution is smaller than requested views")
            elif image.size != resolution:
                raise ValueError(f"Inconsistent image resolution: {image.size} versus {resolution}")
            rgb = np.asarray(image)
            if rgb.dtype != np.uint8 or rgb.shape != (image.height, image.width, 3):
                raise ValueError(f"Invalid RGB image array: {path.name}")
            views, center, pixel_count = _preprocess_rgb_with_audit(rgb, image_size, roi_size)
            for key, value in views.items():
                arrays[key][output_i] = value
            audit[output_i]["rgb_target_center_xy"] = list(center) if center else None
            audit[output_i]["rgb_target_component_pixels"] = pixel_count
    _validate_arrays(arrays, count, image_size, roi_size)
    metadata = {
        **config, "fingerprint_sha256": fingerprint, "cache_hit": False,
        "cache_npz": str(npz_path), "cache_json": str(json_path),
        "source_hashes": hashes, "source_frames": total, "selected_frames": count,
        "image_source_hash_scope": "Every selected original PNG; every input NPZ, label NPZ and audit JSONL. "
                                   "Unselected images are not read when max_frames is set.",
        "selected_source_indices": selected.tolist(), "source_image_size_wh": list(resolution),
        "episodes": episode_metadata, "units": ["A_deg", "B_deg", "C_mm"],
        "policy_input_keys": ["global_rgb", "target_roi_rgb", "visual_features", "state"],
        "label_keys": ["action", "delta"],
        "audit_is_policy_input": False,
        "roi_rule": "unscaled fixed-size raw RGB crop; black padding and missing-target crop",
        "rgb_detector": {"red_min": 160, "green_min": 45, "green_max": 210,
                         "red_minus_green_min_exclusive": 25,
                         "green_minus_blue_min_exclusive": 25,
                         "component_pixels_min": 3, "component_pixels_max": 4096,
                         "component_extent_max": 127, "candidate_pixels_max": 65536,
                         "selection": "largest 8-connected component; current RGB only"},
        "weight_rule": "actual forward dt / episode median dt above 1e-6s; final hold uses median dt",
        "stitching_interval_caution": "Episode exports contain approximately 1e-9s boundary intervals. "
                                      "Their actual dt gives negligible weight; labels are action-state, "
                                      "never delta/dt.",
        "rgb_target_visible_frames": int(arrays["visual_features"][:, 2].sum()),
        "split_caution": "Whole episodes can be isolated; these demonstrations share target layout. "
                         "Do not call a held-out episode a novel-layout test.",
    }
    # Temporary files live beside their final cache artifacts for atomic replace.
    temporary_id = uuid4().hex
    npz_tmp = npz_path.with_suffix(f".{temporary_id}.tmp.npz")
    json_tmp = json_path.with_suffix(f".{temporary_id}.tmp.json")
    try:
        np.savez_compressed(npz_tmp, **arrays)
        json_tmp.write_text(json.dumps({"metadata": metadata, "audit": audit},
                                       ensure_ascii=False, indent=2), encoding="utf-8")
        npz_tmp.replace(npz_path)
        json_tmp.replace(json_path)
    finally:
        npz_tmp.unlink(missing_ok=True)
        json_tmp.unlink(missing_ok=True)
    return {**arrays, "audit": audit, "metadata": metadata}
