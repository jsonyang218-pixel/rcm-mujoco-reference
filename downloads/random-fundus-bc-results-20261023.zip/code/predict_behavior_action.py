#!/usr/bin/env python3
"""Load a BC checkpoint and predict one action increment from raw RGB + ABC.

This prints a proposal only; no simulator or hardware command is issued.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image
import torch

from rcm_behavior_policy import policy_from_checkpoint
from rcm_imitation_data import preprocess_rgb


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--image', type=Path, required=True)
    parser.add_argument('--state', type=float, nargs=3, required=True, metavar=('A_DEG', 'B_DEG', 'C_MM'))
    args = parser.parse_args(argv)
    state = np.asarray(args.state, dtype=np.float32)
    if not np.isfinite(state).all():
        parser.error('ABC state must be finite')
    torch.set_num_threads(1)
    model, metadata = policy_from_checkpoint(args.checkpoint)
    settings = metadata.get('preprocessing', {})
    with Image.open(args.image) as image:
        if image.mode != 'RGB':
            parser.error('Image must be an original RGB image')
        views = preprocess_rgb(np.asarray(image), image_size=settings.get('image_size', 96),
                               roi_size=settings.get('roi_size', 64))
    rgb_tensor = lambda value: torch.from_numpy(value.transpose(2, 0, 1).copy()).float().unsqueeze(0)/255.
    with torch.inference_mode():
        normalized = model(rgb_tensor(views['global_rgb']), rgb_tensor(views['target_roi_rgb']),
                           torch.from_numpy(state).unsqueeze(0),
                           torch.from_numpy(views['visual_features']).unsqueeze(0))
        delta = model.physical_action(normalized)[0].numpy()
    if not np.isfinite(delta).all():
        raise ValueError('Nonfinite policy prediction')
    print(json.dumps({
        'model': metadata.get('model_name'), 'units': ['degree', 'degree', 'millimeter'],
        'state_A_B_C': state.tolist(), 'normalized_delta': normalized[0].tolist(),
        'delta_A_B_C': delta.tolist(), 'proposed_next_absolute_A_B_C': (state+delta).tolist(),
        'rgb_target_detected': bool(views['visual_features'][2]),
        'command_executed': False,
        'scope': 'Single-frame offline prediction; acceleration, scene constraints, phase changes and occlusion recovery are not executed by this script.',
    }, ensure_ascii=False, indent=2, allow_nan=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
