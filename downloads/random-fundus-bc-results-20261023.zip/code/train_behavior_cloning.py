#!/usr/bin/env python3
"""Train RGB/state BC on complete episodes and compare state-only controls.

The original single-root CLI measures same-layout episode validation. Random
dataset indexes instead select successful whole episodes with disjoint target
layouts in train/validation/test. Test is evaluated only after model selection.
Targets, phase, perception and truth are audit fields only.
"""
from __future__ import annotations

import argparse
from collections import Counter
import copy
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
from PIL import Image
import torch

from rcm_behavior_policy import BehaviorCloningPolicy, policy_from_checkpoint
from rcm_imitation_data import prepare_episode_dataset, preprocess_rgb


HERE = Path(__file__).resolve().parent
CASES = HERE/'runs/multitarget_occlusion_20261022'
SPLITS = ('train', 'validation', 'test')
ARRAY_KEYS = ('global_rgb', 'target_roi_rgb', 'visual_features', 'state',
              'action', 'delta', 'dt_seconds', 'sample_weight')
LEGACY_SCOPE = 'offline same-layout episode validation; closed-loop navigation not tested'
HELDOUT_SCOPE = 'offline heldout target layouts; whole-episode train/validation/test; closed-loop navigation not tested'


def canonical_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode()).hexdigest()


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def target_layout(path):
    """Hash target geometry only, ignoring IDs, order and generation metadata."""
    payload = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    targets = []
    for target in payload['targets']:
        point = np.asarray(target['point_mm'], dtype=np.float64)
        if point.shape != (3,) or not np.isfinite(point).all():
            raise ValueError(f'Invalid target geometry: {path}')
        # Normalize signed zero so a spelling change cannot hide equal layouts.
        targets.append((target.get('frame', payload.get('frame', 'world')),
                        tuple(0. if value == 0 else float(value) for value in point)))
    if not targets:
        raise ValueError(f'Empty target layout: {path}')
    return canonical_sha256(sorted(targets)), len(targets)


def check_disjoint_layouts(sources):
    seen_roots, seen_groups = {}, {}
    for split in SPLITS:
        for source in sources[split]:
            root = str(source['dataset_root'])
            if root in seen_roots:
                raise ValueError(f'Duplicate dataset root in {seen_roots[root]} and {split}: {root}')
            seen_roots[root] = split
            # Check both canonical geometry and frozen bytes when available.
            for field in ('target_layout_sha256', 'frozen_targets_sha256'):
                group = source.get(field)
                if not group:
                    continue
                key = (field, group)
                if key in seen_groups and seen_groups[key] != split:
                    raise ValueError(f'Target layout crosses {seen_groups[key]}/{split}: {group}')
                seen_groups[key] = split


def episode_eligibility(source, scenario):
    """Validate completed acceptance evidence without reading or editing images."""
    root = Path(source['dataset_root'])
    collection = scenario.get('collection', {})
    reasons = []
    if scenario.get('collection_status') != 'completed':
        reasons.append('collection_status is not completed')
    if collection.get('capture_complete') is not True or collection.get('exit_code') != 0:
        reasons.append('collection is incomplete or exited unsuccessfully')
    reports = collection.get('reports', [])
    if not reports or any(row.get('result') != 'PASS' for row in reports):
        reasons.append('collection reports are missing or contain navigation failures')
    try:
        actual_reports = json.loads((root.parent/'run_reports.json').read_text())
        manifest = json.loads((root/'manifest.json').read_text())
        verification = json.loads((root.parent/'dataset_verification.json').read_text())
    except (OSError, ValueError) as exc:
        reasons.append(f'missing or unreadable acceptance artifact: {exc}')
        return reasons
    episodes = manifest.get('episodes', [])
    if not actual_reports or any(row.get('result') != 'PASS' for row in actual_reports):
        reasons.append('run_reports.json is empty or contains navigation failures')
    if not episodes or any(row.get('result') != 'PASS' for row in episodes):
        reasons.append('manifest is empty or contains unsuccessful episodes')
    if any(row.get('stop_constraint_summary', {}).get('pass') is not True for row in episodes):
        reasons.append('manifest episode does not have a validated terminal stop')
    identities = lambda rows: Counter((row.get('method'), row.get('seed')) for row in rows)
    expected = collection.get('expected_runs')
    if (not expected or len(episodes) != expected or len(reports) != expected
            or len(actual_reports) != expected
            or identities(episodes) != identities(reports)
            or identities(episodes) != identities(actual_reports)):
        reasons.append('collection/report/manifest run identities or counts differ')
    if verification.get('result') != 'PASS':
        reasons.append('dataset_verification is not PASS')
    if (verification.get('episodes') != len(episodes)
            or verification.get('frames') != sum(row.get('frames', 0) for row in episodes)):
        reasons.append('verification episode/frame counts differ from manifest')
    declared = [row.get('policy_inputs') for row in episodes]
    actual = {path.relative_to(root).as_posix() for path in (root/'policy_inputs').glob('episode_*.npz')}
    if None in declared or len(set(declared)) != len(declared) or set(declared) != actual:
        reasons.append('manifest policy input files do not exactly match the dataset root')
    saved_targets = root.parent/'targets.json'
    if saved_targets.is_file():
        layout, count = target_layout(saved_targets)
        if layout != source['target_layout_sha256'] or count != source['target_count']:
            reasons.append('collected targets differ from frozen scenario targets')
    else:
        reasons.append('collected targets.json is missing')
    if not reasons:
        # Freeze acceptance and all non-image model-source files now. Deferred
        # test selection must remain immutable without reading any test PNGs.
        paths = [root/'manifest.json', root.parent/'run_reports.json',
                 root.parent/'dataset_verification.json', saved_targets]
        for relative in declared:
            policy = root/relative
            paths.extend((policy, root/'action_labels'/(policy.stem+'.npz'),
                          root/'data'/(policy.stem+'.jsonl')))
        try:
            source['acceptance_fingerprint_sha256'] = canonical_sha256({
                str(path.relative_to(root.parent)): file_sha256(path) for path in paths})
        except OSError as exc:
            reasons.append(f'non-image policy/label/audit artifact is missing: {exc}')
    return reasons


def indexed_sources(index_paths, minimums):
    """Return accepted roots and a complete exclusion audit for frozen indexes."""
    frozen = {split: [] for split in SPLITS}
    report = {'scope': HELDOUT_SCOPE, 'split_unit': 'whole target layout and reset episode',
              'minimum_successful_roots_per_target_count': dict(zip(SPLITS, minimums)),
              'indexes': [], 'included': [], 'excluded': []}
    for index_path in index_paths:
        path = Path(index_path).resolve(strict=True)
        index = json.loads(path.read_text(encoding='utf-8-sig'))
        report['indexes'].append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        for scenario in index['episodes']:
            split = scenario.get('split')
            if split not in SPLITS:
                continue
            relative = Path(scenario['targets'])
            if relative.is_absolute() or '..' in relative.parts:
                raise ValueError(f'Unsafe frozen target path in {path}: {relative}')
            targets = (path.parent/relative).resolve(strict=True)
            if not targets.is_relative_to(path.parent):
                raise ValueError(f'Frozen targets escape dataset index root: {targets}')
            frozen_hash = hashlib.sha256(targets.read_bytes()).hexdigest()
            if frozen_hash != scenario.get('targets_sha256'):
                raise ValueError(f'Frozen target SHA-256 mismatch: {targets}')
            layout, count = target_layout(targets)
            if count != scenario.get('target_count', index.get('target_count_per_episode')):
                raise ValueError(f'Target count differs from frozen geometry: {targets}')
            root = (path.parent/'episodes'/split/f"episode_{int(scenario['episode_index']):06d}"/'dataset').resolve()
            source = {'dataset_root': str(root), 'dataset_index': str(path), 'split': split,
                      'scenario_episode_index': scenario['episode_index'], 'target_count': count,
                      'target_layout_sha256': layout, 'frozen_targets_sha256': frozen_hash}
            frozen[split].append({**source, '_scenario': scenario})
    # Inspect every frozen scenario, including exclusions, before accepting any.
    check_disjoint_layouts(frozen)
    accepted = {split: [] for split in SPLITS}
    for split in SPLITS:
        for entry in frozen[split]:
            source = {key: value for key, value in entry.items() if key != '_scenario'}
            reasons = episode_eligibility(source, entry['_scenario'])
            if reasons:
                report['excluded'].append({**source, 'reasons': reasons})
            else:
                accepted[split].append(source)
                report['included'].append(source)
    report['successful_roots_by_target_count'] = {
        str(count): {split: sum(source['target_count'] == count for source in accepted[split])
                     for split in SPLITS} for count in sorted({3, 5} | {
                         source['target_count'] for split in SPLITS for source in frozen[split]})}
    shortages = [f'{count}-target {split}: {counts[split]} < {minimum}'
                 for count, counts in report['successful_roots_by_target_count'].items()
                 for split, minimum in zip(SPLITS, minimums) if counts[split] < minimum]
    report['ready'] = not shortages
    report['shortages'] = shortages
    return accepted, report


def prepare_roots(sources, args, scope, aggregate=True):
    prepared, audits, roots = [], [], []
    for source in sources:
        root = str(Path(source['dataset_root']).resolve())
        data = prepare_episode_dataset(root, args.cache_dir, image_size=args.image_size,
                                       roi_size=args.roi_size, max_frames=args.max_frames)
        prepared.append(data)
        audits.extend({**row, 'source_dataset_root': root,
                       'source_target_layout_sha256': source.get('target_layout_sha256'),
                       'source_target_count': source.get('target_count')} for row in data['audit'])
        roots.append({**source, 'dataset_root': root,
                      'fingerprint_sha256': data['metadata']['fingerprint_sha256'],
                      'episode_count': len(data['metadata']['episodes']),
                      'source_frames': data['metadata']['source_frames'],
                      'selected_frames': len(data['state'])})
    if not prepared:
        raise ValueError('Cannot prepare an empty split')
    metadata = dict(prepared[0]['metadata']) if not aggregate and len(prepared) == 1 else {
        'fingerprint_sha256': canonical_sha256({'roots': roots, 'scope': scope}),
        'source_hashes': {str(Path(source['dataset_root'])/name): digest
                          for source, data in zip(sources, prepared)
                          for name, digest in data['metadata']['source_hashes'].items()},
        'source_frames': sum(data['metadata']['source_frames'] for data in prepared),
        'selected_frames': sum(len(data['state']) for data in prepared),
        'episodes': [{**episode, 'source_dataset_root': source['dataset_root']}
                     for source, data in zip(sources, prepared) for episode in data['metadata']['episodes']],
        'policy_input_keys': prepared[0]['metadata']['policy_input_keys'],
        'label_keys': ['action', 'delta'], 'audit_is_policy_input': False,
        'max_frames_per_root': args.max_frames,
    }
    metadata.update({'scope': scope, 'source_roots': roots, 'dataset_root_count': len(roots),
                     'episode_count': sum(root['episode_count'] for root in roots),
                     'target_layout_count': len({root.get('target_layout_sha256') for root in roots}
                                                - {None}),
                     'split_unit': 'whole source episodes; no random frame split'})
    return {**{key: np.concatenate([data[key] for data in prepared]) for key in ARRAY_KEYS},
            'audit': audits, 'metadata': metadata}


def nearest_training_state(train_state, query_state, scale, chunk_size=256, train_chunk_size=4096):
    """Exact 1NN with bounded pairwise memory and first-index tie behavior."""
    nearest = np.empty(len(query_state), dtype=np.int64)
    distances = np.empty(len(query_state), dtype=np.float64)
    for start in range(0, len(query_state), chunk_size):
        query = query_state[start:start+chunk_size]
        best = np.full(len(query), np.inf)
        indices = np.zeros(len(query), dtype=np.int64)
        for offset in range(0, len(train_state), train_chunk_size):
            delta = (query[:, None, :]-train_state[None, offset:offset+train_chunk_size, :])/scale
            squared = np.sum(delta*delta, axis=2)
            local = np.argmin(squared, axis=1)
            value = squared[np.arange(len(query)), local]
            improved = value < best
            best[improved], indices[improved] = value[improved], offset+local[improved]
        nearest[start:start+len(query)] = indices
        distances[start:start+len(query)] = np.sqrt(best)
    return nearest, distances


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    temporary.replace(path)


def save_checkpoint(path, model, metadata, optimizer=None):
    payload = {'model_config': model.config(), 'state_dict': model.state_dict(), 'metadata': metadata}
    if optimizer is not None:
        payload['optimizer_state_dict'] = optimizer.state_dict()
    temporary = Path(path).with_suffix('.tmp.pt')
    torch.save(payload, temporary)
    temporary.replace(path)


def checked_policy(path, scale):
    model, metadata = policy_from_checkpoint(path)
    if not np.array_equal(model.action_scale.detach().cpu().numpy(), scale):
        raise ValueError('Configured action scale differs from the saved checkpoint')
    return model, metadata


def tensors(data, scale):
    return {
        'global_rgb': torch.from_numpy(data['global_rgb'].transpose(0, 3, 1, 2).copy()).float()/255.,
        'target_roi_rgb': torch.from_numpy(data['target_roi_rgb'].transpose(0, 3, 1, 2).copy()).float()/255.,
        'state': torch.from_numpy(data['state'].copy()),
        'visual_features': torch.from_numpy(data['visual_features'].copy()),
        'label': torch.from_numpy((data['delta']/scale).astype(np.float32)),
        'weight': torch.from_numpy(data['sample_weight'].copy()),
    }


def inputs(batch, indices, use_images=True):
    return (batch['global_rgb'][indices] if use_images else None,
            batch['target_roi_rgb'][indices] if use_images else None,
            batch['state'][indices],
            batch['visual_features'][indices] if use_images else None)


def predict(model, batch, batch_size=128, visual_order=None):
    model.eval()
    output = []
    with torch.inference_mode():
        for start in range(0, len(batch['state']), batch_size):
            index = slice(start, start+batch_size)
            args = list(inputs(batch, index, model.use_images))
            if visual_order is not None and model.use_images:
                other = visual_order[index]
                args[0], args[1], args[3] = (batch['global_rgb'][other], batch['target_roi_rgb'][other],
                                            batch['visual_features'][other])
            output.append(model(*args).cpu().numpy())
    return np.concatenate(output)


def metrics(prediction, data, scale, selection=None):
    if selection is None:
        selection = np.ones(len(data['state']), dtype=bool)
    count = int(np.sum(selection))
    if not count:
        return {'frames': 0, 'normalized_mse': None, 'action_mae_A_deg_B_deg_C_mm': None}
    error = prediction[selection]-data['delta'][selection]/scale
    weights = data['sample_weight'][selection].astype(np.float64)
    if not np.isfinite(error).all() or weights.sum() <= 0:
        raise ValueError('Nonfinite predictions or invalid evaluation weights')
    mean = lambda array: np.sum(array*weights[:, None], axis=0)/weights.sum()
    physical_error = error*scale
    return {
        'frames': count, 'normalized_mse': float(np.mean(mean(error**2))),
        'normalized_rmse_per_axis': np.sqrt(mean(error**2)).tolist(),
        'action_mae_A_deg_B_deg_C_mm': mean(np.abs(physical_error)).tolist(),
        'action_rmse_A_deg_B_deg_C_mm': np.sqrt(mean(physical_error**2)).tolist(),
        'action_max_abs_error_A_deg_B_deg_C_mm': np.max(np.abs(physical_error), axis=0).tolist(),
        'scope': 'one-step action increment error; not accumulated or endpoint position error',
    }


def evaluate_groups(prediction, data, scale):
    groups = {'all': metrics(prediction, data, scale)}
    for field in ('waypoint_id', 'phase', 'source_target_count'):
        labels = np.asarray([str(row.get(field, 'unknown')) for row in data['audit']])
        for label in sorted(set(labels)):
            groups[field+'/'+label] = metrics(prediction, data, scale, labels == label)
    visibility = np.asarray([row.get('visibility', {}).get('target_occlusion_state', 'unknown')
                             for row in data['audit']])
    for label in sorted(set(visibility)):
        groups['visibility/'+label] = metrics(prediction, data, scale, visibility == label)
    return groups


def train_one(name, use_images, train, validation, train_tensors, validation_tensors, scale, args, output):
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    model = BehaviorCloningPolicy(state_mean=train['state'].mean(0), state_std=train['state'].std(0),
                                  action_scale=scale, use_images=use_images)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=1e-4)
    initial_train = metrics(predict(model, train_tensors), train, scale)
    initial_validation = metrics(predict(model, validation_tensors), validation, scale)
    directory = output/name
    directory.mkdir()
    best_loss, best_epoch, best_state, history = float('inf'), 0, None, []
    generator = torch.Generator().manual_seed(args.seed)
    started = time.monotonic()
    parameter_count = sum(p.numel() for p in model.parameters())
    for epoch in range(1, args.epochs+1):
        model.train()
        order = torch.randperm(len(train['state']), generator=generator)
        for start in range(0, len(order), args.batch_size):
            index = order[start:start+args.batch_size]
            prediction = model(*inputs(train_tensors, index, use_images))
            per_row = torch.nn.functional.smooth_l1_loss(prediction, train_tensors['label'][index],
                                                        reduction='none', beta=.1).mean(1)
            weight = train_tensors['weight'][index]
            loss = (per_row*weight).sum()/weight.sum().clamp_min(1e-12)
            if not bool(torch.isfinite(loss)):
                raise ValueError('Nonfinite training loss')
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
            optimizer.step()
        train_result = metrics(predict(model, train_tensors), train, scale)
        validation_result = metrics(predict(model, validation_tensors), validation, scale)
        history.append({'epoch': epoch, 'train_normalized_mse': train_result['normalized_mse'],
                        'validation_normalized_mse': validation_result['normalized_mse'],
                        'last_minibatch_huber': float(loss.detach()),
                        'last_gradient_norm': float(norm), 'wall_elapsed_s': time.monotonic()-started})
        checkpoint_metadata = {'model_name': name, 'epoch': epoch, 'seed': args.seed,
                               'preprocessing': {'image_size': args.image_size, 'roi_size': args.roi_size,
                                                 'visual_coordinates': '[-1, 1], invisible centroid=0'},
                               'policy_input_contract': ['global_rgb', 'target_roi_rgb', 'state', 'visual_features'] if use_images else ['state'],
                               'scope': args.scope,
                               'data_provenance': {split: data['metadata']['source_roots']
                                                   for split, data in [('train', train), ('validation', validation)]},
                               'model_selection': 'lowest validation normalized MSE; test is not used'}
        save_checkpoint(directory/'last.pt', model, checkpoint_metadata, optimizer)
        if validation_result['normalized_mse'] < best_loss:
            best_loss = validation_result['normalized_mse']
            best_epoch, best_state = epoch, copy.deepcopy(model.state_dict())
            save_checkpoint(directory/'policy.pt', model, checkpoint_metadata)
        write_json(directory/'history.json', history)
        write_json(output/'progress.json', {'status': 'training', 'model': name, 'epoch': epoch,
                                           'best_epoch': best_epoch, **history[-1]})
        if epoch == 1 or epoch % 5 == 0:
            print(json.dumps({'model': name, **history[-1]}, ensure_ascii=False), flush=True)
        if epoch-best_epoch >= args.patience:
            break
    assert best_state is not None
    model.load_state_dict(best_state)
    train_prediction = predict(model, train_tensors)
    validation_prediction = predict(model, validation_tensors)
    loaded, metadata = checked_policy(directory/'policy.pt', scale)
    reloaded_prediction = predict(loaded, validation_tensors)
    if not np.array_equal(validation_prediction, reloaded_prediction):
        raise AssertionError('Reloaded checkpoint does not reproduce predictions')
    np.savez_compressed(directory/'validation_predictions.npz',
                        normalized_delta=validation_prediction,
                        predicted_delta_ABC=validation_prediction*scale,
                        recorded_delta_ABC=validation['delta'], sample_weight=validation['sample_weight'])
    result = {'model': name, 'parameter_count': parameter_count, 'epochs_run': len(history),
              'best_epoch': best_epoch, 'wall_s': time.monotonic()-started,
              'initial_train': initial_train, 'initial_validation': initial_validation,
              'train': evaluate_groups(train_prediction, train, scale),
              'validation': evaluate_groups(validation_prediction, validation, scale),
              'checkpoint_reload_identical': True, 'checkpoint': str(directory/'policy.pt'),
              'train_loss_decreased': bool(metrics(train_prediction, train, scale)['normalized_mse'] < initial_train['normalized_mse'])}
    if use_images:
        permutation = torch.randperm(len(validation['state']), generator=torch.Generator().manual_seed(args.seed+1))
        shuffled = predict(model, validation_tensors, visual_order=permutation)
        result['shuffled_visual_inputs_validation'] = metrics(shuffled, validation, scale)
        result['shuffled_visual_prediction_change_mean_abs_normalized'] = float(np.abs(shuffled-validation_prediction).mean())
        result['shuffled_visual_scope'] = 'shuffle global/ROI/RGB features together with state unchanged; sensitivity check, not causal proof of generalization'
    write_json(directory/'metrics.json', result)
    return result


def plots(output, results, heldout_layouts=False):
    os.environ.setdefault('MPLCONFIGDIR', str(HERE/'.cache/matplotlib'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figure, axes = plt.subplots(1, 2, figsize=(11, 4))
    for result in results:
        history = json.loads((output/result['model']/'history.json').read_text())
        epochs = [row['epoch'] for row in history]
        axes[0].plot(epochs, [row['train_normalized_mse'] for row in history], label=result['model'])
        axes[1].plot(epochs, [row['validation_normalized_mse'] for row in history], label=result['model'])
    validation_title = 'Heldout target layouts' if heldout_layouts else 'Same-layout held-out episode'
    for axis, title in zip(axes, ('Training', validation_title)):
        axis.set(title=title, xlabel='Epoch', ylabel='Weighted normalized action MSE', yscale='log')
        axis.grid(alpha=.2)
        axis.legend()
    figure.tight_layout()
    figure.savefig(output/'training_curves.png', dpi=170)
    figure.savefig(output/'training_curves.pdf')
    plt.close(figure)


def choose_sources(args):
    if args.dataset_index:
        return indexed_sources(args.dataset_index, args.min_episodes_per_split)
    paths = {
        'train': args.train_datasets or [args.train_dataset or CASES/'strict_three/dataset'],
        'validation': args.validation_datasets or [args.validation_dataset or CASES/'strict_occlusion_recovery/dataset'],
        'test': args.test_datasets or ([args.test_dataset] if args.test_dataset else []),
    }
    sources = {split: [] for split in SPLITS}
    for split, roots in paths.items():
        for root in roots:
            root = root.resolve(strict=True)
            source = {'dataset_root': str(root), 'split': split}
            targets = root.parent/'targets.json'
            if targets.is_file():
                layout, count = target_layout(targets)
                source.update(target_layout_sha256=layout, target_count=count)
            elif args.heldout_layouts:
                raise ValueError(f'Heldout-layout root requires its parent targets.json: {root}')
            sources[split].append(source)
    if args.heldout_layouts:
        check_disjoint_layouts(sources)
    else:
        roots = [source['dataset_root'] for split in SPLITS for source in sources[split]]
        if len(set(roots)) != len(roots):
            raise ValueError('Train, validation and test must be different whole-episode datasets')
    return sources, {'ready': True, 'scope': args.scope,
                     'included': [source for split in SPLITS for source in sources[split]],
                     'excluded': []}


def frozen_evaluation_sources(output, current, selection):
    """Reuse the run's roots even when collection has added successful episodes."""
    saved_path = output/'episode_selection.json'
    if not saved_path.exists():
        return current, selection  # Original single-root runs predate this audit.
    saved = json.loads(saved_path.read_text())
    by_root = {source['dataset_root']: source for split in SPLITS for source in current[split]}
    sources = {split: [] for split in SPLITS}
    selected_roots = set()
    for original in saved['included']:
        root = original['dataset_root']
        present = by_root.get(root)
        if present is None:
            raise ValueError(f'Original selected root is no longer eligible: {root}')
        for field in ('split', 'target_layout_sha256', 'frozen_targets_sha256', 'target_count',
                      'acceptance_fingerprint_sha256'):
            if original.get(field) != present.get(field):
                raise ValueError(f'Original selected source {field} changed: {root}')
        sources[original['split']].append(original)
        selected_roots.add(root)
    audit = {**selection, 'included': saved['included'],
             'selection_source': str(saved_path),
             'new_successful_roots_not_used': [source for source in selection['included']
                                               if source['dataset_root'] not in selected_roots]}
    return sources, audit


def split_baselines(train, query, scale):
    nearest, distances = nearest_training_state(train['state'], query['state'], scale)
    return ({'zero_hold': evaluate_groups(np.zeros_like(query['delta']), query, scale),
             'nearest_training_state_lookup': evaluate_groups(train['delta'][nearest]/scale, query, scale)},
            {'frames': len(query['state']),
             'nearest_state_distance_lt_point1': int(np.sum(distances < .1)),
             'nearest_state_distance_quantiles': np.quantile(distances, [0, .25, .5, .75, .95, 1]).tolist()})


def save_comparison(path, baseline, results, split):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream)
        writer.writerow(['model', split+'_normalized_mse', 'A_action_mae_deg', 'B_action_mae_deg', 'C_action_mae_mm'])
        for name, values in [('zero_hold', baseline['zero_hold']['all']),
                             ('nearest_training_state_lookup', baseline['nearest_training_state_lookup']['all']),
                             *((result['model'], result[split]['all']) for result in results)]:
            writer.writerow([name, values['normalized_mse'], *values['action_mae_A_deg_B_deg_C_mm']])


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for split in SPLITS:
        group = parser.add_mutually_exclusive_group()
        group.add_argument('--'+split+'-dataset', type=Path)
        group.add_argument('--'+split+'-datasets', type=Path, nargs='+')
    parser.add_argument('--dataset-index', type=Path, nargs='+',
                        help='Frozen random-fundus indexes; select successful whole episodes by split')
    parser.add_argument('--min-episodes-per-split', type=int, nargs=3, default=(1, 1, 1),
                        metavar=('TRAIN', 'VALIDATION', 'TEST'),
                        help='Minimum successful roots in each split, separately for both 3- and 5-target groups')
    parser.add_argument('--defer-test', action='store_true',
                        help='Freeze and audit test selection without decoding test images or evaluating test')
    parser.add_argument('--config', type=Path, default=HERE/'config.json')
    parser.add_argument('--output-dir', type=Path, default=HERE/'runs/policy_training_20261022/bc_first')
    parser.add_argument('--cache-dir', type=Path, default=HERE/'runs/policy_cache')
    parser.add_argument('--epochs', type=int, default=60)
    parser.add_argument('--batch-size', type=int, default=64)
    parser.add_argument('--learning-rate', type=float, default=.001)
    parser.add_argument('--patience', type=int, default=15)
    parser.add_argument('--image-size', type=int, default=96)
    parser.add_argument('--roi-size', type=int, default=64)
    parser.add_argument('--threads', type=int, default=2)
    parser.add_argument('--seed', type=int, default=20261022)
    parser.add_argument('--max-frames', type=int, default=None, help='Optional evenly spaced preparation smoke check; not a new split')
    parser.add_argument('--evaluate-only', action='store_true',
                        help='Finish or repeat offline evaluation using existing checkpoints; do not train again')
    args = parser.parse_args(argv)
    if min(args.epochs, args.batch_size, args.patience, args.threads) <= 0 or args.learning_rate <= 0:
        parser.error('epochs, batch size, patience, threads and learning rate must be positive')
    if min(args.min_episodes_per_split) <= 0:
        parser.error('--min-episodes-per-split values must be positive')
    direct_roots = [getattr(args, split+suffix) for split in SPLITS for suffix in ('_dataset', '_datasets')]
    if args.dataset_index and any(value is not None for value in direct_roots):
        parser.error('--dataset-index cannot be combined with explicit dataset roots')
    args.heldout_layouts = bool(args.dataset_index or any(getattr(args, split+'_datasets') for split in SPLITS)
                                or args.test_dataset)
    args.scope = HELDOUT_SCOPE if args.heldout_layouts else LEGACY_SCOPE
    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    output = args.output_dir.resolve()
    if args.evaluate_only:
        if not output.is_dir():
            parser.error('--evaluate-only requires an existing training output directory')
    else:
        output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    write_json(output/'progress.json', {'status': 'preparing_data', 'evaluate_only': args.evaluate_only})
    sources_by_split, selection = choose_sources(args)
    if args.evaluate_only:
        sources_by_split, selection = frozen_evaluation_sources(output, sources_by_split, selection)
    write_json(output/('evaluation_episode_selection.json' if args.evaluate_only else 'episode_selection.json'), selection)
    write_json(output/('evaluation_excluded_episodes.json' if args.evaluate_only else 'excluded_episodes.json'), selection['excluded'])
    if not selection['ready']:
        write_json(output/'progress.json', {'status': 'insufficient_successful_episodes',
                                           'shortages': selection.get('shortages', [])})
        raise ValueError('Insufficient successful whole episodes: '+'; '.join(selection.get('shortages', [])))
    print('Preparing whole-episode train/validation data; decoding RGB only. Test is held for final evaluation.', flush=True)
    train = prepare_roots(sources_by_split['train'], args, args.scope, aggregate=args.heldout_layouts)
    validation = prepare_roots(sources_by_split['validation'], args, args.scope, aggregate=args.heldout_layouts)
    train_image_hashes = {value for name, value in train['metadata']['source_hashes'].items() if name.endswith('.png')}
    validation_image_hashes = {value for name, value in validation['metadata']['source_hashes'].items() if name.endswith('.png')}
    # Exact repeated held images can occur at static phase boundaries. Record
    # cross-dataset content overlap rather than pretending episode IDs establish
    # independence of the underlying target layout or executed trajectory.
    config = json.loads(args.config.read_text(encoding='utf-8-sig'))
    dt = float(config['navigation']['visual_servo']['sample_period_s'])
    scale = np.asarray(config['navigation']['max_velocity_A_deg_B_deg_C_mm_per_s'], dtype=np.float32)*dt
    if scale.shape != (3,) or not np.isfinite(scale).all() or (scale <= 0).any():
        raise ValueError('Invalid configured action scale')
    if any(np.max(np.abs(data['delta']/scale)) > 1.001 for data in (train, validation)):
        raise ValueError('Recorded increments exceed configured one-step velocity bounds')
    source_names = ['train_behavior_cloning.py', 'rcm_behavior_policy.py', 'rcm_imitation_data.py', 'requirements-training.txt']
    sources = {name: hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in source_names}
    source_directory = output/('evaluation_source_snapshot' if args.evaluate_only else 'source_snapshot')
    source_directory.mkdir(exist_ok=args.evaluate_only)
    for name in source_names:
        (source_directory/name).write_bytes((HERE/name).read_bytes())
    write_json(output/('evaluation_source_sha256.json' if args.evaluate_only else 'source_sha256.json'), sources)
    if args.evaluate_only:
        for name, data in [('train', train), ('validation', validation)]:
            previous = json.loads((output/(name+'_data.json')).read_text())
            if previous['fingerprint_sha256'] != data['metadata']['fingerprint_sha256']:
                raise ValueError('Evaluation data/preprocessing differs from the original training run')
    else:
        write_json(output/'train_data.json', train['metadata'])
        write_json(output/'validation_data.json', validation['metadata'])
    write_json(output/('evaluation_config.json' if args.evaluate_only else 'run_config.json'),
               {key: ([str(item) if isinstance(item, Path) else item for item in value]
                      if isinstance(value, (list, tuple)) else str(value) if isinstance(value, Path) else value)
                for key, value in vars(args).items()})
    baseline, validation_distances = split_baselines(train, validation, scale)
    split_audit = {'train_frames': len(train['state']), 'validation_frames': len(validation['state']),
                   'split_unit': 'entire source episode; no random frame split',
                   'scope': args.scope,
                   'target_layouts_disjoint': True if args.heldout_layouts else 'NOT_CLAIMED_SAME_LAYOUT',
                   'successful_root_counts': {split: len(roots) for split, roots in sources_by_split.items()},
                   'source_episode_counts': {split: data['metadata']['episode_count']
                                             for split, data in [('train', train), ('validation', validation)]},
                   'target_layout_hashes': {split: sorted({source['target_layout_sha256'] for source in roots
                                                           if source.get('target_layout_sha256')})
                                            for split, roots in sources_by_split.items()},
                   'test_status': 'DEFERRED' if args.defer_test else 'FINAL_EVALUATION' if sources_by_split['test'] else 'NOT_CONFIGURED',
                   'exact_rgb_content_hashes_in_both': len(train_image_hashes & validation_image_hashes),
                   'nearest_state_distance_definition': 'min train L2 norm of (validation_state-train_state)/action_scale',
                   'validation_nearest_state_distance_lt_point1': validation_distances['nearest_state_distance_lt_point1'],
                   'validation_nearest_state_distance_quantiles': validation_distances['nearest_state_distance_quantiles']}
    write_json(output/'split_audit.json', split_audit)
    train_tensors, validation_tensors = tensors(train, scale), tensors(validation, scale)
    if args.evaluate_only:
        results = []
        for name in ('rgb_state_bc', 'state_only_bc'):
            result = json.loads((output/name/'metrics.json').read_text())
            model, _ = checked_policy(output/name/'policy.pt', scale)
            current = predict(model, validation_tensors)
            with np.load(output/name/'validation_predictions.npz', allow_pickle=False) as saved:
                if not np.array_equal(current, saved['normalized_delta']):
                    raise AssertionError('Saved checkpoint/predictions changed since training')
            results.append(result)
    else:
        results = [train_one(name, visual, train, validation, train_tensors, validation_tensors, scale, args, output)
                   for name, visual in [('rgb_state_bc', True), ('state_only_bc', False)]]
    # Test inference from an actual PNG through exactly the training transform.
    raw_path = Path(validation['audit'][0]['source_dataset_root'])/validation['audit'][0]['image_relative_path']
    with Image.open(raw_path) as image:
        views = preprocess_rgb(np.asarray(image), image_size=args.image_size, roi_size=args.roi_size)
    for key, value in views.items():
        if not np.array_equal(value, validation[key][0]):
            raise AssertionError('Inference preprocessing differs from training cache')
    test_baseline = None
    # Neither train_one nor checkpoint selection ever sees a test tensor. In
    # deferred runs, no test images, preprocessing cache or predictions are read.
    if sources_by_split['test'] and not args.defer_test:
        test = prepare_roots(sources_by_split['test'], args, args.scope, aggregate=True)
        if np.max(np.abs(test['delta']/scale)) > 1.001:
            raise ValueError('Test increments exceed configured one-step velocity bounds')
        test_metadata_path = output/'test_data.json'
        if test_metadata_path.exists():
            previous = json.loads(test_metadata_path.read_text())
            if previous['fingerprint_sha256'] != test['metadata']['fingerprint_sha256']:
                raise ValueError('Test data/preprocessing differs from the previous final evaluation')
        write_json(test_metadata_path, test['metadata'])
        test_tensors = tensors(test, scale)
        test_baseline, test_distances = split_baselines(train, test, scale)
        for result in results:
            model, _ = checked_policy(output/result['model']/'policy.pt', scale)
            prediction = predict(model, test_tensors)
            prediction_path = output/result['model']/'test_predictions.npz'
            if args.evaluate_only and prediction_path.exists():
                with np.load(prediction_path, allow_pickle=False) as saved:
                    if not np.array_equal(prediction, saved['normalized_delta']):
                        raise AssertionError('Saved final test predictions changed')
            np.savez_compressed(prediction_path, normalized_delta=prediction,
                                predicted_delta_ABC=prediction*scale,
                                recorded_delta_ABC=test['delta'], sample_weight=test['sample_weight'])
            result['test'] = evaluate_groups(prediction, test, scale)
            result['test_evaluated_after_model_selection'] = True
            write_json(output/result['model']/'metrics.json', result)
        split_audit.update({'test_frames': len(test['state']),
                            'test_episode_count': test['metadata']['episode_count'],
                            'test_root_count': test['metadata']['dataset_root_count'],
                            'test_nearest_state_distance': test_distances})
        split_audit['source_episode_counts']['test'] = test['metadata']['episode_count']
        save_comparison(output/'test_comparison.csv', test_baseline, results, 'test')
    write_json(output/'split_audit.json', split_audit)
    plots(output, results, heldout_layouts=args.heldout_layouts)
    vision, state_only = results
    vision_loss = vision['validation']['all']['normalized_mse']
    zero_loss = baseline['zero_hold']['all']['normalized_mse']
    pipeline_pass = all(r['checkpoint_reload_identical'] and r['train_loss_decreased'] for r in results)
    validation_gate = vision_loss < zero_loss and vision_loss < state_only['validation']['all']['normalized_mse']
    if args.defer_test:
        # Existing final artifacts remain on disk; this invocation reports no
        # test evaluation and must not silently mix old test numbers into it.
        results = [{key: value for key, value in result.items()
                    if key not in ('test', 'test_evaluated_after_model_selection')} for result in results]
    layout_status = ('OFFLINE_ONE_STEP_TEST_EVALUATED' if test_baseline is not None else
                     'VALIDATION_ONLY_TEST_DEFERRED' if args.defer_test and sources_by_split['test'] else
                     'VALIDATION_ONLY_TEST_NOT_CONFIGURED')
    summary = {'training_pipeline_result': 'PASS' if pipeline_pass else 'FAIL',
               'validation_gate_pass': bool(validation_gate),
               'validation_gate_definition': 'RGB validation normalized MSE < zero hold and < state-only; nearest-state lookup is report-only',
               'visual_model_better_than_state_only': vision_loss < state_only['validation']['all']['normalized_mse'],
               'closed_loop_navigation': 'NOT_RUN', 'endpoint_accuracy_below_20um': 'NOT_EVALUATED',
               'new_layout_generalization': layout_status if args.heldout_layouts else 'NOT_EVALUATED',
               'evaluation_scope': args.scope,
               'test_status': split_audit['test_status'],
               'test_used_for_model_selection': False,
               'scope': 'RGB-only colour ROI + small CNN + ABC behavior cloning. No depth, segmentation, teacher geometry, phase, target coordinates or memory are policy inputs. Fixed task text is not encoded.',
               'training_objective': 'dt-weighted Huber loss on normalized action-state increments',
               'metrics_definition': 'dt-weighted normalized one-step action MSE; physical errors in deg, deg, mm, not endpoint error',
               'action_scale_A_deg_B_deg_C_mm': scale.tolist(),
               'inference_preprocessing_matches_training': True,
               'runtime': {'torch': str(torch.__version__), 'device': 'cpu', 'threads': args.threads,
                           'evaluation_only_invocation': args.evaluate_only,
                           'invocation_wall_s': time.monotonic()-started,
                           'model_training_and_evaluation_wall_s': sum(r['wall_s'] for r in results)},
               'split_audit': split_audit, 'baselines': baseline, 'models': results}
    comparison_key = ('heldout_target_layouts_validation_better_than_zero_hold' if args.heldout_layouts
                      else 'same_layout_validation_better_than_zero_hold')
    summary[comparison_key] = bool(vision_loss < zero_loss)
    if test_baseline is not None:
        summary['test_baselines'] = test_baseline
    write_json(output/'training_report.json', summary)
    write_json(output/'progress.json', {'status': 'complete', 'training_pipeline_result': summary['training_pipeline_result']})
    save_comparison(output/'comparison.csv', baseline, results, 'validation')
    print(json.dumps({'training_pipeline_result': summary['training_pipeline_result'],
                      'validation_gate_pass': bool(validation_gate), 'test_status': summary['test_status'],
                      'validation_normalized_mse': {r['model']: r['validation']['all']['normalized_mse'] for r in results},
                      'zero_hold_mse': zero_loss, 'closed_loop_navigation': 'NOT_RUN',
                      'output_dir': str(output)}, ensure_ascii=False, indent=2), flush=True)
    return 0 if pipeline_pass else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'Training failed: {type(exc).__name__}: {exc}', file=sys.stderr, flush=True)
        raise
