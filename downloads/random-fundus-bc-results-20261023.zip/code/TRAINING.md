# 首次行为克隆训练

当前新增的是 CPU 可运行的 RGB＋A/B/C 行为克隆基线，用来先跑通数据准备、训练、检查点保存与加载和离线动作预测。它没有部署进导航闭环，也没有训练遮挡恢复模块。

## 安装与运行

使用项目虚拟环境，先安装基础依赖，再安装 CPU PyTorch；Linux/Windows CPU 环境使用：

```bash
python -m pip install -r requirements.txt
python -m pip install -r requirements-training.txt
python train_behavior_cloning.py --output-dir runs/bc_demo
```

需要完整原始 RGB 数据。默认训练数据为 `runs/multitarget_occlusion_20261022/strict_three/dataset`，验证数据为 `strict_occlusion_recovery/dataset`；GitHub 的报告副本不含完整 RGB 库，因此仅下载源码不能直接重现这两个默认路径。已有其他完整数据时，可传入 `--train-dataset` 和 `--validation-dataset`。输出目录应为新目录。

一次调用会训练 RGB＋状态模型及只用状态的对照，默认60轮、CPU两线程。数据预处理可复用内容哈希缓存；训练逐轮保存 `last.pt` 和进度、历史文件，按验证集归一化动作MSE选择 `policy.pt`。这是验证集选模，没有独立测试集结论。

如果训练后的检查点和各模型 `metrics.json` 已保存，可只补做或重复评估，不重新训练：

```bash
python train_behavior_cloning.py --output-dir runs/bc_demo --evaluate-only
```

必须使用同样的数据、图像尺寸和预处理配置，脚本检查数据指纹及预测一致性。该选项不是从优化器状态继续训练；`last.pt` 虽含优化器状态，本版尚未提供中断续训入口。

## 输入、标签与输出

RGB模型只接收当前原始RGB的96×96全局视图、64×64原分辨率目标局部裁剪、当前A/B/C状态及从同一RGB得到的目标中心和可见标记。目标定位是当前场景的橙色阈值连通区域规则；没有使用分割、深度、动态真值或标靶ID。目标不可见时局部图为黑色、视觉特征为零，不填入历史位置。

全局缩放会丢失微小目标信息，局部图保留原像素细节。这个颜色规则仍需在新外观、新布局及干扰物上验证，不能视为通用病灶检测器。状态对照同时移除图像和所有RGB目标特征。任务文本固定，本版不训练文本编码器。

标签为 `action - observation.state`，不是直接回归下一时刻绝对位置。按配置的最大速度×0.05秒归一化为 `[0.2度, 0.1度, 0.03毫米]` 的增量尺度；模型输出经tanh限制在每轴[-1,1]。这只限制一步增量，不构成加速度、眼壁约束或实际制动验证。

训练使用时间间隔加权的Huber损失；报告使用同样权重的归一化动作MSE及物理单位动作误差。极短的阶段拼接间隔权重接近零，最后一帧保持动作保留一个正常间隔的权重。**不把动作除以约1e-9秒的拼接间隔计算速度。**

## 第一次实际结果

结果目录为 `runs/policy_training_20261022/bc_first/`。训练1289帧、验证669帧，均整episode划分；两个模型各完成60轮，检查点重载预测一致，原始PNG到推理输入与训练缓存逐元素一致。RGB模型52,987参数，状态模型8,963参数。

| 验证方法 | 时间加权归一化一步动作MSE |
|---|---:|
| 保持当前位置（零增量） | 0.235738 |
| 训练状态1近邻查表 | **0.031936** |
| RGB＋状态BC | 0.140098 |
| 仅状态BC | 0.154560 |

RGB模型训练动作MSE为0.077032；验证时打乱图像、局部图及RGB特征后为0.267383。RGB模型优于本次状态神经网络基线，但明显弱于简单状态近邻查表。打乱实验说明当前模型对视觉输入敏感，不证明新布局泛化。

两集使用相同P1/P2/P3目标与访问顺序，验证起始姿态来自原训练轨迹；609/669验证状态距离训练轨迹小于0.1个归一化动作步。不能把这些相关帧当成独立任务，不能将此验证误差称为终点误差，更不能据此宣称导航达到20 μm。

本次训练主体完成后，报告导出因audit字段名不一致触发KeyError。已修复为 `image_relative_path`，复用原60轮检查点完成评估，没有重新训练或修改原示范。原训练源码与修复后评估源码分别快照，日志保留该失败与修复过程。

## 检查点与单帧推理

```bash
python predict_behavior_action.py --checkpoint runs/policy_training_20261022/bc_first/rgb_state_bc/policy.pt --image runs/multitarget_occlusion_20261022/strict_occlusion_recovery/dataset/images/episode_000000/frame_000000.png --state 6.481389210293787 2.847750084902797 17.8199835578327
```

输出归一化增量、物理增量和建议下一绝对位置，仅打印，不执行运动。检查点加载使用 `torch.load(..., weights_only=True)`。默认模型没有记忆、阶段管理或目标切换机制，当前不能直接替换原严格视觉导航控制器。

## 随机目标是下一轮数据的必要条件

用户已确认：后续采集和策略训练使用随机眼底目标布局；固定P1/P2/P3只保留为历史回归和本次训练链路验证。

正式策略训练应在眼球后部表面代理上随机目标布局，并检查眼底区域、点间距、起始姿态与可观测性。每个完整episode保存seed和配置；同一布局的所有方法、访问顺序变体和遮挡条件归入同一split，测试保留训练未见布局。目标坐标只作场景布置和独立验收，不传给RGB策略。

当前目标生成入口 `random_fundus_dataset.py` 已支持随机眼底目标及严格视觉采集，例如先冻结场景（不执行导航）：

```bash
python random_fundus_dataset.py --output-dir runs/random_bc_scenarios --episodes 6 2 2 --targets-per-episode 3 --seed 20261022 --strict-visual --methods visual_servo
```

后续再按冻结布局采集完整成功/失败episode，组装多布局训练、验证、测试数据。当前这次训练使用固定布局，未在本轮自动启动随机采集或新布局闭环评估。
