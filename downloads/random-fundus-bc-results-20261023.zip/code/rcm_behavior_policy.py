"""Small RGB behavior cloning policies with an identical state-only baseline.

The policy sees only two RGB images, measured ABC joint state and RGB detector
features. Images must already be float tensors in [0, 1], with shape N x 3 x H
x W (normally 96 x 96 global RGB and 64 x 64 target ROI). ``state`` is raw ABC
in degrees, degrees and millimetres. ``visual_features`` normally contains
[2*centroid_u/(width-1)-1, 2*centroid_v/(height-1)-1, visible]; an invisible
target should have zero centroid features and a zero ROI.

``forward`` normalizes the state internally and returns dimensionless ABC
increments bounded by [-1, 1]. Multiply by ``action_scale`` to obtain physical
increments. For a 0.05 s control interval, the reference safe velocity limits
give an action scale of [0.2 deg, 0.1 deg, 0.03 mm]. Training code should derive
that scale from its configuration rather than assuming these example values.

No depth, segmentation, target truth, phase, waypoint or filename is an input.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

import torch
from torch import Tensor, nn


def _vector3(value: Sequence[float] | Tensor, name: str) -> Tensor:
    result = torch.as_tensor(value, dtype=torch.float32).detach().clone()
    if result.shape != (3,) or not bool(torch.isfinite(result).all()):
        raise ValueError(f"{name} must contain three finite numbers")
    return result


class BehaviorCloningPolicy(nn.Module):
    """A shared three-convolution image encoder and a small action MLP.

    With ``use_images=False``, both images and all visual features are ignored;
    callers may pass ``None`` for them. This baseline retains the same public
    interface and state normalization, but has no visual input or parameters.
    State statistics and action scales are registered buffers and are therefore
    stored in the state dict and moved with the model.
    """

    def __init__(
        self,
        *,
        state_mean: Sequence[float] | Tensor,
        state_std: Sequence[float] | Tensor,
        action_scale: Sequence[float] | Tensor,
        visual_feature_dim: int = 3,
        use_images: bool = True,
    ) -> None:
        super().__init__()
        if not isinstance(use_images, bool):
            raise ValueError("use_images must be a boolean")
        if not isinstance(visual_feature_dim, int) or visual_feature_dim < 0:
            raise ValueError("visual_feature_dim must be a nonnegative integer")
        mean = _vector3(state_mean, "state_mean")
        std = _vector3(state_std, "state_std")
        scale = _vector3(action_scale, "action_scale")
        if bool((std < 0).any()):
            raise ValueError("state_std must be nonnegative")
        if bool((scale <= 0).any()):
            raise ValueError("action_scale must be strictly positive")
        self.register_buffer("state_mean", mean)
        self.register_buffer("state_std", std.clamp_min(1e-6))
        self.register_buffer("action_scale", scale)
        self.visual_feature_dim = visual_feature_dim
        self.use_images = use_images

        feature_dim = 3
        if use_images:
            self.image_encoder = nn.Sequential(
                nn.Conv2d(3, 16, kernel_size=3, stride=2, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(16, 24, kernel_size=3, stride=2, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(24, 32, kernel_size=3, stride=2, padding=1),
                nn.ReLU(inplace=True),
                nn.AdaptiveAvgPool2d((2, 2)),
                nn.Flatten(1),
            )
            feature_dim += 2 * 32 * 2 * 2 + visual_feature_dim
        else:
            self.image_encoder = None
        self.action_head = nn.Sequential(
            nn.Linear(feature_dim, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, 64),
            nn.ReLU(inplace=True),
            nn.Linear(64, 3),
            nn.Tanh(),
        )

    def _image(self, value: Tensor | None, batch_size: int, name: str) -> Tensor:
        if value is None or value.ndim != 4 or value.shape[:2] != (batch_size, 3):
            raise ValueError(f"{name} must have shape (batch_size, 3, H, W)")
        if value.shape[2] < 8 or value.shape[3] < 8:
            raise ValueError(f"{name} image dimensions must be at least 8")
        if not torch.is_floating_point(value):
            raise ValueError(f"{name} must be floating point RGB in [0, 1]")
        return value.to(device=self.state_mean.device, dtype=self.state_mean.dtype)

    def forward(
        self,
        global_rgb: Tensor | None,
        target_roi: Tensor | None,
        state: Tensor,
        visual_features: Tensor | None,
    ) -> Tensor:
        """Return normalized delta ABC, shape N x 3, from raw ABC state.

        Input image conversion/resizing and RGB target detection belong to the
        caller. Keeping those steps outside this module lets training and
        inference share exactly the same preprocessing.
        """
        if state.ndim != 2 or state.shape[1] != 3:
            raise ValueError("state must have shape (batch_size, 3)")
        state = state.to(device=self.state_mean.device, dtype=self.state_mean.dtype)
        normalized_state = (state - self.state_mean) / self.state_std
        if not self.use_images:
            return self.action_head(normalized_state)

        batch_size = state.shape[0]
        global_rgb = self._image(global_rgb, batch_size, "global_rgb")
        target_roi = self._image(target_roi, batch_size, "target_roi")
        if visual_features is None or visual_features.shape != (batch_size, self.visual_feature_dim):
            raise ValueError(f"visual_features must have shape (batch_size, {self.visual_feature_dim})")
        visual_features = visual_features.to(device=self.state_mean.device, dtype=self.state_mean.dtype)
        assert self.image_encoder is not None
        features = torch.cat(
            (
                self.image_encoder(global_rgb),
                self.image_encoder(target_roi),
                normalized_state,
                visual_features,
            ),
            dim=1,
        )
        return self.action_head(features)

    def physical_action(self, normalized_action: Tensor) -> Tensor:
        """Convert normalized output to delta ABC in deg, deg and mm."""
        return normalized_action * self.action_scale

    def config(self) -> dict[str, Any]:
        """Return plain constructor arguments suitable for a checkpoint."""
        return {
            "state_mean": self.state_mean.detach().cpu().tolist(),
            "state_std": self.state_std.detach().cpu().tolist(),
            "action_scale": self.action_scale.detach().cpu().tolist(),
            "visual_feature_dim": self.visual_feature_dim,
            "use_images": self.use_images,
        }


def policy_from_checkpoint(
    path: str | Path,
    device: str | torch.device = "cpu",
) -> tuple[BehaviorCloningPolicy, dict[str, Any]]:
    """Load an evaluation policy and metadata without arbitrary pickle loading.

    Expected checkpoint fields are ``model_config`` (``policy.config()``),
    ``state_dict`` (``policy.state_dict()``), and optional ``metadata`` (a plain
    dict). Save these with ``torch.save``. ``weights_only=True`` is mandatory;
    unsupported checkpoints or older PyTorch versions fail explicitly instead
    of falling back to unsafe pickle deserialization.
    """
    try:
        checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    except TypeError as exc:
        raise RuntimeError("Checkpoint loading requires PyTorch with weights_only=True support") from exc
    if not isinstance(checkpoint, Mapping):
        raise ValueError("checkpoint must be a mapping")
    config = checkpoint.get("model_config")
    state_dict = checkpoint.get("state_dict")
    metadata = checkpoint.get("metadata", {})
    if not isinstance(config, Mapping) or not isinstance(state_dict, Mapping):
        raise ValueError("checkpoint requires model_config and state_dict mappings")
    if not isinstance(metadata, dict):
        raise ValueError("checkpoint metadata must be a dict")
    required_keys = {"state_mean", "state_std", "action_scale"}
    allowed_keys = required_keys | {"visual_feature_dim", "use_images"}
    if not required_keys.issubset(config) or not set(config).issubset(allowed_keys):
        raise ValueError("checkpoint model_config has missing or unsupported fields")
    policy = BehaviorCloningPolicy(**dict(config))
    for name, value in state_dict.items():
        if not isinstance(name, str) or not isinstance(value, Tensor):
            raise ValueError("checkpoint state_dict must map names to tensors")
        if not bool(torch.isfinite(value).all()):
            raise ValueError(f"checkpoint contains nonfinite tensor: {name}")
    for name in ("state_mean", "state_std", "action_scale"):
        saved_value = state_dict.get(name)
        if saved_value is None or not torch.equal(saved_value, getattr(policy, name)):
            raise ValueError(f"checkpoint {name} disagrees with model_config")
    policy.load_state_dict(state_dict, strict=True)
    policy.to(device)
    policy.eval()
    return policy, metadata
